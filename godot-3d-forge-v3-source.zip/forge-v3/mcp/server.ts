#!/usr/bin/env node
/**
 * Godot 3D Forge MCP server entry point (F-31). Runs directly under Node 24
 * native TypeScript type stripping — no build step:
 *
 *   node mcp/server.ts
 *
 * Thin bootstrap: registers the ESM resolve hook (cli/resolve-hooks.mjs)
 * that lets extensionless `.ts` imports in the engine resolve, then
 * dynamic-imports the real implementation.
 */
import { register } from 'node:module';

register('../cli/resolve-hooks.mjs', import.meta.url);

const { main } = await import('./server-main.ts');
await main();
