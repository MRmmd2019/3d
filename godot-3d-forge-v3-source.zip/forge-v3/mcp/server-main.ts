/**
 * Godot 3D Forge MCP server (F-31).
 *
 * stdio transport; tools reuse `lib/node-shim.ts` + the engine core — no
 * duplicated mesh code. Run directly under Node 24 native TypeScript
 * type stripping (no build step):
 *
 *   node mcp/server.ts
 *
 * Tools:
 *   build_mesh     — photo (+ optional back photo) -> GLB mesh file
 *   optimize_glb   — weld / dedup / prune an existing GLB
 *   validate_mesh  — parse a GLB and validate its mesh topology
 *   list_targets   — export targets (godot / unity / unreal / blender / generic)
 */
import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { z } from 'zod';
import { basename } from 'node:path';
import {
  TARGET_NOTE,
  buildMeshGlb,
  defaultGlbOutPath,
  listForgeTargets,
  optimizeGlbFile,
  validateGlbFile,
  writeFile,
} from '../lib/node-shim';

const TARGET_ENUM = ['godot', 'unity', 'unreal', 'blender', 'generic'] as const;
const MODE_ENUM = ['sculpted', 'lathe', 'voxel'] as const;

type TextContent = { type: 'text'; text: string };

function textResult(value: unknown): { content: TextContent[] } {
  return {
    content: [
      {
        type: 'text',
        text: typeof value === 'string' ? value : JSON.stringify(value, null, 2),
      },
    ],
  };
}

function errorResult(message: string): { content: TextContent[]; isError: true } {
  return { content: [{ type: 'text', text: `Error: ${message}` }], isError: true };
}

export async function main(): Promise<void> {
  const server = new McpServer({ name: 'godot-3d-forge', version: '0.2.0' });

  server.registerTool(
    'build_mesh',
    {
      description:
        'Build a 3D mesh (GLB) from a photo using the Godot 3D Forge engine. ' +
        'The photo should show a single object on a plain light background. ' +
        'Target note: all targets currently use the Godot default geometry; ' +
        'target-specific transforms (Unreal cm scale, normal flip, Unity packing) ' +
        'land with Group F (lib/targets.ts).',
      inputSchema: {
        imagePath: z.string().describe('Path to the front photo (PNG/JPG/WebP).'),
        outputPath: z
          .string()
          .optional()
          .describe('Output GLB path. Defaults to <photo-basename>.glb in the working directory.'),
        backImagePath: z
          .string()
          .optional()
          .describe('Optional second photo for the back face (dual-view atlas).'),
        widthMeters: z
          .number()
          .min(0.05)
          .max(20)
          .optional()
          .describe('Real-world width of the model in metres (default 1.0).'),
        target: z
          .enum(TARGET_ENUM)
          .optional()
          .describe('Export target (default godot). Accepted but not yet transformed: unity, unreal, blender, generic.'),
        mode: z
          .enum(MODE_ENUM)
          .optional()
          .describe('Mesh mode: sculpted (default), lathe, voxel.'),
        assetName: z
          .string()
          .optional()
          .describe('Asset/node name (default: photo file name, ASCII-sanitized).'),
      },
    },
    async (args) => {
      try {
        const result = await buildMeshGlb({
          frontPath: args.imagePath,
          backPath: args.backImagePath ?? null,
          target: args.target ?? 'godot',
          widthMeters: args.widthMeters ?? 1.0,
          mode: args.mode ?? 'sculpted',
          assetName:
            args.assetName ?? basename(args.imagePath).replace(/\.[^.]+$/, ''),
          optimize: true,
        });
        const outputPath = args.outputPath ?? defaultGlbOutPath(args.imagePath);
        await writeFile(outputPath, result.glbBytes);
        return textResult({
          ok: true,
          output: outputPath,
          target: result.target,
          asset: result.assetName,
          triangles: result.triangles,
          vertices: result.vertices,
          sizeBytes: result.sizeBytes,
          widthMeters: result.widthMeters,
          watertight: result.watertight,
          boundsMeters: result.boundsMeters,
          foregroundCoveragePct: result.foregroundCoveragePct,
          hasBackImage: result.hasBackImage,
          ...(result.target !== 'godot' ? { targetNote: TARGET_NOTE } : {}),
        });
      } catch (err) {
        return errorResult(err instanceof Error ? err.message : String(err));
      }
    }
  );

  server.registerTool(
    'optimize_glb',
    {
      description:
        'Optimize a GLB file in place (weld / dedup / prune via gltf-transform). ' +
        'If outputPath is omitted the input file is overwritten.',
      inputSchema: {
        inputPath: z.string().describe('Path to the GLB file to optimize.'),
        outputPath: z
          .string()
          .optional()
          .describe('Output GLB path (default: overwrite the input file).'),
      },
    },
    async (args) => {
      try {
        const res = await optimizeGlbFile(args.inputPath, args.outputPath);
        return textResult({ ok: true, ...res });
      } catch (err) {
        return errorResult(err instanceof Error ? err.message : String(err));
      }
    }
  );

  server.registerTool(
    'validate_mesh',
    {
      description:
        'Parse a GLB file and validate the topology of its first mesh ' +
        '(watertight, open boundary edges, degenerate triangles, triangle budget).',
      inputSchema: {
        path: z.string().describe('Path to the GLB file to validate.'),
      },
    },
    async (args) => {
      try {
        const report = await validateGlbFile(args.path);
        return textResult({ ok: true, path: args.path, ...report });
      } catch (err) {
        return errorResult(err instanceof Error ? err.message : String(err));
      }
    }
  );

  server.registerTool(
    'list_targets',
    {
      description:
        'List the export targets the Forge CLI/MCP accept ' +
        '(godot, unity, unreal, blender, generic) with their units. ' +
        'Note: target-specific transforms land with Group F; until then every ' +
        'target uses the Godot default geometry.',
      inputSchema: {},
    },
    async () => textResult({ targets: listForgeTargets(), note: TARGET_NOTE })
  );

  await server.connect(new StdioServerTransport());
}
