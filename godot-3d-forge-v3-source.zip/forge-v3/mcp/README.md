# Godot 3D Forge — MCP server

MCP server (stdio transport) for Godot 3D Forge v3 (package 0.2.0). It exposes
the photo-to-GLB engine over the Model Context Protocol, reusing
`lib/node-shim.ts` + the engine core — no duplicated mesh code.

Requires **Node.js 24+** and the project's dependencies installed
(`npm install` in the Forge root). No build step: the server runs directly
from TypeScript via Node's native type stripping.

```bash
node mcp/server.ts
```

## Tools

| Tool | Description |
| --- | --- |
| `build_mesh` | Build a 3D mesh (GLB) from a photo. Params: `imagePath` (required), `outputPath`, `backImagePath`, `widthMeters` (0.05–20, default 1.0), `target` (godot/unity/unreal/blender/generic, default godot), `mode` (sculpted/lathe/voxel), `assetName`. |
| `optimize_glb` | Optimize a GLB (weld / dedup / prune). Params: `inputPath`, `outputPath` (default: overwrite input). |
| `validate_mesh` | Parse a GLB and validate its mesh topology (watertight, open edges, degenerate triangles, triangle budget). Params: `path`. |
| `list_targets` | List the export targets with their units. |

> Target note: all five target names are accepted, and the target
> transforms (Unreal cm scale, normal-map green-channel flip, Unity
> metallic+smoothness packing) are implemented in `lib/targets.ts` and
> wired into the web export path (`prepareExportGroup()` in
> `lib/godotExport.ts`). The Node path (`buildMeshGlb` in
> `lib/node-shim.ts`) does not apply them yet — until that wiring lands,
> every target built through the CLI/MCP uses the Godot default geometry.

## Claude Desktop config

Add a server entry to your Claude Desktop config file:

- macOS: `~/Library/Application Support/Claude/claude_desktop_config.json`
- Windows: `%APPDATA%\Claude\claude_desktop_config.json`
- Linux: `~/.config/Claude/claude_desktop_config.json` (if applicable)

```json
{
  "mcpServers": {
    "godot-3d-forge": {
      "command": "node",
      "args": ["/absolute/path/to/godot-3d-forge/mcp/server.ts"],
      "cwd": "/absolute/path/to/godot-3d-forge"
    }
  }
}
```

Replace `/absolute/path/to/godot-3d-forge` with the real checkout path, then
restart Claude Desktop.

## Cursor config

Add to your project's `.cursor/mcp.json` (or Cursor Settings → MCP):

```json
{
  "mcpServers": {
    "godot-3d-forge": {
      "command": "node",
      "args": ["/absolute/path/to/godot-3d-forge/mcp/server.ts"],
      "cwd": "/absolute/path/to/godot-3d-forge"
    }
  }
}
```

## Verifying the server

From the Forge root, drive it with a raw JSON-RPC exchange over stdio:

```bash
printf '%s\n' \
  '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2024-11-05","capabilities":{},"clientInfo":{"name":"probe","version":"0.1"}}}' \
  '{"jsonrpc":"2.0","method":"notifications/initialized"}' \
  '{"jsonrpc":"2.0","id":2,"method":"tools/list"}' \
  | node mcp/server.ts
```

`tools/list` must show `build_mesh`, `optimize_glb`, `validate_mesh`,
`list_targets`.
