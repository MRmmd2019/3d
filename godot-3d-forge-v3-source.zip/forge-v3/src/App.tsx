import StudioWorkspace from '@/components/StudioWorkspace';

export default function App() {
  return <StudioWorkspace />;
}
