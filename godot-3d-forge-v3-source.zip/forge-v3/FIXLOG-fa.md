# گزارش رفع و تغییر — Godot 3D Forge v3 (0.2.0)

> مبنا: `forge-no-gemini` (v2 بدون جمنای). برای هر تغییر: فایل:خط قبل/بعد، تست تئوری، تست عملی، نتیجه.
> قانون: اگر تغییری بعد از ۳ تلاش نشد، با برچسب «مسدود — بعد از ۳ تلاش» ثبت می‌شود؛ هرگز رفع خراب قبول نیست.

## فاز A — مهاجرت به Vite (هماهنگ‌کننده)

### F-13 — اسکافولد Vite + React + `vite.config.ts`
- **فایل:** `vite.config.ts` (جدید).
- **تغییر:** `base` از env با نام `PAGES_BASE` خوانده می‌شود، پیش‌فرض `/`؛ پلاگین‌های `react()` و `tailwindcss()`؛ alias `@/` به ریشه پروژه؛ `worker.format: 'es'`.
- **تست تئوری:** الگوی `new Worker(new URL('./meshBuildWorker.ts', import.meta.url))` در Vite به‌صورت بومی پشتیبانی می‌شود؛ `base` در `index.html` و assetها تزریق می‌شود.
- **تست عملی:** `npm run build` موفق (۹٫۴۷ ثانیه)؛ `dist/` با `vite preview` سرو شد، HTTP 200 و title درست.
- **نتیجه:** ✅ انجام شد.

### F-14 — انتقال موتور و UI به Vite
- **فایل‌ها:** `src/main.tsx` (جدید)، `src/App.tsx` (جدید)، `index.html` (جدید)، `src/globals.css` (منتقل‌شده از `app/globals.css`)؛ حذف `app/page.tsx` و `app/layout.tsx`.
- **تغییر:** `main.tsx` روت React را روی `#root` سوار می‌کند؛ `App.tsx` همان `StudioWorkspace` را رندر می‌کند؛ ساختار `lib/` و `components/` بدون تغییر حفظ شد؛ alias `@/` به ریشه نگاشت شد.
- **تست تئوری:** هیچ import از `next/*` در `lib/` و `components/` و `hooks/` نبود (فقط `layout.tsx` و روت API)؛ موتور بدون تغییر منتقل می‌شود.
- **تست عملی:** `npx tsc --noEmit` تمیز؛ `npm run build` موفق؛ سرو `dist/` با HTTP 200 و title «Godot 3D Forge — تبدیل تصویر به مدل سه‌بعدی».
- **نتیجه:** ✅ انجام شد.

### F-15 — فونت self-hosted
- **فایل‌ها:** `package.json` (افزودن `@fontsource/vazirmatn` و `@fontsource/jetbrains-mono`)، `src/main.tsx` (import وزن‌های ۴۰۰/۵۰۰/۶۰۰/۷۰۰ وزیرمتن و ۴۰۰/۵۰۰/۶۰۰ جت‌برینز مونو)، `src/globals.css` (تعریف `:root` برای `--font-vazirmatn` و `--font-jetbrains-mono` که قبلاً `next/font` تعریف می‌کرد).
- **تست تئوری:** فایل‌های CSS هر وزن در پکیج fontsource وجود دارند و subset عربی/لاتین را با unicode-range شامل می‌شوند.
- **تست عملی:** در خروجی `dist/assets/` فایل‌های woff2 و woff وزیرمتن (عربی و لاتین) و جت‌برینز مونو تولید شدند.
- **نتیجه:** ✅ انجام شد.

### F-16 — Tailwind v4 با `@tailwindcss/vite`
- **فایل‌ها:** `package.json` (افزودن `@tailwindcss/vite`، حذف `postcss` و `autoprefixer` و `@tailwindcss/postcss`)؛ حذف `postcss.config.mjs`؛ `src/globals.css` بدون تغییر (`@import "tailwindcss"` و `@import "tw-animate-css"` حفظ شد).
- **تست تئوری:** پلاگین Vite جایگزین PostCSS می‌شود؛ `@import`های Tailwind در Vite پردازش می‌شوند.
- **تست عملی:** بیلد موفق؛ `dist/assets/index-*.css` با حجم ۷۱٫۶۹ کیلوبایت (gzip ‏۲۸٫۱۲) تولید شد.
- **نتیجه:** ✅ انجام شد.

### F-17 — `optimize-glb` به سمت کلاینت
- **فایل‌ها:** `lib/optimizeGlb.ts` (جدید — همان منطق روت Next: WebIO ‏`weld/dedup/prune` با سقف ۲۵ مگابایت، خطا throw می‌شود)، `lib/godotExport.ts:1` (import تابع جدید) و `lib/godotExport.ts:20-26` (تابع محلی `optimizeGlbBinary` که fetch به `/api/optimize-glb` می‌زد، حالا تابع جدید را صدا می‌زند و در خطا بافر خام را برمی‌گرداند — رفتار fallback دقیقاً حفظ شد).
- **تست تئوری:** `WebIO` در مرورگر isomorphic است؛ همان transformها همان خروجی را می‌دهند.
- **تست عملی:** `npx tsc --noEmit` تمیز؛ `npm run build` موفق؛ هیچ ارجاعی به `/api/optimize-glb` در کد نمانده است.
- **نتیجه:** ✅ انجام شد.

### F-18 — ورک‌فلوی GitHub Actions
- **فایل:** `.github/workflows/deploy.yml` (جدید).
- **تغییر:** checkout ← setup-node 24 ← `npm ci` ← `npm run build` با `PAGES_BASE=/<repo>/` ← upload-pages-artifact از `dist/` ← deploy-pages.
- **تست تئوری:** `PAGES_BASE` از `github.event.repository.name` ساخته می‌شود که برای Project Page همان `/<repo>/` است.
- **تست عملی:** سینتکس YAML با `python3 -c yaml.safe_load` تأیید شد. ورک‌فلو اجرا نشد (دیپلوی ممنوع است).
- **نتیجه:** ✅ انجام شد (اجرا نشده — دیپلوی ممنوع).

### F-19 — حذف فایل‌های Next.js
- **فایل‌های حذف‌شده:** `next.config.ts`، `app/` (کل پوشه)، `next-env.d.ts`، `metadata.json`، `.eslintrc.json`، `postcss.config.mjs`، `tsconfig.tsbuildinfo`؛ وابستگی‌های `next` و `eslint-config-next` از `package.json` حذف شدند؛ `tsconfig.json` بازنویسی شد (حذف پلاگین `next` و include های `.next`، ‏`jsx: react-jsx`، ‏`include: src, lib, components, hooks, vite.config.ts`)؛ ‏`.gitignore`: ‏`.next/` ← ‏`dist/`؛ ‏`eslint.config.mjs` با `@eslint/js` + ‏`typescript-eslint` + ‏`eslint-plugin-react-hooks` (flat) + ‏`globals` بازنویسی شد؛ ۴ کامنت `eslint-disable-next-line @next/next/no-img-element` از `components/StudioWorkspace.tsx` حذف شدند.
- **تست تئوری:** هیچ import از `next/*` در کد باقی نمانده بود (فقط layout و روت API).
- **تست عملی:** `grep -rn "from 'next"` در `src/ lib/ components/ hooks/` صفر نتیجه؛ `npm run lint` تمیز (exit 0)؛ `npx tsc --noEmit` تمیز؛ `npm run build` موفق.
- **نتیجه:** ✅ انجام شد.
- **یادداشت ۱ (lint):** پیکربندی اول `reactHooks.configs['recommended-latest']` فرمت eslintrc داشت و ESLint 9 خطا داد؛ با `reactHooks.configs.flat['recommended-latest']` اصلاح شد (تلاش ۱).
- **یادداشت ۲ (lint — کد مرده از قبل):** ‏`npm run lint` دو خطای `no-unused-vars` از قبل را نشان داد که با حذف جمنای جا مانده بود: state خوانده‌نشده `sourceMimeType` در `components/StudioWorkspace.tsx:48` (فقط set می‌شد، هرگز خوانده نمی‌شد — state و set آن حذف شد) و متغیر استفاده‌نشده `sy` در `lib/meshAlgorithms.ts:347` (در حلقه خودش خوانده نمی‌شد — خط حذف شد). بعد از هر دو اصلاح، lint تمیز و تست‌ها ۱۰/۱۰ پاس شدند.

### F-20 — اضافه کردن `vite` به devDependencies
- **فایل:** `package.json` (‏`vite: ^7.0.0`؛ نصب‌شده 7.3.8).
- **تست عملی:** `npm ls vite` نسخه 7.3.8 را نشان می‌دهد.
- **نتیجه:** ✅ انجام شد.

### F-21 — ارتقای `@types/node` از `^20` به `^22`
- **فایل:** `package.json` (‏`@types/node: ^22`).
- **تست تئوری:** vitest 5.1.0 به `@types/node@^22 || >=24` نیاز دارد و نبود `vite` هم خطای `ERR_MODULE_NOT_FOUND` می‌داد — هر دو با F-20/F-21 رفع می‌شوند.
- **تست عملی:** `npm install` ساده (بدون `--legacy-peer-deps`) موفق شد — ۲۵۸ پکیج؛ `npm test` ‏**۱۰/۱۰ پاس** شد.
- **نتیجه:** ✅ انجام شد.

### یادداشت فاز A
- باندل اصلی `dist/assets/index-*.js` ‏۱٫۱۹ مگابایت خام / ‏۳۳۷ کیلوبایت gzip است (three.js کامل) و Vite هشدار chunk-size می‌دهد — فقط هشدار است، نه خطا؛ با gzip با First Load قبلی Next ‏(۳۴۱ کیلوبایت) برابر است.
- ورکر `meshBuildWorker` به‌صورت چانک جدا (`dist/assets/meshBuildWorker-*.js`، ‏۹۲٫۷۸ کیلوبایت) ساخته شد.
- نسخه `package.json` به `0.2.0` رفت و اسکریپت‌ها Vite شدند (`dev`، ‏`build: tsc --noEmit && vite build`، ‏`preview`، ‏`test`، ‏`lint`، ‏`clean: rm -rf dist`).

## فاز B — گروه‌های موازی (C / D / E / F)

> هر گروه در کپی کاری خودش (`forge-v3-work-c/d/e/f`) ساخته شد و نتیجه‌اش اینجا ادغام می‌شود.

### F-22 — برش ML با `@imgly/background-removal`
- **فایل‌ها:** `lib/mlCutout.ts` (جدید — `removeBackgroundFromImageUrl()` با lazy dynamic import و `mlAlphaMaskFromRgba()` خالص و قابل تست در Node)، `lib/meshTypes.ts` (‏`CutoutMethod = 'flood' | 'ml'` و `cutoutMethod` با پیش‌فرض `'flood'`)، `lib/meshPipeline.ts` (ورودی‌های اختیاری `mlMask`/`backMlMask`؛ وقتی برش فعال و روش `ml` است و ماسک داده شده، مستقیم استفاده می‌شود، وگرنه flood-fill)، `lib/meshEngine.ts` (‏`applyMlCutoutToView` و `flipMaskHorizontally`؛ برش ML جلو/پشت قبل از نمونه‌گیری، fallback به flood-fill برای هر view در صورت خطا)، `components/StudioWorkspace.tsx` (تاگل دو دکمه‌ای «Flood-fill (آفلاین)» / «ML (هوش مصنوعی)» در سکشن جداسازی سوژه؛ اسلایدرهای flood فقط وقتی روش flood است نشان داده می‌شوند)، `package.json` (افزودن `@imgly/background-removal@^1.7.0` و `onnxruntime-web@1.21.0`).
- **تغییر:** روش دوم برش (ML، ‏ONNX/WASM)؛ پیش‌فرض همان flood-fill می‌ماند تا آفلاین بودن حفظ شود؛ دانلود مدل فقط در اولین استفاده و کش‌شده (طبق مستند کتابخانه).
- **تست عملی:** ۹ تست در `lib/__tests__/cutout.test.ts` (پیش‌فرض flood، مرز threshold ماسک، استفاده pipeline از ماسک ML، نادیده‌گرفتن ماسک ML وقتی flood است، fallback به flood وقتی ml انتخاب شده ولی ماسک نیست) پاس شدند. استنتاج زنده ML در مرورگر واقعی در این VM اجرا نشد (مرورگر زنده نیست) — lazy import و code-split در بیلد تأیید شد.
- **⚠️ پرچم لایسنس:** ‏`@imgly/background-removal` تحت **AGPL** است، برخلاف بقیه وابستگی‌های MIT — برای تصمیم لایسنس اوپن‌سورس که هنوز قطعی نشده اهمیت دارد؛ در کامنت بالای `lib/mlCutout.ts` ثبت شد.
- **نتیجه:** ✅ انجام شد (با قید تست زنده بالا).

### F-23 — فشرده‌سازی WebP بافت‌ها
- **فایل‌ها:** `lib/optimizeGlb.ts` (‏`optimizeGlbBinary(rawBuffer, { webpTextures = true, webpQuality = 85 })`؛ ‏`textureCompress({ targetFormat: 'webp', quality, slots: /^(?!normalTexture).*$/ })` بعد از weld/dedup/prune؛ نرمال‌مپ‌ها مستثنی‌اند و PNG lossless می‌مانند؛ ‏`EXTTextureWebP` روی نمونه WebIO ثبت شد — بدون آن بلوک extension هنگام نوشتن بی‌صدا حذف می‌شود و mimeType ‏`image/webp` نامعتبر می‌ماند)، `lib/meshTypes.ts` (‏`webpTextures: boolean` با پیش‌فرض `true`)، `lib/godotExport.ts` (عبور `webpTextures` از `exportThreeGroup` و `serializeGroupToBlob` و `exportTargetZip`)، `components/StudioWorkspace.tsx` (عبور `webpTextures: settings.webpTextures` در محل فراخوانی خروجی + چک‌باکس WebP زیر چک‌باکس بهینه‌سازی، فقط وقتی بهینه‌سازی روشن است)، `package.json` (افزودن `@gltf-transform/extensions@^4.5.1`).
- **حکم Godot (تست headless):** ‏**Godot 4.7.2 بافت WebP در GLB را می‌خواند (EXT_texture_webp) — پیش‌فرض روشن امن است.** شواهد (Godot ‏`4.7.2.stable.official.ed1daf0bf`): تبدیل `akm_trellis_clean.glb` ‏(۱٬۰۹۴٬۶۸۴ بایت؛ ۱ بافت PNG ‏۹۱۳٬۷۶۸ بایت) ← GLB وب‌پی ‏۲۵۶٬۲۲۰ بایت با همان `optimizeGlbBinary` (‏۷۶٫۶٪ کوچک‌تر)؛ بافت `image/webp` ‏۹۶٬۴۰۶ بایت؛ ‏`extensionsUsed`/`extensionsRequired` ‏= ‏`EXT_texture_webp`؛ ایمپورت headless در پروژه حداقلی ← ‏exit 0 و صفر خط «error» در لاگ؛ خروجی ایمپورتر `akm_webp_appfn_Image_0.webp-*.ctex` ‏(۱٫۱ مگابایت) و `.scn` ‏۹۱ کیلوبایت؛ چک زمان اجرا (اسکریپت SceneTree): ‏`albedo_texture=<CompressedTexture2D> size=(1024, 1024)` و `surfaces_with_albedo_texture=1`. کنترل: GLB اصلی PNG در همان اجرا یکسان ایمپورت شد.
- **تست عملی:** تست‌های `cutout.test.ts` برای مسیر بدون WebP و رد ورودی خالی پاس شدند؛ `npm test` نهایی ‏۶۵/۶۵.
- **یادداشت ادغام (رفع پس از ادغام، تلاش ۱):** بعد از ادغام C، تست `nodeShim.test.ts` با خطای `Missing required extension, "EXT_texture_webp"` شکست — چون `buildMeshGlb` حالا GLB وب‌پی می‌سازد اما `readGlbMeshStats`/`validateGlbBytes` در `lib/node-shim.ts` از `new WebIO()` بدون ثبت extension استفاده می‌کردند. رفع: helper ‏`createWebIO()` در `lib/node-shim.ts` که `EXTTextureWebP` را ثبت می‌کند و در هر سه محل (`writeBinary`، ‏`readGlbMeshStats`، ‏`validateGlbBytes`) جایگزین شد؛ بعد از رفع، تست‌ها ۶۵/۶۵ پاس شدند.
- **نتیجه:** ✅ انجام شد.

### F-24 — PWA با `vite-plugin-pwa`
- **فایل‌ها:** `vite.config.ts` (پلاگین `VitePWA`)، `src/main.tsx` (ثبت SW با `registerSW({ immediate: true })`)، `src/vite-env.d.ts` (ارجاع تایپ `vite-plugin-pwa/client`)، `public/icons/icon-192.png` و `icon-512.png` و `apple-touch-icon.png` (جدید — ساخته‌شده با اسکریپت خالص Node؛ گرادیان بنفش→فیروزه‌ای + قاب کهربایی)، `package.json` (افزودن `vite-plugin-pwa@^2.0.0` به devDependencies).
- **تغییر:** مانیفست (نام فارسی استودیو، theme ‏`#7138D4`، ‏background ‏`#090b0f`، ‏`display: standalone`، ‏`dir: rtl`، ‏`lang: fa`، ‏۴ آیکون) + Service Worker با generateSW و کش app shell.
- **تست تئوری:** `start_url` و `scope` باید با `base` (مسیر فرعی PAGES_BASE) هماهنگ باشند.
- **تست عملی:** بیلد نهایی `dist/` شامل `sw.js` و `workbox-9c191d2f.js` و `manifest.webmanifest` است (۶۳ ورودی precache، ‏۲۲۰۶٫۵۳ کیلوبایت)؛ بیلد با `PAGES_BASE=/godot-3d-forge/` مقدار `start_url`/`scope` را `/godot-3d-forge/` داد و بیلد پیش‌فرض `/`؛ تست سرو: index ‏۲۰۰ + title درست، ‏`sw.js` ‏۲۰۰، مانیفست ۲۰۰، آیکون ۲۰۰.
- **نتیجه:** ✅ انجام شد.

### F-25 — ذخیره تنظیمات در localStorage
- **فایل‌ها:** `lib/persistence.ts` (جدید — `loadStoredSettings`/`saveStoredSettings`/`mergeStoredSettings`)، `components/StudioWorkspace.tsx` (بارگذاری به‌عنوان initializer در `useState` + ذخیره با debounce ‏۴۰۰ میلی‌ثانیه).
- **تغییر:** کلید نسخه‌دار `godot-3d-forge:settings:v1`؛ `mergeStoredSettings` روی پیش‌فرض‌ها ادغام می‌کند با بررسی نوع و enum، پس مقادیر گمشده/خراب/قدیمی به پیش‌فرض برمی‌گردند.
- **تست عملی:** ۵ تست واحد در `lib/__tests__/persistence.test.ts` (شامل round-trip و عدم خطا وقتی storage در دسترس نیست) پاس شدند.
- **نتیجه:** ✅ انجام شد.

### F-26 — پروژه‌ها و پرست‌ها در IndexedDB با `idb-keyval`
- **فایل‌ها:** `lib/persistence.ts` (‏`savePreset/listPresets/deletePreset` و `saveProject/listProjects/deleteProject`؛ دیتابیس `godot-3d-forge` / استور `keyval`، جدیدترین اول)، `components/StudioWorkspace.tsx` (ورودی نام پرست + «ذخیره پرست»، لیست پرست با حذف، دکمه «ذخیره پروژه»، لیست پروژه با بندانگشتی + حذف)، `package.json` (افزودن `idb-keyval@^6.3.0` و `fake-indexeddb@^6.2.8` برای تست).
- **تغییر:** پرست = اسنپ‌شات تنظیمات + نام؛ پروژه = تنظیمات + بندانگشتی data URL.
- **تست عملی:** ۴ تست واحد (round-trip + ترتیب، با fake-indexeddb) پاس شدند.
- **یادداشت:** بارگذاری پروژه فقط تنظیمات را اعمال می‌کند — بندانگشتی فقط نمایشی است (بازسازی مش از بندانگشتی ۲۵۶ پیکسل خراب می‌شود) و اعلان به کاربر می‌گوید عکس را دوباره وارد کند.
- **نتیجه:** ✅ انجام شد.

### F-27 — File System Access API
- **فایل‌ها:** `lib/fileSystemAccess.ts` (جدید — `supportsFileSystemAccess()`، ‏`pickPhotoDirectory()` با مرتب‌سازی بر اساس نام، `saveBlobToDirectory()` و `saveGlbToFolder()`)، `components/StudioWorkspace.tsx` (دکمه «باز کردن پوشه عکس‌ها» + ناوبری بچ «عکس i از N»، دکمه «ذخیره GLB در پوشه» در تب خروجی).
- **تغییر:** همه مسیرها feature-detect می‌کنند؛ مرورگر پشتیبانی‌نشده به ورودی فایل معمولی / دانلود با anchor برمی‌گردد (`'unsupported'`)؛ لغو picker خطا نمی‌دهد (`'cancelled'`).
- **تست عملی:** ۳ تست واحد برای مسیر پشتیبانی‌نشده پاس شدند. مسیر پشتیبانی‌شده (picker واقعی) در این VM قابل تست زنده نیست و فقط بازبینی کد شده است.
- **نتیجه:** ✅ انجام شد (با قید بالا).

### F-28 — OffscreenCanvas در ورکر
- **فایل‌ها:** `lib/meshBuildWorker.ts` (جاب جدید `sample-image`: ‏`sampleImageBitmapOffscreen()` با feature-detect روی `typeof OffscreenCanvas` و گزارش `ok: false` وقتی نیست؛ ثبت `self.addEventListener` محافظت‌شده تا ماژول در Node برای تست import شود)، `lib/meshEngine.ts` (استخراج `getOrCreateWorker()` با رفتار یکسان + `canUseWorkerImageSampling`/`sampleImageRgbaViaWorker`/`sampleImageRgbaSmart`؛ ۴ فراخوانی `sampleImageRgba()` در `build3DMeshFromImage` حالا `await sampleImageRgbaSmart(...)` هستند؛ منطق cutout دست‌نخورده).
- **تغییر:** موتور اول نمونه‌گیری در ورکر را با `createImageBitmap` + transfer امتحان می‌کند و در هر خطا به `sampleImageRgba()` اصلی در main thread برمی‌گردد.
- **تست عملی:** ۳ تست واحد (عدم تشخیص در Node، خطا بدون OffscreenCanvas، پیکسل درست با OffscreenCanvas جعلی) پاس شدند؛ در باندل ساخته‌شده `sample-image` و `OffscreenCanvas` در `dist/assets/meshBuildWorker-*.js` دیده می‌شوند. دور کامل زنده در مرورگر در این VM ممکن نیست — fallback همان کد قبلی است.
- **نتیجه:** ✅ انجام شد (با قید بالا).

### F-29 — آداپتور Node با `lib/node-shim.ts`
- **فایل‌ها:** `lib/node-shim.ts` (جدید)، `package.json` (افزودن `sharp@^0.35.5`).
- **تغییر:** `decodeImageToRgba(path)` با sharp (‏`.ensureAlpha().raw()`)، ‏`encodeRgbaToPng` و `resampleRgba`، ‏`writeFile`/`readFileBytes` با `node:fs/promises`؛ ‏`buildMeshGlb(options)` هسته موتور را بدون تغییر می‌راند (همان فرمول‌های grid و texture-size در `meshEngine.build3DMeshFromImage`، فراخوانی مستقیم `runMeshBuildPipeline`) و GLB را با `@gltf-transform/core` می‌نویسد (positions/normals/UVs/indices و COLOR_0 در صورت وجود، بافت‌های albedo + normal + ORM ترکیبی به‌صورت PNG با sharp، متریال `Mat_<name>`، گره `<name>_Mesh-col`، pivot پایین-مرکز دقیقاً مثل meshEngine)؛ بهینه‌سازی weld/dedup/prune با `lib/optimizeGlb.ts` (پیش‌فرض روشن، همان fallback). هیچ `window`/`document` در این مسیر نیست؛ `meshEngine.ts` و `godotExport.ts` استفاده نشدند.
- **تست عملی:** ۳ تست در `lib/__tests__/nodeShim.test.ts` (round-trip دقیق PNG، رد فایل گمشده، ساخت کامل GLB از تصویر سنتتیک با magic ‏`glTF`، ‏۱ مش / ۱ متریال / ۳ بافت، watertight، عرض ≤ ‏۰٫۸۹ متر با width ‏۰٫۸۸) پاس شدند.
- **نتیجه:** ✅ انجام شد.

### F-30 — CLI در `cli/`
- **فایل‌ها:** `cli/forge.ts` (bootstrap نازک)، `cli/forge-main.ts`، `cli/args.ts` (+ `cli/args.test.ts` با ۷ تست)، `cli/resolve-hooks.mjs` (هوک resolve در ESM)، `cli/test-crate.png` (تصویر تست سنتتیک ۵۱۲×۳۸۴، جعبه تیره روی پس‌زمینه روشن، ساخته‌شده با PIL)، `package.json` (‏`bin: { forge: ./cli/forge.ts, forge-mcp: ./mcp/server.ts }`).
- **تغییر:** `node cli/forge.ts build <photo.png> [--target godot|unity|unreal|blender|generic] [--width 0.88] [--out out.glb]` (+ ‏`--back`، ‏`--mode`، ‏`--name`، ‏`--help`)؛ خلاصه JSON در stdout؛ کد خروج ۰ موفق / ۲ خطای استفاده / ۱ خطای زمان اجرا.
- **یادداشت فنی:** type-stripping در Node 24 به پسوند صریح فایل نیاز دارد اما موتور importهای بدون پسوند دارد (`./meshAlgorithms` در `meshPipeline.ts` — فایل‌هایی که نباید دست بخورند)؛ راه‌حل بدون بیلد اضافه: bootstrap هوک resolve را ثبت می‌کند و `forge-main.ts` را dynamic-import می‌کند (هوک فقط specifierهای نسبی بدون پسوند را به فایل `.ts` نگاشت می‌کند).
- **تست عملی:** ‏`node cli/forge.ts build cli/test-crate.png --width 0.88 --out /tmp/forge-e-out/test-crate.glb` ← ‏exit 0، ‏JSON: ‏triangles ‏۱۵۳۳۲، ‏vertices ‏۷۶۶۸، ‏sizeBytes ‏۴۷۶۰۳۲، ‏widthMeters ‏۰٫۸۸، ‏watertight ‏true، ‏openBoundaryEdges ‏۰؛ فایل گمشده ← ‏exit 1؛ نبود آرگومان عکس ← ‏exit 2 با usage؛ ‏`--target unreal` پذیرفته شد (همان هندسه + `targetNote` — ببینید محدودیت شناخته‌شده).
- **محدودیت شناخته‌شده:** ‏CLI/MCP همه پنج مقصد را می‌پذیرند اما فعلاً برای هر مقصد هندسه پیش‌فرض گودو را می‌سازند (اعمال transformهای مقصد در مسیر Node هنوز وصل نشده است؛ `target` در `buildMeshGlb` رد می‌شود و یادداشت محدودیت در `TARGET_NOTE` و فیلد `targetNote` و `mcp/README.md` آمده است). این مورد در برنامه به‌عنوان کار جداگانه تعریف نشده بود؛ به‌عنوان پیگیری پیشنهادی ثبت می‌شود، نه نقص این تغییر.
- **نتیجه:** ✅ انجام شد (با محدودیت بالا).

### F-31 — سرور MCP در `mcp/`
- **فایل‌ها:** `mcp/server.ts` (bootstrap با همان الگوی resolve-hook)، `mcp/server-main.ts` (۴ ابزار)، `mcp/README.md` (کانفیگ Claude Desktop و Cursor + دستور تست JSON-RPC خام)، `package.json` (افزودن `@modelcontextprotocol/sdk@^1.32.2` و `zod@^4.6.7`).
- **تغییر:** transport روی stdio؛ ابزارها `build_mesh`، ‏`optimize_glb`، ‏`validate_mesh`، ‏`list_targets` — همه از `lib/node-shim.ts` + هسته موتور استفاده می‌کنند، بدون تکرار کد مش.
- **تست عملی:** پروب SDK Client + StdioClientTransport و تبادل JSON-RPC خام: ‏`tools/list` ← ‏`['build_mesh', 'optimize_glb', 'validate_mesh', 'list_targets']`؛ ‏`validate_mesh` روی GLB ساخته‌شده با CLI ← ‏`valid: true, triangles 15332, vertices 7668, meshes 1, materials 1, textures 3`؛ ‏`build_mesh` از طریق MCP یک GLB بایت‌به‌بایت یکسان ساخت (۴۷۶۰۳۲ بایت)؛ ‏`optimize_glb` ← ‏`inputBytes 476032, outputBytes 476032` (از قبل بهینه بود).
- **نتیجه:** ✅ انجام شد.

### F-32 — رجیستری مقصدها `lib/targets.ts`
- **فایل:** `lib/targets.ts` (جدید، ۱۱ کیلوبایت).
- **تغییر:** `EXPORT_TARGETS` با پنج مقصد godot/unity/unreal/blender/generic — هر یک با id، label (انگلیسی+فارسی)، unit، unitScale، flipNormalGreen، texturePacking، collisionNaming (style/value/note انگلیسی+فارسی)، scriptKind، scriptFileName و readmeBlurb؛ `getExportTarget()` برای id ناشناخته به godot برمی‌گردد.
- **تست تئوری:** رجیستری داده خالص است؛ تست واحد محتوای هر مقصد را می‌سنجد.
- **تست عملی:** `npm test` — ۱۳ تست در `lib/__tests__/targets.test.ts` پاس شد.
- **نتیجه:** ✅ انجام شد.

### F-33 — مقیاس واحد هر مقصد
- **فایل‌ها:** `lib/targets.ts` (آنریل `unit: 'cm', unitScale: 100`، بقیه `unit: 'm', unitScale: 1`)، `lib/godotExport.ts` (`prepareExportGroup()` مقیاس را در هندسه کلون‌شده می‌پزد — رأس‌های خروجی واقعاً سانتی‌مترند، نه فقط transform گره).
- **تست عملی:** تست واحد: max-X آنریل ۰٫۷ متر ← ۷۰ بعد از پخت؛ یونیتی ۰٫۷ می‌ماند.
- **نتیجه:** ✅ انجام شد.

### F-34 — فلیپ کانال سبز نرمال‌مپ برای آنریل
- **فایل‌ها:** `lib/targets.ts` (`flipNormalMapGreenChannel()` خالص: G‏ = 255−G، ورودی دست‌نخورده، خودمعکوس)؛ فقط وقتی `unreal.flipNormalGreen === true` اعمال می‌شود.
- **تست عملی:** تست واحد (خودمعکوس + عدم تغییر ورودی) پاس شد. توجه: فلیپ فقط روی PNG نرمال داخل ZIP اعمال می‌شود؛ نرمال‌مپ داخل GLB همان OpenGL استاندارد می‌ماند (تغییر آن نیاز به بازنویسی بافت با gltf-transform داشت — خارج از محدوده این گروه).
- **نتیجه:** ✅ انجام شد.

### F-35 — بافت packed متالیک+smoothness برای یونیتی
- **فایل‌ها:** `lib/targets.ts` (`packUnityMetallicSmoothness()`: ‏R = metallic، ‏G/B = 0، ‏A = smoothness = ۱ − roughness)؛ ZIP یونیتی شامل `<Name>_MetallicSmoothness.png` است؛ وقتی بافت نیست، از مقادیر اسکالر `settings.metalness`/`roughness` استفاده می‌شود.
- **تست عملی:** تست واحد: metal ‏۲۵۵ + rough ‏۶۴ ← `[255, 0, 0, 191]` پاس شد.
- **نتیجه:** ✅ انجام شد.

### F-36 — نام‌گذاری کالایژن هر مقصد
- **فایل‌ها:** `lib/targets.ts` و `lib/godotExport.ts` (`targetCollisionMeshName`)؛ گودو `-col` را حفظ می‌کند؛ آنریل پیشوند `UCX_` می‌گیرد (در رجیستری و README ثبت شد که فقط برای مسیر FBX است — ایمپورت glTF کالایژن سفارشی حمل نمی‌کند)؛ یونیتی هیچ قرارداد نام‌گذاری ندارد (در ادیتور MeshCollider اضافه شود، Convex برای Rigidbody متحرک)؛ بلندر هم ندارد (کالایژن خاصیت فیزیک است، نه نام).
- **تست عملی:** تست واحد نام‌گذاری پاس شد.
- **نتیجه:** ✅ انجام شد.

### F-37 — ژنراتور اسکریپت C# یونیتی
- **فایل:** `lib/godotExport.ts` (`generateUnityCSharpScript()`).
- **تغییر:** `MonoBehaviour` با `[RequireComponent(typeof(MeshCollider))]`، چرخش turntable با `spinSpeed`، ‏`pickupOnClick` و `PickUp()` (غیرفعال‌کردن کالایدر و حذف با تأخیر)، یادداشت نصب glTFast با آدرس git؛ نام کلاس با نام فایل `<Name>Controller.cs` یکی است.
- **تست عملی:** تست واحد محتوای اسکریپت در `lib/__tests__/godotExport.test.ts` پاس شد.
- **نتیجه:** ✅ انجام شد.

### F-38 — ژنراتور اسکریپت پایتون ادیتور آنریل
- **فایل:** `lib/godotExport.ts` (`generateUnrealPythonScript()`).
- **تغییر:** ایمپورت GLB با `AssetImportTask`، یافتن StaticMesh از AssetRegistry، ساخت اکتور در لول فعلی با `spawn_actor_from_object`، یادداشت مقیاس cm و یادداشت کالایژن UCX_/FBX.
- **تست عملی:** فقط `python3 -m py_compile` چک شد — آنریل انجین در این VM نصب نیست، پس داخل ادیتور اجرا نشده است (نیاز به بررسی زنده با آنریل دارد).
- **نتیجه:** ✅ انجام شد (با قید بالا).

### F-39 — ژنراتور اسکریپت پایتون بلندر
- **فایل:** `lib/godotExport.ts` (`generateBlenderPythonScript()`).
- **تغییر:** پاک‌سازی صحنه، `bpy.ops.import_scene.gltf`، اتصال بافت‌های Albedo/Normal/Roughness/Metalness به Principled BSDF (sRGB در برابر Non-Color)، turntable با empty (۰ تا ۳۶۰ درجه در فریم‌های ۱ تا ۱۲۰)، دوربین tracking، ‏EEVEE با fallback.
- **تست عملی:** بلندر ۵٫۳٫۰ headless با `akm_trellis_clean.glb`: ‏exit 0، ‏`BLENDER_SETUP_OK AKM_Test (2 objects, 120-frame turntable)`؛ بازرسی صحنه: ریگ `Turntable_AKM_Test`، چرخش ۰ درجه در فریم ۱ ← ۳۶۰ درجه در فریم ۱۲۰، دوربین موجود، بازه فریم ۱–۱۲۰. هر دو اسکریپت (آنریل و بلندر) `python3 -m py_compile` را پاس کردند.
- **یادداشت:** انتساب `BLENDER_EEVEE_NEXT` در بلندر ۵٫۳٫۰ خطا می‌دهد و fallback داخلی به `BLENDER_EEVEE` فعال می‌شود — تأییدشده و نیاز به تغییر ندارد.
- **نتیجه:** ✅ انجام شد.

### F-40 — انتخاب‌گر مقصد در UI + خروجی ZIP هر مقصد
- **فایل‌ها:** `components/StudioWorkspace.tsx` (سکشن انتخاب‌گر با ۵ دکمه + واحد + یادداشت‌های فارسی واردات/کالایژن، دقیقاً قبل از کارت اعتبارسنجی؛ دکمه ZIP بعد از دکمه GLB)، `lib/godotExport.ts` (`exportTargetZip()`)، `package.json` (افزودن `jszip@^3.10.2`).
- **تغییر:** ZIP به نام `<Name>_<target>.zip` شامل GLB + بافت‌های آن مقصد + اسکریپت + README.md؛ ZIP گودو/generic دقیقاً همان GLB دانلود تکی را دارد.
- **تست عملی:** `npm test` ‏۳۱/۳۱؛ بیلد موفق؛ `vite preview` ‏HTTP 200.
- **نتیجه:** ✅ انجام شد.

### F-41 — خروجی STL و PLY
- **فایل‌ها:** `lib/godotExport.ts` (`exportMeshFormat()` با `STLExporter` به‌صورت ASCII و `PLYExporter` به‌صورت ASCII با Promise)، `components/StudioWorkspace.tsx` (دو دکمه در گرید دانلود).
- **تغییر:** فقط هندسه، واحد متر، معنای live-group (مثل دکمه‌های GLB تکی — مقصد روی آن‌ها اعمال نمی‌شود؛ ZIP مصنوعتِ هر مقصد است).
- **تست عملی:** `npm test` ‏۳۱/۳۱؛ `npx tsc --noEmit` تمیز؛ `npm run lint` تمیز.
- **نتیجه:** ✅ انجام شد.
