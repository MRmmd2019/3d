'use client';

import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { motion } from 'motion/react';
import {
  AlertCircle,
  AlertTriangle,
  Box,
  Check,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  Code2,
  Copy,
  Download,
  Eye,
  FileCode,
  FolderDown,
  FolderOpen,
  ImagePlus,
  Layers,
  RotateCcw,
  Save,
  ShieldCheck,
  Trash2,
  Upload,
} from 'lucide-react';
import Viewport3D, { type ExportGroupHandle } from './Viewport3D';
import PrecisionControl from './PrecisionControl';
import {
  DEFAULT_MESH_SETTINGS,
  DEFAULT_POLISH_PROFILE,
  EMPTY_VALIDATION,
  sanitizeAsciiNodeName,
  type GeneratedTexturesPreview,
  type MeshBuildSettings,
  type MeshPolishProfile,
  type MeshStats,
  type TextureResolution,
} from '@/lib/meshTypes';
import {
  exportMeshFormat,
  exportTargetZip,
  exportThreeGroup,
  generateTargetScript,
  type ExportFormat,
  type MeshExportFormat,
} from '@/lib/godotExport';
import { EXPORT_TARGETS, getExportTarget } from '@/lib/targets';
import {
  deletePreset,
  deleteProject,
  listPresets,
  listProjects,
  loadStoredSettings,
  mergeStoredSettings,
  savePreset,
  saveProject,
  saveStoredSettings,
  type StoredPreset,
  type StoredProject,
} from '@/lib/persistence';
import {
  pickPhotoDirectory,
  saveGlbToFolder,
  supportsFileSystemAccess,
} from '@/lib/fileSystemAccess';

type StudioTab = 'polish' | 'geometry' | 'materials' | 'export';

export default function StudioWorkspace() {
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const backFileInputRef = useRef<HTMLInputElement | null>(null);
  const exportGetterRef = useRef<(() => Promise<ExportGroupHandle | null>) | null>(null);

  const [activeTab, setActiveTab] = useState<StudioTab>('polish');
  // F-25: settings load from localStorage on startup (defaults when absent/corrupt).
  const [settings, setSettings] = useState<MeshBuildSettings>(
    () => loadStoredSettings() ?? DEFAULT_MESH_SETTINGS
  );

  // F-26: presets & projects (IndexedDB) — loaded once on mount.
  const [presets, setPresets] = useState<StoredPreset[]>([]);
  const [projects, setProjects] = useState<StoredProject[]>([]);
  const [presetName, setPresetName] = useState('');

  // F-27: batch photo folder (File System Access API) — null when unsupported.
  const [fsaSupported] = useState(() => supportsFileSystemAccess());
  const [batchFiles, setBatchFiles] = useState<File[]>([]);
  const [batchIndex, setBatchIndex] = useState(0);

  const [sourceImageUrl, setSourceImageUrl] = useState<string | null>(null);
  const [backImageUrl, setBackImageUrl] = useState<string | null>(null);
  const [showCutoutPreview, setShowCutoutPreview] = useState(false);
  const [isDragging, setIsDragging] = useState(false);

  const [stats, setStats] = useState<MeshStats>({
    meshCount: 0,
    triangleCount: 0,
    vertexCount: 0,
    materialCount: 0,
    foregroundCoveragePct: 0,
    metallicSurfacePct: 0,
    hasBackImage: false,
    textureResolution: '—',
    polishActive: false,
    boundsMeters: { width: 0, height: 0, depth: 0 },
    validation: EMPTY_VALIDATION,
  });

  const [previews, setPreviews] = useState<GeneratedTexturesPreview>({
    cutoutMaskUrl: '',
    normalMapUrl: '',
    roughnessMapUrl: '',
    metalnessMapUrl: '',
  });

  const [isBuilding, setIsBuilding] = useState(false);
  const [isExporting, setIsExporting] = useState<ExportFormat | MeshExportFormat | 'zip' | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [statusNotice, setStatusNotice] = useState<string | null>(null);
  const [copiedScript, setCopiedScript] = useState(false);

  const updateSetting = <K extends keyof MeshBuildSettings>(
    key: K,
    value: MeshBuildSettings[K]
  ) => {
    setSettings((prev) => ({ ...prev, [key]: value }));
  };

  const updatePolish = <K extends keyof MeshPolishProfile>(
    key: K,
    value: MeshPolishProfile[K]
  ) => {
    setSettings((prev) => ({
      ...prev,
      polish: { ...prev.polish, [key]: value },
    }));
  };

  const handleStatsChange = useCallback(
    (nextStats: MeshStats, nextPreviews: GeneratedTexturesPreview) => {
      setStats(nextStats);
      setPreviews(nextPreviews);
    },
    []
  );

  const handleExportGroupReady = useCallback(
    (getter: () => Promise<ExportGroupHandle | null>) => {
      exportGetterRef.current = getter;
    },
    []
  );

  const loadFile = useCallback((file: File, target: 'front' | 'back' = 'front') => {
    if (!file.type.startsWith('image/')) {
      setErrorMessage('لطفاً فقط فایل تصویری (PNG، JPG یا WebP) انتخاب کنید.');
      return;
    }
    setErrorMessage(null);
    setStatusNotice(null);

    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = String(reader.result);
      if (target === 'back') {
        setBackImageUrl(dataUrl);
        setStatusNotice('تصویر پشت مدل اضافه شد و نقشه عمق + بافت پشت به‌صورت مجزا بازسازی شد.');
        return;
      }

      const baseName = sanitizeAsciiNodeName(
        file.name.replace(/\.[^/.]+$/, ''),
        'CustomAsset_3D'
      );
      setSettings((prev) => ({
        ...prev,
        assetName: baseName,
        polish: DEFAULT_POLISH_PROFILE,
      }));
      setSourceImageUrl(dataUrl);
    };
    reader.readAsDataURL(file);
  }, []);

  useEffect(() => {
    const onPaste = (e: ClipboardEvent) => {
      const items = e.clipboardData?.items;
      if (!items) return;
      for (const item of Array.from(items)) {
        if (item.type.startsWith('image/')) {
          const blob = item.getAsFile();
          if (blob) loadFile(blob, 'front');
          break;
        }
      }
    };
    window.addEventListener('paste', onPaste);
    return () => window.removeEventListener('paste', onPaste);
  }, [loadFile]);

  // F-25: persist settings to localStorage, debounced so slider drags
  // do not write on every tick.
  useEffect(() => {
    const timer = setTimeout(() => saveStoredSettings(settings), 400);
    return () => clearTimeout(timer);
  }, [settings]);

  // F-26: load saved presets & projects once on startup.
  useEffect(() => {
    let cancelled = false;
    void listPresets()
      .then((list) => {
        if (!cancelled) setPresets(list);
      })
      .catch(() => {
        // IndexedDB unavailable (private mode) — presets stay in-memory only.
      });
    void listProjects()
      .then((list) => {
        if (!cancelled) setProjects(list);
      })
      .catch(() => undefined);
    return () => {
      cancelled = true;
    };
  }, []);

  const handleExport = async (format: ExportFormat) => {
    if (!sourceImageUrl) {
      setErrorMessage('ابتدا یک تصویر وارد کنید تا مدل سه‌بعدی ساخته شود.');
      return;
    }
    const getter = exportGetterRef.current;
    if (!getter) {
      setErrorMessage('مدل سه‌بعدی هنوز آماده خروجی نیست.');
      return;
    }

    setErrorMessage(null);
    setStatusNotice(null);
    setIsExporting(format);
    let handle: ExportGroupHandle | null = null;
    try {
      handle = await getter();
      if (!handle) throw new Error('ساختار مش برای خروجی در دسترس نیست.');
      const byteSize = await exportThreeGroup(handle.group, settings.assetName, format, {
        optimizeGltf: settings.optimizeGltfOnExport,
        webpTextures: settings.webpTextures,
      });
      const kb = Math.max(1, Math.round(byteSize / 1024));
      setStatusNotice(
        `فایل ${sanitizeAsciiNodeName(settings.assetName)}.${format} (${kb.toLocaleString('en-US')} KB) با موفقیت دانلود شد.`
      );
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'خطا در خروجی گرفتن فایل سه‌بعدی';
      setErrorMessage(msg);
    } finally {
      handle?.cleanup();
      setIsExporting(null);
    }
  };

  // F-26: presets (settings snapshot + name) in IndexedDB.
  const handleSavePreset = async () => {
    setErrorMessage(null);
    try {
      const preset = await savePreset(presetName || settings.assetName, settings);
      setPresets((prev) => [preset, ...prev]);
      setPresetName('');
      setStatusNotice(`پرست «${preset.name}» ذخیره شد.`);
    } catch {
      setErrorMessage('ذخیره پرست ناموفق بود — مرورگر اجازه ذخیره‌سازی محلی نمی‌دهد.');
    }
  };

  const handleApplyPreset = (preset: StoredPreset) => {
    setSettings(mergeStoredSettings(preset.settings));
    setStatusNotice(`پرست «${preset.name}» اعمال شد.`);
  };

  const handleDeletePreset = async (id: string) => {
    try {
      await deletePreset(id);
      setPresets((prev) => prev.filter((p) => p.id !== id));
    } catch {
      setErrorMessage('حذف پرست ناموفق بود.');
    }
  };

  // F-26: projects (settings + thumbnail) in IndexedDB.
  const handleSaveProject = async () => {
    setErrorMessage(null);
    try {
      const project = await saveProject(
        settings.assetName,
        settings,
        previews.cutoutMaskUrl || sourceImageUrl
      );
      setProjects((prev) => [project, ...prev]);
      setStatusNotice(`پروژه «${project.name}» با تنظیمات و بندانگشتی ذخیره شد.`);
    } catch {
      setErrorMessage('ذخیره پروژه ناموفق بود — مرورگر اجازه ذخیره‌سازی محلی نمی‌دهد.');
    }
  };

  const handleApplyProject = (project: StoredProject) => {
    setSettings(mergeStoredSettings(project.settings));
    setStatusNotice(
      `تنظیمات پروژه «${project.name}» اعمال شد. تصویر اصلی را دوباره وارد کنید.`
    );
  };

  const handleDeleteProject = async (id: string) => {
    try {
      await deleteProject(id);
      setProjects((prev) => prev.filter((p) => p.id !== id));
    } catch {
      setErrorMessage('حذف پروژه ناموفق بود.');
    }
  };

  // F-27: open a folder of photos for batch processing.
  const handleOpenPhotoFolder = async () => {
    setErrorMessage(null);
    try {
      const files = await pickPhotoDirectory();
      if (!files) {
        if (!fsaSupported) {
          setErrorMessage('مرورگر شما انتخاب پوشه را پشتیبانی نمی‌کند؛ از دکمه انتخاب تصویر استفاده کنید.');
        }
        return;
      }
      if (files.length === 0) {
        setStatusNotice('در پوشه انتخاب‌شده عکسی پیدا نشد.');
        return;
      }
      setBatchFiles(files);
      setBatchIndex(0);
      loadFile(files[0], 'front');
      setStatusNotice(
        `پوشه باز شد: ${files.length.toLocaleString('en-US')} عکس — با دکمه‌های «بعدی / قبلی» بین عکس‌ها جابه‌جا شوید.`
      );
    } catch {
      setErrorMessage('باز کردن پوشه ناموفق بود.');
    }
  };

  const handleBatchStep = (direction: 1 | -1) => {
    if (batchFiles.length === 0) return;
    const next = (batchIndex + direction + batchFiles.length) % batchFiles.length;
    setBatchIndex(next);
    loadFile(batchFiles[next], 'front');
  };

  // F-27: save the GLB directly into a picked folder (normal download fallback).
  const handleSaveGlbToFolder = async () => {
    if (!sourceImageUrl) {
      setErrorMessage('ابتدا یک تصویر وارد کنید تا مدل سه‌بعدی ساخته شود.');
      return;
    }
    const getter = exportGetterRef.current;
    if (!getter) {
      setErrorMessage('مدل سه‌بعدی هنوز آماده خروجی نیست.');
      return;
    }

    setErrorMessage(null);
    setStatusNotice(null);
    setIsExporting('glb');
    let handle: ExportGroupHandle | null = null;
    try {
      handle = await getter();
      if (!handle) throw new Error('ساختار مش برای خروجی در دسترس نیست.');
      const result = await saveGlbToFolder(handle.group, settings.assetName, {
        optimizeGltf: settings.optimizeGltfOnExport,
      });
      const fileName = `${sanitizeAsciiNodeName(settings.assetName)}.glb`;
      if (result === 'saved') {
        setStatusNotice(`فایل ${fileName} در پوشه انتخاب‌شده ذخیره شد.`);
      } else if (result === 'downloaded') {
        setStatusNotice(
          `مرورگر ذخیره مستقیم در پوشه را پشتیبانی نمی‌کند؛ فایل ${fileName} به‌صورت معمولی دانلود شد.`
        );
      } else {
        setStatusNotice('ذخیره در پوشه لغو شد.');
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'خطا در خروجی گرفتن فایل سه‌بعدی';
      setErrorMessage(msg);
    } finally {
      handle?.cleanup();
      setIsExporting(null);
    }
  };

  const handleExportMesh = async (format: MeshExportFormat) => {
    if (!sourceImageUrl) {
      setErrorMessage('ابتدا یک تصویر وارد کنید تا مدل سه‌بعدی ساخته شود.');
      return;
    }
    const getter = exportGetterRef.current;
    if (!getter) {
      setErrorMessage('مدل سه‌بعدی هنوز آماده خروجی نیست.');
      return;
    }

    setErrorMessage(null);
    setStatusNotice(null);
    setIsExporting(format);
    let handle: ExportGroupHandle | null = null;
    try {
      handle = await getter();
      if (!handle) throw new Error('ساختار مش برای خروجی در دسترس نیست.');
      const byteSize = await exportMeshFormat(handle.group, settings.assetName, format);
      const kb = Math.max(1, Math.round(byteSize / 1024));
      setStatusNotice(
        `فایل ${sanitizeAsciiNodeName(settings.assetName)}.${format} (${kb.toLocaleString('en-US')} KB) با موفقیت دانلود شد.`
      );
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'خطا در خروجی گرفتن فایل سه‌بعدی';
      setErrorMessage(msg);
    } finally {
      handle?.cleanup();
      setIsExporting(null);
    }
  };

  const handleExportZip = async () => {
    if (!sourceImageUrl) {
      setErrorMessage('ابتدا یک تصویر وارد کنید تا مدل سه‌بعدی ساخته شود.');
      return;
    }
    const getter = exportGetterRef.current;
    if (!getter) {
      setErrorMessage('مدل سه‌بعدی هنوز آماده خروجی نیست.');
      return;
    }

    const target = getExportTarget(settings.exportTarget);
    setErrorMessage(null);
    setStatusNotice(null);
    setIsExporting('zip');
    let handle: ExportGroupHandle | null = null;
    try {
      handle = await getter();
      if (!handle) throw new Error('ساختار مش برای خروجی در دسترس نیست.');
      const byteSize = await exportTargetZip(handle.group, settings, stats, target.id);
      const kb = Math.max(1, Math.round(byteSize / 1024));
      setStatusNotice(
        `بسته ${sanitizeAsciiNodeName(settings.assetName)}_${target.id}.zip (${kb.toLocaleString('en-US')} KB) برای ${target.labelFa} با موفقیت دانلود شد.`
      );
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'خطا در ساخت بسته خروجی مقصد';
      setErrorMessage(msg);
    } finally {
      handle?.cleanup();
      setIsExporting(null);
    }
  };

  const targetScript = useMemo(
    () => generateTargetScript(getExportTarget(settings.exportTarget), settings, stats),
    [settings, stats]
  );

  const handleCopyScript = async () => {
    try {
      await navigator.clipboard.writeText(targetScript);
      setCopiedScript(true);
      setTimeout(() => setCopiedScript(false), 2000);
    } catch {
      setErrorMessage('امکان کپی خودکار در کلیپ‌بورد وجود ندارد.');
    }
  };

  const hasValidationWarnings =
    stats.triangleCount > 0 &&
    (!stats.validation.isWatertight ||
      stats.validation.degenerateTriangles > 0 ||
      !stats.validation.withinTriangleBudget);

  return (
    <div className="min-h-screen flex flex-col bg-[#090b0f] text-zinc-100">
      {/* Top Bar Contract: 3 exact zones */}
      <header className="h-16 px-5 lg:px-6 border-b border-zinc-800/90 bg-[#0b0e14] flex items-center justify-between gap-8 shrink-0">
        <div className="text-base sm:text-lg font-bold tracking-tight text-zinc-100 whitespace-nowrap shrink-0">
          استودیو تبدیل تصویر به مش سه‌بعدی
        </div>

        <nav className="hidden md:flex items-center gap-6 text-sm font-medium">
          <button
            type="button"
            onClick={() => setActiveTab('polish')}
            className={`py-1 transition-colors whitespace-nowrap shrink-0 cursor-pointer border-b-2 ${
              activeTab === 'polish'
                ? 'text-amber-400 border-amber-400'
                : 'text-zinc-400 border-transparent hover:text-zinc-100'
            }`}
          >
            صیقل نهایی
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('geometry')}
            className={`py-1 transition-colors whitespace-nowrap shrink-0 cursor-pointer border-b-2 ${
              activeTab === 'geometry'
                ? 'text-amber-400 border-amber-400'
                : 'text-zinc-400 border-transparent hover:text-zinc-100'
            }`}
          >
            مقیاس و مش دقیق
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('materials')}
            className={`py-1 transition-colors whitespace-nowrap shrink-0 cursor-pointer border-b-2 ${
              activeTab === 'materials'
                ? 'text-amber-400 border-amber-400'
                : 'text-zinc-400 border-transparent hover:text-zinc-100'
            }`}
          >
            بافت و متریال PBR
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('export')}
            className={`py-1 transition-colors whitespace-nowrap shrink-0 cursor-pointer border-b-2 ${
              activeTab === 'export'
                ? 'text-amber-400 border-amber-400'
                : 'text-zinc-400 border-transparent hover:text-zinc-100'
            }`}
          >
            اعتبارسنجی و خروجی گودو
          </button>
        </nav>

        <div className="flex items-center shrink-0">
          <button
            type="button"
            disabled={!sourceImageUrl || isExporting !== null || isBuilding}
            onClick={() => handleExport('glb')}
            className="flex items-center gap-2 px-4 py-2 text-xs sm:text-sm font-semibold bg-amber-500 hover:bg-amber-400 disabled:opacity-40 text-zinc-950 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>{isExporting === 'glb' ? 'در حال خروجی...' : 'دانلود GLB برای گودو'}</span>
          </button>
        </div>
      </header>

      <main className="flex-1 flex flex-col lg:flex-row min-h-0">
        {/* Sidebar Controls Panel */}
        <aside className="w-full lg:w-[420px] shrink-0 border-b lg:border-b-0 lg:border-l border-zinc-800/90 bg-[#0d1017] flex flex-col max-h-none lg:h-[calc(100vh-64px)] overflow-y-auto">
          {/* Mobile Tab Selector */}
          <div className="flex md:hidden items-center gap-1 p-2 border-b border-zinc-800 bg-[#0b0e14]">
            {(
              [
                ['polish', 'صیقل'],
                ['geometry', 'مش و مقیاس'],
                ['materials', 'متریال PBR'],
                ['export', 'خروجی'],
              ] as const
            ).map(([tab, label]) => (
              <button
                key={tab}
                type="button"
                onClick={() => setActiveTab(tab)}
                className={`flex-1 py-2 px-1.5 text-[11px] font-medium rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                  activeTab === tab
                    ? 'bg-zinc-800 text-amber-400'
                    : 'text-zinc-400 hover:text-zinc-200'
                }`}
              >
                {label}
              </button>
            ))}
          </div>

          <div className="p-5 space-y-5 flex-1">
            {errorMessage && (
              <div className="flex items-start gap-2.5 p-3 rounded-lg bg-red-950/50 border border-red-800/70 text-red-200 text-xs leading-relaxed">
                <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                <span>{errorMessage}</span>
              </div>
            )}

            {statusNotice && !errorMessage && (
              <div className="flex items-start gap-2.5 p-3 rounded-lg bg-emerald-950/40 border border-emerald-800/60 text-emerald-200 text-xs leading-relaxed">
                <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>{statusNotice}</span>
              </div>
            )}

            {/* Primary Front Image + Optional Back View Image Uploader */}
            <section className="space-y-2.5">
              <div className="flex items-center justify-between">
                <h2 className="text-sm font-semibold text-zinc-100">تصویر ورودی (نمای جلو)</h2>
                <div className="flex items-center gap-2">
                  {sourceImageUrl && previews.cutoutMaskUrl && (
                    <button
                      type="button"
                      onClick={() => setShowCutoutPreview((v) => !v)}
                      className={`flex items-center gap-1 text-[11px] px-2 py-0.5 rounded border cursor-pointer transition-colors ${
                        showCutoutPreview
                          ? 'border-amber-500/60 text-amber-300 bg-amber-500/10'
                          : 'border-zinc-700 text-zinc-400 hover:text-zinc-200'
                      }`}
                    >
                      <Eye className="w-3 h-3" />
                      <span>{showCutoutPreview ? 'نمایش عکس اصلی' : 'نمایش ماسک برش'}</span>
                    </button>
                  )}
                  {sourceImageUrl && (
                    <button
                      type="button"
                      onClick={() => {
                        setSourceImageUrl(null);
                        setBackImageUrl(null);
                        setStatusNotice(null);
                        setSettings(DEFAULT_MESH_SETTINGS);
                      }}
                      className="text-[11px] text-zinc-400 hover:text-zinc-200 cursor-pointer"
                    >
                      حذف تصویر
                    </button>
                  )}
                </div>
              </div>

              <div
                onDragOver={(e) => {
                  e.preventDefault();
                  setIsDragging(true);
                }}
                onDragLeave={() => setIsDragging(false)}
                onDrop={(e) => {
                  e.preventDefault();
                  setIsDragging(false);
                  const dropped = e.dataTransfer.files?.[0];
                  if (dropped) loadFile(dropped, 'front');
                }}
                onClick={() => fileInputRef.current?.click()}
                className={`relative rounded-xl border border-dashed transition-colors cursor-pointer overflow-hidden ${
                  isDragging
                    ? 'border-amber-400 bg-amber-500/10'
                    : 'border-zinc-700 hover:border-zinc-500 bg-zinc-900/50'
                }`}
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/png,image/jpeg,image/webp"
                  className="hidden"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) loadFile(file, 'front');
                  }}
                />

                {sourceImageUrl ? (
                  <div className="relative h-40 w-full flex items-center justify-center bg-[#090b0f] p-2.5">
                    <img
                      src={
                        showCutoutPreview && previews.cutoutMaskUrl
                          ? previews.cutoutMaskUrl
                          : sourceImageUrl
                      }
                      alt="تصویر مرجع کاربر"
                      referrerPolicy="no-referrer"
                      className="max-h-full max-w-full object-contain rounded"
                    />
                    <div className="absolute bottom-2 left-2 px-2.5 py-1 rounded-md bg-zinc-900/95 border border-zinc-700 text-[11px] text-zinc-200 flex items-center gap-1.5">
                      <Upload className="w-3 h-3" />
                      <span>تغییر تصویر</span>
                    </div>
                  </div>
                ) : (
                  <div className="h-36 flex flex-col items-center justify-center px-4 text-center">
                    <ImagePlus className="w-8 h-8 text-zinc-400 mb-2" />
                    <p className="text-xs font-medium text-zinc-200">
                      عکس خود را اینجا رها کنید یا کلیک کنید
                    </p>
                    <p className="text-[11px] text-zinc-500 mt-1">
                      پشتیبانی از PNG / JPG / WebP و چسباندن با Ctrl+V
                    </p>
                  </div>
                )}
              </div>

              {/* Optional Second Back-View Image Slot */}
              {sourceImageUrl && settings.mode !== 'lathe' && (
                <div className="pt-1">
                  <input
                    ref={backFileInputRef}
                    type="file"
                    accept="image/png,image/jpeg,image/webp"
                    className="hidden"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) loadFile(file, 'back');
                    }}
                  />

                  {backImageUrl ? (
                    <div className="flex items-center justify-between gap-3 p-2 rounded-lg bg-zinc-950 border border-zinc-800">
                      <div className="flex items-center gap-2.5 min-w-0">
                        <img
                          src={backImageUrl}
                          alt="نمای پشت مدل"
                          className="w-10 h-10 object-cover rounded border border-zinc-800 shrink-0"
                        />
                        <div className="min-w-0">
                          <div className="text-xs font-medium text-zinc-200 truncate">
                            تصویر پشت مدل فعال
                          </div>
                          <div className="text-[11px] text-zinc-500">
                            بافت و عمق پشت مجزا از جلو
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        <button
                          type="button"
                          onClick={() => backFileInputRef.current?.click()}
                          className="text-[11px] text-amber-400 hover:text-amber-300 cursor-pointer"
                        >
                          تغییر
                        </button>
                        <button
                          type="button"
                          onClick={() => setBackImageUrl(null)}
                          className="text-[11px] text-zinc-500 hover:text-zinc-300 cursor-pointer"
                        >
                          حذف
                        </button>
                      </div>
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={() => backFileInputRef.current?.click()}
                      className="w-full py-2 px-3 rounded-lg border border-dashed border-zinc-800 hover:border-zinc-600 bg-zinc-950/60 text-xs text-zinc-400 hover:text-zinc-200 flex items-center justify-center gap-2 transition-colors cursor-pointer"
                    >
                      <ImagePlus className="w-3.5 h-3.5" />
                      <span>افزودن عکس دوم برای پشت مدل (اختیاری)</span>
                    </button>
                  )}
                </div>
              )}
            </section>

            {/* F-27: batch photo folder (File System Access API, graceful fallback) */}
            {fsaSupported && (
              <section className="space-y-2">
                <button
                  type="button"
                  onClick={handleOpenPhotoFolder}
                  className="w-full py-2 px-3 rounded-lg border border-dashed border-zinc-800 hover:border-zinc-600 bg-zinc-950/60 text-xs text-zinc-400 hover:text-zinc-200 flex items-center justify-center gap-2 transition-colors cursor-pointer"
                >
                  <FolderOpen className="w-3.5 h-3.5" />
                  <span>باز کردن پوشه عکس‌ها برای پردازش دسته‌ای</span>
                </button>

                {batchFiles.length > 0 && (
                  <div className="flex items-center justify-between gap-2 p-2 rounded-lg bg-zinc-950 border border-zinc-800">
                    <span className="text-[11px] text-zinc-400">
                      پوشه: {batchFiles.length.toLocaleString('en-US')} عکس — عکس{' '}
                      {(batchIndex + 1).toLocaleString('en-US')} از{' '}
                      {batchFiles.length.toLocaleString('en-US')}
                    </span>
                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        type="button"
                        onClick={() => handleBatchStep(-1)}
                        className="p-1.5 rounded-md bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-zinc-300 cursor-pointer"
                        aria-label="عکس قبلی"
                      >
                        <ChevronRight className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleBatchStep(1)}
                        className="p-1.5 rounded-md bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-zinc-300 cursor-pointer"
                        aria-label="عکس بعدی"
                      >
                        <ChevronLeft className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                )}
              </section>
            )}

            {/* F-26: presets & projects (IndexedDB) */}
            <section className="space-y-2.5 p-3.5 rounded-xl bg-zinc-950/70 border border-zinc-800">
              <h3 className="text-xs font-semibold text-zinc-100">پرست‌ها و پروژه‌ها</h3>

              <div className="flex gap-2">
                <input
                  type="text"
                  value={presetName}
                  onChange={(e) => setPresetName(e.target.value)}
                  placeholder="نام پرست (مثلاً چوب تیره)"
                  className="flex-1 min-w-0 px-3 py-2 text-xs bg-zinc-950 border border-zinc-800 rounded-lg text-zinc-100 placeholder:text-zinc-500 focus:outline-none focus:border-amber-500"
                />
                <button
                  type="button"
                  onClick={handleSavePreset}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-zinc-200 text-xs font-medium cursor-pointer shrink-0"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>ذخیره پرست</span>
                </button>
              </div>

              {presets.length > 0 && (
                <ul className="space-y-1.5">
                  {presets.map((preset) => (
                    <li
                      key={preset.id}
                      className="flex items-center justify-between gap-2 p-2 rounded-lg bg-zinc-900 border border-zinc-800"
                    >
                      <button
                        type="button"
                        onClick={() => handleApplyPreset(preset)}
                        className="text-xs text-zinc-200 hover:text-amber-300 truncate cursor-pointer text-right"
                      >
                        {preset.name}
                      </button>
                      <button
                        type="button"
                        onClick={() => handleDeletePreset(preset.id)}
                        aria-label={`حذف پرست ${preset.name}`}
                        className="text-zinc-500 hover:text-rose-400 cursor-pointer shrink-0"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </li>
                  ))}
                </ul>
              )}

              <button
                type="button"
                disabled={!sourceImageUrl}
                onClick={handleSaveProject}
                className="w-full py-2 px-3 rounded-lg bg-zinc-900 hover:bg-zinc-800 disabled:opacity-40 border border-zinc-700 text-zinc-200 text-xs font-medium cursor-pointer"
              >
                ذخیره پروژه (تنظیمات + بندانگشتی)
              </button>

              {projects.length > 0 && (
                <ul className="space-y-1.5">
                  {projects.map((project) => (
                    <li
                      key={project.id}
                      className="flex items-center justify-between gap-2 p-2 rounded-lg bg-zinc-900 border border-zinc-800"
                    >
                      <button
                        type="button"
                        onClick={() => handleApplyProject(project)}
                        className="flex items-center gap-2 min-w-0 text-right cursor-pointer"
                      >
                        {project.thumbnailDataUrl && (
                          <img
                            src={project.thumbnailDataUrl}
                            alt=""
                            className="w-8 h-8 object-cover rounded border border-zinc-800 shrink-0"
                          />
                        )}
                        <span className="text-xs text-zinc-200 hover:text-amber-300 truncate">
                          {project.name}
                        </span>
                      </button>
                      <button
                        type="button"
                        onClick={() => handleDeleteProject(project.id)}
                        aria-label={`حذف پروژه ${project.name}`}
                        className="text-zinc-500 hover:text-rose-400 cursor-pointer shrink-0"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </li>
                  ))}
                </ul>
              )}

              <p className="text-[11px] text-zinc-500 leading-relaxed">
                پرست‌ها و پروژه‌ها فقط در همین مرورگر (IndexedDB) ذخیره می‌شوند؛ تنظیمات هم به‌صورت خودکار در همین مرورگر نگه داشته می‌شود.
              </p>
            </section>

            <hr className="border-zinc-800/80" />

            {/* TAB 1: Manual Final Mesh Polish (fully local, no external service) */}
            {activeTab === 'polish' && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.16 }}
                className="space-y-5"
              >
                {/* Final Mesh Polish — local Taubin / AO / clearcoat passes */}
                <section className="p-3.5 rounded-xl bg-zinc-950/70 border border-zinc-800 space-y-3">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xs font-semibold text-zinc-100">
                      صیقل نهایی و بهینه‌سازی مستقیم مش
                    </h3>
                    {settings.polish.enabled && (
                      <button
                        type="button"
                        onClick={() => updatePolish('enabled', false)}
                        className="text-[11px] text-zinc-400 hover:text-zinc-200 cursor-pointer"
                      >
                        غیرفعال
                      </button>
                    )}
                  </div>

                  <p className="text-[11px] text-zinc-400 leading-relaxed">
                    اعمال مستقیم هموارسازی حجمی Taubin، پخ لبه سیلوئت، میکرودیسپلیسمنت جزئیات، پخت سایه حفره‌ها (Cavity AO) و شفاف‌سازی شیدر PBR روی مش نهایی — همه به‌صورت محلی، بدون سرویس خارجی.
                  </p>

                  <label className="flex items-center justify-between text-xs text-zinc-300 cursor-pointer pt-1">
                    <span>فعال‌کردن صیقل نهایی</span>
                    <input
                      type="checkbox"
                      checked={settings.polish.enabled}
                      onChange={(e) => updatePolish('enabled', e.target.checked)}
                      className="accent-amber-500 w-4 h-4"
                    />
                  </label>

                  {settings.polish.enabled && (
                    <div className="pt-3 border-t border-zinc-800/80 space-y-3">
                      <PrecisionControl
                        label="گذرهای هموارسازی اضافه Taubin"
                        value={settings.polish.laplacianIterations}
                        min={0}
                        max={5}
                        step={1}
                        decimals={0}
                        onChange={(v) => updatePolish('laplacianIterations', v)}
                      />

                      <PrecisionControl
                        label="ضریب نرمی Taubin (Lambda)"
                        value={settings.polish.taubinLambda}
                        min={0.15}
                        max={0.65}
                        step={0.01}
                        decimals={2}
                        onChange={(v) => updatePolish('taubinLambda', v)}
                      />

                      <PrecisionControl
                        label="پخ و گردی لبه سیلوئت"
                        value={settings.polish.edgeBevelStrength}
                        min={0}
                        max={1}
                        step={0.02}
                        decimals={2}
                        onChange={(v) => updatePolish('edgeBevelStrength', v)}
                      />

                      <PrecisionControl
                        label="برجسته‌سازی میکرومش"
                        value={settings.polish.microDisplacement}
                        min={-0.06}
                        max={0.14}
                        step={0.005}
                        decimals={3}
                        onChange={(v) => updatePolish('microDisplacement', v)}
                      />

                      <PrecisionControl
                        label="تیزسازی بافت و نرمال"
                        value={settings.polish.detailSharpen}
                        min={0}
                        max={2}
                        step={0.05}
                        decimals={2}
                        onChange={(v) => updatePolish('detailSharpen', v)}
                      />

                      <PrecisionControl
                        label="شدت سایه حفره‌ها (Cavity AO)"
                        value={settings.polish.cavityAoIntensity}
                        min={0}
                        max={1}
                        step={0.02}
                        decimals={2}
                        onChange={(v) => updatePolish('cavityAoIntensity', v)}
                      />

                      <PrecisionControl
                        label="لایه براقیت فیزیکی (Clearcoat)"
                        value={settings.polish.clearcoat}
                        min={0}
                        max={1}
                        step={0.02}
                        decimals={2}
                        onChange={(v) => updatePolish('clearcoat', v)}
                      />
                    </div>
                  )}
                </section>
              </motion.div>
            )}

            {/* TAB 2: Precision Geometry, Real-World Scale & Triangle Budget */}
            {activeTab === 'geometry' && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.16 }}
                className="space-y-5"
              >
                <section className="space-y-2.5">
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-semibold text-zinc-100">الگوریتم ساخت مش</h3>
                    <button
                      type="button"
                      onClick={() =>
                        setSettings((prev) => ({
                          ...DEFAULT_MESH_SETTINGS,
                          assetName: prev.assetName,
                        }))
                      }
                      className="flex items-center gap-1 text-[11px] text-zinc-400 hover:text-zinc-200 cursor-pointer"
                    >
                      <RotateCcw className="w-3 h-3" />
                      <span>بازنشانی</span>
                    </button>
                  </div>

                  <div className="grid grid-cols-3 gap-1.5 p-1 rounded-lg bg-zinc-950 border border-zinc-800">
                    {(
                      [
                        ['sculpted', 'حجم‌دار 3D'],
                        ['lathe', 'چرخشی ۳۶۰°'],
                        ['voxel', 'ووکسل'],
                      ] as const
                    ).map(([mKey, mLabel]) => (
                      <button
                        key={mKey}
                        type="button"
                        onClick={() => updateSetting('mode', mKey)}
                        className={`py-2 px-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                          settings.mode === mKey
                            ? 'bg-zinc-800 text-amber-400'
                            : 'text-zinc-400 hover:text-zinc-200'
                        }`}
                      >
                        {mLabel}
                      </button>
                    ))}
                  </div>
                </section>

                {/* Real-World Scale & Triangle Budget Section */}
                <section className="space-y-3.5 p-3.5 rounded-xl bg-zinc-950/70 border border-zinc-800">
                  <h4 className="text-xs font-semibold text-amber-300">
                    مقیاس واقعی و بودجه مثلث (Godot 4)
                  </h4>

                  <PrecisionControl
                    label="عرض واقعی سوژه (Real-World Width)"
                    value={settings.targetWidthMeters}
                    min={0.05}
                    max={12.0}
                    step={0.05}
                    fineStep={0.01}
                    decimals={2}
                    unit="m"
                    onChange={(v) => updateSetting('targetWidthMeters', v)}
                  />

                  <PrecisionControl
                    label="سقف بودجه مثلث (Triangle Budget)"
                    value={settings.targetTriangleBudget}
                    min={1000}
                    max={60000}
                    step={500}
                    fineStep={250}
                    decimals={0}
                    onChange={(v) => updateSetting('targetTriangleBudget', v)}
                  />

                  <label className="flex items-center justify-between text-xs text-zinc-300 cursor-pointer pt-1">
                    <span>کاهش هوشمند مثلث تا سقف بودجه (Meshopt Decimate)</span>
                    <input
                      type="checkbox"
                      checked={settings.autoDecimate}
                      onChange={(e) => updateSetting('autoDecimate', e.target.checked)}
                      className="accent-amber-500 w-4 h-4 shrink-0"
                    />
                  </label>
                </section>

                <section className="space-y-3.5 p-3.5 rounded-xl bg-zinc-950/60 border border-zinc-800/80">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-zinc-200">
                      جداسازی سوژه از پس‌زمینه
                    </span>
                    <input
                      type="checkbox"
                      checked={settings.cutoutEnabled}
                      onChange={(e) => updateSetting('cutoutEnabled', e.target.checked)}
                      className="accent-amber-500 w-4 h-4 cursor-pointer"
                    />
                  </div>

                  {settings.cutoutEnabled && (
                    <div className="space-y-3.5 pt-1">
                      <div className="space-y-1.5">
                        <span className="text-xs text-zinc-300 block">روش برش پس‌زمینه</span>
                        <div className="grid grid-cols-2 gap-1.5" dir="ltr">
                          <button
                            type="button"
                            onClick={() => updateSetting('cutoutMethod', 'flood')}
                            className={`rounded-lg border px-2 py-1.5 text-xs ${
                              settings.cutoutMethod === 'flood'
                                ? 'border-amber-500 bg-amber-500/15 text-amber-300'
                                : 'border-zinc-800 bg-zinc-950 text-zinc-400 hover:text-zinc-200'
                            }`}
                          >
                            Flood-fill (آفلاین)
                          </button>
                          <button
                            type="button"
                            onClick={() => updateSetting('cutoutMethod', 'ml')}
                            className={`rounded-lg border px-2 py-1.5 text-xs ${
                              settings.cutoutMethod === 'ml'
                                ? 'border-amber-500 bg-amber-500/15 text-amber-300'
                                : 'border-zinc-800 bg-zinc-950 text-zinc-400 hover:text-zinc-200'
                            }`}
                          >
                            ML (هوش مصنوعی)
                          </button>
                        </div>
                        {settings.cutoutMethod === 'ml' && (
                          <span className="text-[11px] text-zinc-500 block leading-relaxed">
                            مدل ML در اولین استفاده دانلود و کش می‌شود (نیازمند اینترنت)؛ در صورت
                            خطا، به‌صورت خودکار به flood-fill برمی‌گردد.
                          </span>
                        )}
                      </div>

                      {settings.cutoutMethod === 'flood' && (
                        <>
                          <PrecisionControl
                            label="حساسیت برش پس‌زمینه"
                            value={settings.cutoutTolerance}
                            min={0.03}
                            max={0.55}
                            step={0.01}
                            fineStep={0.005}
                            decimals={3}
                            onChange={(v) => updateSetting('cutoutTolerance', v)}
                          />

                          <PrecisionControl
                            label="اصلاح لبه (حذف هاله دور)"
                            value={settings.edgeErode}
                            min={0}
                            max={3}
                            step={1}
                            decimals={0}
                            unit="px"
                            onChange={(v) => updateSetting('edgeErode', v)}
                          />
                        </>
                      )}
                    </div>
                  )}
                </section>

                <section className="space-y-4">
                  <PrecisionControl
                    label="تراکم شبکه (Resolution)"
                    value={settings.resolution}
                    min={32}
                    max={192}
                    step={4}
                    fineStep={1}
                    decimals={0}
                    onChange={(v) => updateSetting('resolution', v)}
                  />

                  <PrecisionControl
                    label="هموارسازی ضدپلکانی سیلوئت (Taubin پایه)"
                    value={settings.silhouetteTaubinPasses}
                    min={0}
                    max={4}
                    step={1}
                    decimals={0}
                    onChange={(v) => updateSetting('silhouetteTaubinPasses', v)}
                  />

                  {settings.mode !== 'lathe' && (
                    <>
                      <PrecisionControl
                        label="ضخامت سه‌بعدی (Depth)"
                        value={settings.depthScale}
                        min={0.02}
                        max={1.5}
                        step={0.01}
                        fineStep={0.005}
                        decimals={3}
                        unit="m"
                        onChange={(v) => updateSetting('depthScale', v)}
                      />

                      <PrecisionControl
                        label="حجم‌دهی مرکزی (EDT Balloon)"
                        value={settings.balloonWeight}
                        min={0}
                        max={1}
                        step={0.02}
                        fineStep={0.01}
                        decimals={2}
                        onChange={(v) => updateSetting('balloonWeight', v)}
                      />

                      <PrecisionControl
                        label="برجستگی جزئیات (Detail Relief)"
                        value={settings.detailWeight}
                        min={0}
                        max={1}
                        step={0.02}
                        fineStep={0.01}
                        decimals={2}
                        onChange={(v) => updateSetting('detailWeight', v)}
                      />
                    </>
                  )}

                  {settings.mode === 'lathe' && (
                    <PrecisionControl
                      label="تعداد سگمنت چرخشی"
                      value={settings.latheSegments}
                      min={16}
                      max={64}
                      step={2}
                      fineStep={1}
                      decimals={0}
                      onChange={(v) => updateSetting('latheSegments', v)}
                    />
                  )}

                  <PrecisionControl
                    label="نرمی ارتفاع سطح (Height Smooth)"
                    value={settings.smoothPasses}
                    min={0}
                    max={6}
                    step={1}
                    decimals={0}
                    onChange={(v) => updateSetting('smoothPasses', v)}
                  />

                  <div className="space-y-2.5 pt-1">
                    {settings.mode !== 'lathe' && (
                      <>
                        <label className="flex items-center justify-between text-xs text-zinc-300 cursor-pointer">
                          <span>حجم دوطرفه متقارن (پشت و رو)</span>
                          <input
                            type="checkbox"
                            checked={settings.doubleSidedSymmetry}
                            onChange={(e) =>
                              updateSetting('doubleSidedSymmetry', e.target.checked)
                            }
                            className="accent-amber-500 w-4 h-4"
                          />
                        </label>

                        <label className="flex items-center justify-between text-xs text-zinc-300 cursor-pointer">
                          <span>معکوس کردن عمق (تیره برجسته‌تر)</span>
                          <input
                            type="checkbox"
                            checked={settings.invertDepth}
                            onChange={(e) => updateSetting('invertDepth', e.target.checked)}
                            className="accent-amber-500 w-4 h-4"
                          />
                        </label>
                      </>
                    )}

                    <div className="flex items-center justify-between pt-1">
                      <span className="text-xs text-zinc-400">محور (Pivot)</span>
                      <div className="flex items-center gap-1 bg-zinc-950 p-0.5 rounded-md border border-zinc-800">
                        <button
                          type="button"
                          onClick={() => updateSetting('pivotMode', 'bottom_center')}
                          className={`px-2.5 py-1 text-[11px] rounded cursor-pointer ${
                            settings.pivotMode === 'bottom_center'
                              ? 'bg-zinc-800 text-amber-300'
                              : 'text-zinc-400'
                          }`}
                        >
                          کف مدل (Y=0)
                        </button>
                        <button
                          type="button"
                          onClick={() => updateSetting('pivotMode', 'center')}
                          className={`px-2.5 py-1 text-[11px] rounded cursor-pointer ${
                            settings.pivotMode === 'center'
                              ? 'bg-zinc-800 text-amber-300'
                              : 'text-zinc-400'
                          }`}
                        >
                          مرکز
                        </button>
                      </div>
                    </div>
                  </div>
                </section>
              </motion.div>
            )}

            {/* TAB 3: Precision PBR Materials & Textures */}
            {activeTab === 'materials' && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.16 }}
                className="space-y-5"
              >
                <section className="space-y-4">
                  <h3 className="text-sm font-semibold text-zinc-100">
                    تفکیک متریال و رزولوشن بافت PBR
                  </h3>

                  <div className="flex items-center justify-between gap-3">
                    <span className="text-xs text-zinc-300">رزولوشن بافت‌ها</span>
                    <div className="flex items-center gap-1 bg-zinc-950 p-1 rounded-lg border border-zinc-800">
                      {([512, 1024, 2048] as TextureResolution[]).map((resOpt) => (
                        <button
                          key={resOpt}
                          type="button"
                          onClick={() => updateSetting('textureResolution', resOpt)}
                          className={`px-2.5 py-1 text-xs font-mono-code rounded-md transition-colors cursor-pointer ${
                            settings.textureResolution === resOpt
                              ? 'bg-zinc-800 text-amber-400'
                              : 'text-zinc-400 hover:text-zinc-200'
                          }`}
                        >
                          {resOpt}px
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="p-3 rounded-xl bg-zinc-950/70 border border-zinc-800 space-y-3">
                    <label className="flex items-center justify-between text-xs font-medium text-zinc-200 cursor-pointer">
                      <span>تفکیک خودکار متریال (چوب مات در برابر فلز براق)</span>
                      <input
                        type="checkbox"
                        checked={settings.autoMaterialSegmentation}
                        onChange={(e) =>
                          updateSetting('autoMaterialSegmentation', e.target.checked)
                        }
                        className="accent-amber-500 w-4 h-4 shrink-0"
                      />
                    </label>

                    {settings.autoMaterialSegmentation && (
                      <PrecisionControl
                        label="حساسیت تشخیص نواحی فلزی"
                        value={settings.materialSensitivity}
                        min={0.3}
                        max={1.5}
                        step={0.05}
                        fineStep={0.01}
                        decimals={2}
                        onChange={(v) => updateSetting('materialSensitivity', v)}
                      />
                    )}
                  </div>

                  <PrecisionControl
                    label="قدرت نرمال‌مپ (Normal Strength)"
                    value={settings.normalStrength}
                    min={0}
                    max={2.5}
                    step={0.05}
                    fineStep={0.01}
                    decimals={2}
                    onChange={(v) => {
                      updateSetting('normalStrength', v);
                      if (settings.polish.enabled) {
                        updatePolish('normalStrengthOverride', v);
                      }
                    }}
                  />

                  <PrecisionControl
                    label="زبری پایه (Base Roughness)"
                    value={settings.roughness}
                    min={0.05}
                    max={1}
                    step={0.02}
                    fineStep={0.005}
                    decimals={3}
                    onChange={(v) => {
                      updateSetting('roughness', v);
                      if (settings.polish.enabled) {
                        updatePolish('roughnessOverride', v);
                      }
                    }}
                  />

                  <PrecisionControl
                    label="فلزی بودن پایه (Base Metalness)"
                    value={settings.metalness}
                    min={0}
                    max={1}
                    step={0.02}
                    fineStep={0.005}
                    decimals={3}
                    onChange={(v) => {
                      updateSetting('metalness', v);
                      if (settings.polish.enabled) {
                        updatePolish('metalnessOverride', v);
                      }
                    }}
                  />

                  <label className="flex items-center justify-between text-xs text-zinc-300 cursor-pointer pt-1">
                    <span>سایه‌زنی چندضلعی تخت (Flat Shading)</span>
                    <input
                      type="checkbox"
                      checked={settings.flatShading}
                      onChange={(e) => updateSetting('flatShading', e.target.checked)}
                      className="accent-amber-500 w-4 h-4"
                    />
                  </label>
                </section>

                <hr className="border-zinc-800/80" />

                <section className="space-y-2.5">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-semibold text-zinc-200">
                      نقشه‌های بافت تولیدشده ({stats.textureResolution})
                    </h4>
                    {stats.triangleCount > 0 && (
                      <span className="text-[11px] text-zinc-400">
                        سطح فلزی: {stats.metallicSurfacePct}%
                      </span>
                    )}
                  </div>
                  <div className="grid grid-cols-2 gap-2.5">
                    <div className="space-y-1 text-center">
                      <div className="aspect-square rounded-lg border border-zinc-800 bg-zinc-950 overflow-hidden flex items-center justify-center p-1">
                        {previews.cutoutMaskUrl && (
                          <img
                            src={previews.cutoutMaskUrl}
                            alt="Albedo Cutout"
                            className="max-w-full max-h-full object-contain"
                          />
                        )}
                      </div>
                      <span className="text-[11px] text-zinc-400 block">Albedo + Cutout</span>
                    </div>

                    <div className="space-y-1 text-center">
                      <div className="aspect-square rounded-lg border border-zinc-800 bg-zinc-950 overflow-hidden flex items-center justify-center p-1">
                        {previews.normalMapUrl && (
                          <img
                            src={previews.normalMapUrl}
                            alt="Normal Map"
                            className="max-w-full max-h-full object-contain"
                          />
                        )}
                      </div>
                      <span className="text-[11px] text-zinc-400 block">Normal Map</span>
                    </div>

                    <div className="space-y-1 text-center">
                      <div className="aspect-square rounded-lg border border-zinc-800 bg-zinc-950 overflow-hidden flex items-center justify-center p-1">
                        {previews.roughnessMapUrl && (
                          <img
                            src={previews.roughnessMapUrl}
                            alt="Roughness Map"
                            className="max-w-full max-h-full object-contain"
                          />
                        )}
                      </div>
                      <span className="text-[11px] text-zinc-400 block">Roughness Map</span>
                    </div>

                    <div className="space-y-1 text-center">
                      <div className="aspect-square rounded-lg border border-zinc-800 bg-zinc-950 overflow-hidden flex items-center justify-center p-1">
                        {previews.metalnessMapUrl && (
                          <img
                            src={previews.metalnessMapUrl}
                            alt="Metalness Map"
                            className="max-w-full max-h-full object-contain"
                          />
                        )}
                      </div>
                      <span className="text-[11px] text-zinc-400 block">Metalness Map</span>
                    </div>
                  </div>
                </section>
              </motion.div>
            )}

            {/* TAB 4: Pre-Export Validation, Godot Export & GDScript */}
            {activeTab === 'export' && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.16 }}
                className="space-y-5"
              >
                <section className="space-y-3">
                  <label className="block space-y-1.5">
                    <span className="text-xs font-medium text-zinc-300">
                      نام نود و فایل خروجی (انگلیسی)
                    </span>
                    <input
                      type="text"
                      dir="ltr"
                      value={settings.assetName}
                      onChange={(e) => updateSetting('assetName', e.target.value)}
                      className="w-full px-3 py-2 text-xs font-mono-code bg-zinc-950 border border-zinc-800 rounded-lg text-zinc-100 focus:outline-none focus:border-amber-500"
                    />
                  </label>

                  <label className="flex items-start gap-2.5 p-3 rounded-lg bg-zinc-950 border border-zinc-800 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settings.godotCollisionSuffix}
                      onChange={(e) =>
                        updateSetting('godotCollisionSuffix', e.target.checked)
                      }
                      className="mt-0.5 accent-amber-500 w-4 h-4 shrink-0"
                    />
                    <div className="space-y-0.5">
                      <span className="text-xs font-medium text-zinc-200 block">
                        افزودن خودکار پسوند برخورد گودو (<span className="font-mono-code text-amber-400">-col</span>)
                      </span>
                      <span className="text-[11px] text-zinc-500 block leading-relaxed">
                        گودو هنگام ایمپورت فایل GLB به‌صورت خودکار StaticBody3D و CollisionShape3D می‌سازد.
                      </span>
                    </div>
                  </label>

                  <label className="flex items-start gap-2.5 p-3 rounded-lg bg-zinc-950 border border-zinc-800 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settings.optimizeGltfOnExport}
                      onChange={(e) =>
                        updateSetting('optimizeGltfOnExport', e.target.checked)
                      }
                      className="mt-0.5 accent-amber-500 w-4 h-4 shrink-0"
                    />
                    <div className="space-y-0.5">
                      <span className="text-xs font-medium text-zinc-200 block">
                        بهینه‌سازی باینری <span className="font-mono-code text-amber-400" dir="ltr">glTF-Transform</span>
                      </span>
                      <span className="text-[11px] text-zinc-500 block leading-relaxed">
                        اجرای weld، dedup و prune روی فایل خروجی GLB برای حذف بافرهای تکراری.
                      </span>
                    </div>
                  </label>

                  {settings.optimizeGltfOnExport && (
                    <label className="flex items-start gap-2.5 p-3 rounded-lg bg-zinc-950 border border-zinc-800 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={settings.webpTextures}
                        onChange={(e) =>
                          updateSetting('webpTextures', e.target.checked)
                        }
                        className="mt-0.5 accent-amber-500 w-4 h-4 shrink-0"
                      />
                      <div className="space-y-0.5">
                        <span className="text-xs font-medium text-zinc-200 block">
                          فشرده‌سازی بافت‌ها با <span className="font-mono-code text-amber-400" dir="ltr">WebP</span>
                        </span>
                        <span className="text-[11px] text-zinc-500 block leading-relaxed">
                          تبدیل بافت‌ها به WebP (EXT_texture_webp)؛ Godot 4.7 آن را می‌خواند
                          (تست headless). نقشه نرمال دست‌نخورده می‌ماند.
                        </span>
                      </div>
                    </label>
                  )}
                </section>

                {/* Export target picker (F-40): Godot stays the default */}
                <section className="space-y-2">
                  <h3 className="text-sm font-semibold text-zinc-100 flex items-center gap-2">
                    <Layers className="w-4 h-4 text-amber-400" />
                    <span>مقصد خروجی</span>
                  </h3>
                  <div className="grid grid-cols-5 gap-2">
                    {EXPORT_TARGETS.map((target) => (
                      <button
                        key={target.id}
                        type="button"
                        disabled={isExporting !== null || isBuilding}
                        onClick={() => updateSetting('exportTarget', target.id)}
                        className={`p-2 rounded-lg border text-xs font-medium transition-colors cursor-pointer disabled:opacity-40 ${
                          settings.exportTarget === target.id
                            ? 'bg-amber-500/15 border-amber-500 text-amber-300'
                            : 'bg-zinc-900 border-zinc-700 text-zinc-300 hover:bg-zinc-800'
                        }`}
                      >
                        <span className="block" dir="ltr">{target.label}</span>
                        <span className="block text-[10px] text-zinc-500 mt-0.5">
                          {target.unit === 'cm' ? 'سانتی‌متر ×۱۰۰' : 'متر'}
                        </span>
                      </button>
                    ))}
                  </div>
                  <p className="text-[11px] text-zinc-500 leading-relaxed">
                    {getExportTarget(settings.exportTarget).readmeBlurbFa}
                  </p>
                  <p className="text-[11px] text-zinc-500 leading-relaxed">
                    برخورد: {getExportTarget(settings.exportTarget).collisionNaming.noteFa}
                  </p>
                </section>

                {/* Pre-Export Mesh Validation Card */}
                <section
                  className={`p-3.5 rounded-xl border space-y-2.5 ${
                    hasValidationWarnings
                      ? 'bg-rose-950/25 border-rose-800/60'
                      : 'bg-zinc-950/80 border-zinc-800'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-zinc-100 flex items-center gap-1.5">
                      {hasValidationWarnings ? (
                        <AlertTriangle className="w-4 h-4 text-rose-400" />
                      ) : (
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      )}
                      <span>اعتبارسنجی هندسه قبل از خروجی</span>
                    </span>
                    <span className="font-mono-code text-[11px] text-zinc-400">
                      {stats.textureResolution}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-y-2 gap-x-4 text-xs">
                    <div className="flex justify-between">
                      <span className="text-zinc-500">مثلث‌ها:</span>
                      <span
                        className={`font-mono-code tabular-nums ${
                          stats.validation.withinTriangleBudget
                            ? 'text-emerald-300'
                            : 'text-rose-400 font-semibold'
                        }`}
                      >
                        {stats.triangleCount.toLocaleString('en-US')}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-zinc-500">سقف بودجه:</span>
                      <span className="font-mono-code tabular-nums text-zinc-300">
                        {settings.targetTriangleBudget.toLocaleString('en-US')}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-zinc-500">لبه باز:</span>
                      <span
                        className={`font-mono-code tabular-nums ${
                          stats.validation.isWatertight
                            ? 'text-emerald-300'
                            : 'text-amber-300'
                        }`}
                      >
                        {stats.validation.openBoundaryEdges.toLocaleString('en-US')}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-zinc-500">مثلث منحط:</span>
                      <span
                        className={`font-mono-code tabular-nums ${
                          stats.validation.degenerateTriangles === 0
                            ? 'text-emerald-300'
                            : 'text-rose-300'
                        }`}
                      >
                        {stats.validation.degenerateTriangles.toLocaleString('en-US')}
                      </span>
                    </div>
                  </div>

                  {stats.validation.decimatedFromTriangles && (
                    <div className="text-[11px] text-emerald-300 pt-1 border-t border-zinc-800/80">
                      کاهش خودکار Meshopt انجام شد:{' '}
                      <span className="font-mono-code" dir="ltr">
                        {stats.validation.decimatedFromTriangles.toLocaleString('en-US')} →{' '}
                        {stats.triangleCount.toLocaleString('en-US')} tris
                      </span>
                    </div>
                  )}

                  {stats.triangleCount > 0 && !stats.validation.withinTriangleBudget && (
                    <div className="pt-2 border-t border-rose-800/40 space-y-2">
                      <p className="text-[11px] text-rose-200 leading-relaxed">
                        تعداد مثلث از سقف بودجه ({settings.targetTriangleBudget.toLocaleString('en-US')}) بیشتر است.
                      </p>
                      <button
                        type="button"
                        onClick={() => updateSetting('autoDecimate', true)}
                        className="w-full py-1.5 px-2.5 rounded-md bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/50 text-rose-100 text-[11px] font-medium cursor-pointer transition-colors"
                      >
                        کاهش خودکار مثلث به زیر سقف بودجه (Decimate)
                      </button>
                    </div>
                  )}
                </section>

                <section className="space-y-2">
                  <h3 className="text-sm font-semibold text-zinc-100 flex items-center gap-2">
                    <Box className="w-4 h-4 text-amber-400" />
                    <span>دانلود فایل نهایی</span>
                  </h3>

                  <button
                    type="button"
                    disabled={!sourceImageUrl || isExporting !== null || isBuilding}
                    onClick={() => handleExport('glb')}
                    className="w-full p-3 rounded-lg bg-amber-500 hover:bg-amber-400 disabled:opacity-40 text-zinc-950 font-semibold text-xs flex items-center justify-between transition-colors cursor-pointer"
                  >
                    <span className="flex items-center gap-2">
                      <Download className="w-4 h-4" />
                      <span>دانلود باینری glTF 2.0 (پیشنهادی گودو)</span>
                    </span>
                    <span className="font-mono-code opacity-80">.glb</span>
                  </button>

                  <button
                    type="button"
                    disabled={!sourceImageUrl || isExporting !== null || isBuilding}
                    onClick={() => handleExportZip()}
                    className="w-full p-3 rounded-lg bg-zinc-900 hover:bg-zinc-800 disabled:opacity-40 border border-amber-500/60 text-zinc-100 font-semibold text-xs flex items-center justify-between transition-colors cursor-pointer"
                  >
                    <span className="flex items-center gap-2">
                      <Download className="w-4 h-4 text-amber-400" />
                      <span>
                        {isExporting === 'zip'
                          ? 'در حال ساخت بسته...'
                          : `دانلود بسته ZIP برای ${getExportTarget(settings.exportTarget).labelFa}`}
                      </span>
                    </span>
                    <span className="font-mono-code text-amber-400 opacity-80">.zip</span>
                  </button>

                  <button
                    type="button"
                    disabled={!sourceImageUrl || isExporting !== null || isBuilding}
                    onClick={handleSaveGlbToFolder}
                    className="w-full p-2.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 disabled:opacity-40 border border-zinc-700 text-zinc-200 text-xs font-medium flex items-center justify-between transition-colors cursor-pointer"
                  >
                    <span className="flex items-center gap-2">
                      <FolderDown className="w-4 h-4" />
                      <span>ذخیره GLB در پوشه (بدون دانلود معمولی)</span>
                    </span>
                    <span className="font-mono-code text-zinc-400">.glb</span>
                  </button>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      disabled={!sourceImageUrl || isExporting !== null || isBuilding}
                      onClick={() => handleExport('gltf')}
                      className="p-2.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 disabled:opacity-40 border border-zinc-700 text-zinc-200 text-xs font-medium flex items-center justify-between transition-colors cursor-pointer"
                    >
                      <span>فایل متنی</span>
                      <span className="font-mono-code text-zinc-400">.gltf</span>
                    </button>

                    <button
                      type="button"
                      disabled={!sourceImageUrl || isExporting !== null || isBuilding}
                      onClick={() => handleExport('obj')}
                      className="p-2.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 disabled:opacity-40 border border-zinc-700 text-zinc-200 text-xs font-medium flex items-center justify-between transition-colors cursor-pointer"
                    >
                      <span>مش استاندارد</span>
                      <span className="font-mono-code text-zinc-400">.obj</span>
                    </button>

                    <button
                      type="button"
                      disabled={!sourceImageUrl || isExporting !== null || isBuilding}
                      onClick={() => handleExportMesh('stl')}
                      className="p-2.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 disabled:opacity-40 border border-zinc-700 text-zinc-200 text-xs font-medium flex items-center justify-between transition-colors cursor-pointer"
                    >
                      <span>{isExporting === 'stl' ? 'در حال خروجی...' : 'مش STL (چاپ سه‌بعدی)'}</span>
                      <span className="font-mono-code text-zinc-400">.stl</span>
                    </button>

                    <button
                      type="button"
                      disabled={!sourceImageUrl || isExporting !== null || isBuilding}
                      onClick={() => handleExportMesh('ply')}
                      className="p-2.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 disabled:opacity-40 border border-zinc-700 text-zinc-200 text-xs font-medium flex items-center justify-between transition-colors cursor-pointer"
                    >
                      <span>{isExporting === 'ply' ? 'در حال خروجی...' : 'مش PLY (ابر نقاط)'}</span>
                      <span className="font-mono-code text-zinc-400">.ply</span>
                    </button>
                  </div>
                </section>

                <section className="space-y-2">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xs font-semibold text-zinc-200 flex items-center gap-1.5">
                      <FileCode className="w-3.5 h-3.5 text-amber-400" />
                      <span>
                        {getExportTarget(settings.exportTarget).scriptKind === 'gdscript'
                          ? 'اسکریپت آماده Godot 4'
                          : getExportTarget(settings.exportTarget).scriptKind === 'csharp'
                            ? 'اسکریپت آماده Unity (C#)'
                            : getExportTarget(settings.exportTarget).scriptKind === 'unreal-python'
                              ? 'اسکریپت پایتون ادیتور Unreal'
                              : getExportTarget(settings.exportTarget).scriptKind === 'blender-python'
                                ? 'اسکریپت پایتون Blender'
                                : 'اسکریپت مقصد'}
                      </span>
                    </h3>
                    {targetScript && (
                      <button
                        type="button"
                        onClick={handleCopyScript}
                        className="flex items-center gap-1.5 px-2.5 py-1 text-xs rounded-md bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-zinc-300 cursor-pointer"
                      >
                        {copiedScript ? (
                          <>
                            <Check className="w-3.5 h-3.5 text-emerald-400" />
                            <span>کپی شد</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3.5 h-3.5" />
                            <span>کپی کد</span>
                          </>
                        )}
                      </button>
                    )}
                  </div>

                  {targetScript ? (
                    <pre
                      dir="ltr"
                      className="p-3 rounded-lg bg-zinc-950 border border-zinc-800 text-[11px] leading-relaxed text-zinc-300 font-mono-code overflow-x-auto max-h-52"
                    >
                      <code>{targetScript}</code>
                    </pre>
                  ) : (
                    <p className="p-3 rounded-lg bg-zinc-950 border border-zinc-800 text-[11px] text-zinc-400 leading-relaxed">
                      مقصد glTF عمومی اسکریپت ندارد — فایل ‎.glb به‌همراه بافت‌ها در بسته ZIP قرار می‌گیرد.
                    </p>
                  )}

                  <div className="p-3 rounded-lg bg-zinc-950/60 border border-zinc-800/80 flex items-start gap-2 text-[11px] text-zinc-400 leading-relaxed">
                    <ShieldCheck className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                    <span>
                      {settings.exportTarget === 'godot' ? (
                        <>
                          فایل <span className="font-mono-code text-zinc-200" dir="ltr">.glb</span> را در مسیر{' '}
                          <span className="font-mono-code text-amber-300" dir="ltr">res://assets/models/</span> پروژه گودو قرار دهید تا اسکریپت بدون نیاز به تغییر مسیر اجرا شود.
                        </>
                      ) : (
                        getExportTarget(settings.exportTarget).readmeBlurbFa
                      )}
                    </span>
                  </div>
                </section>
              </motion.div>
            )}
          </div>

          <div className="px-5 py-3 border-t border-zinc-800/80 bg-[#0b0e14] flex items-center justify-between text-[11px] text-zinc-500">
            <div className="flex items-center gap-2">
              <Layers className="w-3.5 h-3.5 text-zinc-500" />
              <span>مقیاس استاندارد گودو: ۱ واحد = ۱ متر</span>
            </div>
            <div className="flex items-center gap-1.5 font-mono-code" dir="ltr">
              <Code2 className="w-3.5 h-3.5" />
              <span>glTF 2.0</span>
            </div>
          </div>
        </aside>

        {/* Unobstructed 3D Viewport */}
        <section className="flex-1 relative min-h-[540px] lg:h-[calc(100vh-64px)]">
          <Viewport3D
            sourceImageUrl={sourceImageUrl}
            backImageUrl={backImageUrl}
            settings={settings}
            isBuilding={isBuilding}
            onBuildStateChange={setIsBuilding}
            onStatsChange={handleStatsChange}
            onExportGroupReady={handleExportGroupReady}
            onBuildError={setErrorMessage}
          />
        </section>
      </main>
    </div>
  );
}
