'use client';

import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import {
  Box,
  ChevronDown,
  ChevronUp,
  Grid3x3,
  RotateCw,
  Sun,
} from 'lucide-react';
import {
  EMPTY_VALIDATION,
  type CameraPreset,
  type GeneratedTexturesPreview,
  type LightingPreset,
  type MeshBuildSettings,
  type MeshStats,
  type ViewportRenderMode,
} from '@/lib/meshTypes';
import { build3DMeshFromImage, disposeObject3D } from '@/lib/meshEngine';

export interface ExportGroupHandle {
  group: THREE.Group;
  cleanup: () => void;
}

interface Viewport3DProps {
  sourceImageUrl: string | null;
  backImageUrl: string | null;
  settings: MeshBuildSettings;
  isBuilding: boolean;
  onBuildStateChange: (building: boolean) => void;
  onStatsChange: (stats: MeshStats, previews: GeneratedTexturesPreview) => void;
  onExportGroupReady: (getter: () => Promise<ExportGroupHandle | null>) => void;
  onBuildError: (msg: string | null) => void;
}

const _camTargetPos = new THREE.Vector3(2.4, 1.5, 2.7);
const _camTargetLook = new THREE.Vector3(0, 0.75, 0);

function createContactShadowTexture(): THREE.CanvasTexture {
  const size = 256;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d');
  if (ctx) {
    const grad = ctx.createRadialGradient(
      size / 2,
      size / 2,
      4,
      size / 2,
      size / 2,
      size / 2
    );
    grad.addColorStop(0, 'rgba(0, 0, 0, 0.62)');
    grad.addColorStop(0.55, 'rgba(0, 0, 0, 0.24)');
    grad.addColorStop(1, 'rgba(0, 0, 0, 0)');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, size, size);
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

const EMPTY_STATS: MeshStats = {
  meshCount: 0,
  triangleCount: 0,
  vertexCount: 0,
  materialCount: 0,
  foregroundCoveragePct: 0,
  metallicSurfacePct: 0,
  hasBackImage: false,
  textureResolution: '—',
  polishActive: false,
  boundsMeters: { width: 0, height: 0, depth: 0 },
  validation: EMPTY_VALIDATION,
};

function applyDisplayMaterialMode(
  group: THREE.Group,
  pbrMaterial: THREE.Material,
  renderMode: ViewportRenderMode,
  flatShading: boolean
): THREE.Material | null {
  let tempOverlayMat: THREE.Material | null = null;
  group.traverse((obj) => {
    if (obj instanceof THREE.Mesh) {
      if (renderMode === 'pbr') {
        obj.material = pbrMaterial;
      } else if (renderMode === 'normals') {
        tempOverlayMat = new THREE.MeshNormalMaterial({ flatShading });
        obj.material = tempOverlayMat;
      } else {
        const wireMat = pbrMaterial.clone() as THREE.MeshStandardMaterial;
        wireMat.wireframe = true;
        tempOverlayMat = wireMat;
        obj.material = tempOverlayMat;
      }
    }
  });
  return tempOverlayMat;
}

export default function Viewport3D({
  sourceImageUrl,
  backImageUrl,
  settings,
  isBuilding,
  onBuildStateChange,
  onStatsChange,
  onExportGroupReady,
  onBuildError,
}: Viewport3DProps) {
  const mountRef = useRef<HTMLDivElement | null>(null);

  const [renderMode, setRenderMode] = useState<ViewportRenderMode>('pbr');
  const [showGrid, setShowGrid] = useState(true);
  const [autoRotate, setAutoRotate] = useState(true);
  const [lighting, setLighting] = useState<LightingPreset>('studio');
  const [cameraPreset, setCameraPreset] = useState<CameraPreset>('perspective');
  const [dockCollapsed, setDockCollapsed] = useState(false);
  const [contextLost, setContextLost] = useState(false);
  const [localStats, setLocalStats] = useState<MeshStats>(EMPTY_STATS);
  const displayedStats = sourceImageUrl ? localStats : EMPTY_STATS;

  const autoRotateRef = useRef(true);
  const renderModeRef = useRef<ViewportRenderMode>('pbr');
  const camTransitionRef = useRef(false);
  const activeMeshRef = useRef<{
    group: THREE.Group;
    pbrMaterial: THREE.Material;
    overlayMaterial: THREE.Material | null;
    flatShading: boolean;
  } | null>(null);

  const sceneObjectsRef = useRef<{
    scene: THREE.Scene;
    renderer: THREE.WebGLRenderer;
    camera: THREE.PerspectiveCamera;
    controls: OrbitControls;
    modelHolder: THREE.Group;
    grid: THREE.GridHelper;
    axes: THREE.AxesHelper;
    keyLight: THREE.DirectionalLight;
    hemiLight: THREE.HemisphereLight;
    rimLight: THREE.DirectionalLight;
    contactShadow: THREE.Mesh;
    modelHeight: number;
  } | null>(null);

  useEffect(() => {
    autoRotateRef.current = autoRotate;
  }, [autoRotate]);

  useEffect(() => {
    renderModeRef.current = renderMode;
    const active = activeMeshRef.current;
    if (!active) return;
    active.overlayMaterial?.dispose();
    active.overlayMaterial = applyDisplayMaterialMode(
      active.group,
      active.pbrMaterial,
      renderMode,
      active.flatShading
    );
  }, [renderMode]);

  // Initialize Three.js WebGL scene once
  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const isSoftwareGl = (() => {
      try {
        const probe = document.createElement('canvas').getContext('webgl2');
        if (!probe) return true;
        const ext = probe.getExtension('WEBGL_debug_renderer_info');
        const param = ext ? ext.UNMASKED_RENDERER_WEBGL : probe.RENDERER;
        const gpu = String(probe.getParameter(param));
        probe.getExtension('WEBGL_lose_context')?.loseContext();
        return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
      } catch {
        return false;
      }
    })();

    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
      preserveDrawingBuffer: true,
    });
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.1;
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio || 1, 2));
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.setSize(container.clientWidth || 800, container.clientHeight || 600);
    renderer.domElement.style.display = 'block';
    renderer.domElement.style.width = '100%';
    renderer.domElement.style.height = '100%';
    container.appendChild(renderer.domElement);

    const handleContextLost = (e: Event) => {
      e.preventDefault();
      setContextLost(true);
    };
    const handleContextRestored = () => {
      setContextLost(false);
    };
    renderer.domElement.addEventListener('webglcontextlost', handleContextLost);
    renderer.domElement.addEventListener('webglcontextrestored', handleContextRestored);

    const scene = new THREE.Scene();
    scene.background = new THREE.Color('#0c0f15');
    scene.fog = new THREE.FogExp2('#0c0f15', 0.045);

    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    const envTexture = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    scene.environment = envTexture;
    pmremGenerator.dispose();

    const width = container.clientWidth || 800;
    const height = container.clientHeight || 600;
    const camera = new THREE.PerspectiveCamera(42, width / height, 0.05, 100);
    camera.position.set(2.0, 1.35, 2.2);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = !isSoftwareGl;
    controls.dampingFactor = 0.07;
    controls.target.set(0, 0.55, 0);
    controls.minDistance = 0.25;
    controls.maxDistance = 18;
    controls.maxPolarAngle = Math.PI * 0.495;
    controls.autoRotate = !isSoftwareGl;
    controls.autoRotateSpeed = 1.05;

    controls.addEventListener('start', () => {
      camTransitionRef.current = false;
    });

    const hemiLight = new THREE.HemisphereLight('#a8c7ff', '#1e222b', 0.8);
    hemiLight.position.set(0, 12, 0);
    scene.add(hemiLight);

    const keyLight = new THREE.DirectionalLight('#fff2df', 2.2);
    keyLight.position.set(4.5, 6.5, 4.5);
    keyLight.castShadow = !isSoftwareGl;
    keyLight.shadow.mapSize.width = 1024;
    keyLight.shadow.mapSize.height = 1024;
    keyLight.shadow.camera.near = 0.5;
    keyLight.shadow.camera.far = 20;
    keyLight.shadow.camera.left = -3;
    keyLight.shadow.camera.right = 3;
    keyLight.shadow.camera.top = 3;
    keyLight.shadow.camera.bottom = -3;
    keyLight.shadow.bias = -0.0005;
    keyLight.shadow.normalBias = 0.02;
    scene.add(keyLight);

    const rimLight = new THREE.DirectionalLight('#7dd3fc', 1.0);
    rimLight.position.set(-4, 3.2, -4.5);
    scene.add(rimLight);

    const grid = new THREE.GridHelper(10, 20, '#364152', '#1d232e');
    grid.position.y = 0;
    scene.add(grid);

    const axes = new THREE.AxesHelper(1.0);
    axes.position.y = 0.004;
    scene.add(axes);

    const shadowTex = createContactShadowTexture();
    const contactShadow = new THREE.Mesh(
      new THREE.PlaneGeometry(2.6, 2.6),
      new THREE.MeshBasicMaterial({
        map: shadowTex,
        transparent: true,
        depthWrite: false,
        opacity: 0.72,
      })
    );
    contactShadow.rotation.x = -Math.PI / 2;
    contactShadow.position.y = 0.002;
    scene.add(contactShadow);

    const modelHolder = new THREE.Group();
    scene.add(modelHolder);

    if (!isSoftwareGl) {
      renderer.compile(scene, camera);
    }

    let frameId = 0;
    let disposed = false;
    let lastTime = performance.now();

    function afterDraw(cb: () => void) {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      if (!gl || typeof gl.fenceSync !== 'function') {
        frameId = window.setTimeout(cb, 80);
        return;
      }
      const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
      gl.flush();
      const poll = () => {
        if (disposed) return;
        const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (state === gl.UNSIGNALED) {
          frameId = window.setTimeout(poll, 5);
        } else {
          if (sync) gl.deleteSync(sync);
          frameId = window.setTimeout(cb, 80);
        }
      };
      frameId = window.setTimeout(poll, 5);
    }

    sceneObjectsRef.current = {
      scene,
      renderer,
      camera,
      controls,
      modelHolder,
      grid,
      axes,
      keyLight,
      hemiLight,
      rimLight,
      contactShadow,
      modelHeight: 1.0,
    };

    const tick = () => {
      if (disposed) return;
      const now = performance.now();
      const dt = Math.min(0.1, (now - lastTime) / 1000);
      lastTime = now;

      if (camTransitionRef.current) {
        camera.position.x = THREE.MathUtils.damp(camera.position.x, _camTargetPos.x, 8, dt);
        camera.position.y = THREE.MathUtils.damp(camera.position.y, _camTargetPos.y, 8, dt);
        camera.position.z = THREE.MathUtils.damp(camera.position.z, _camTargetPos.z, 8, dt);
        controls.target.x = THREE.MathUtils.damp(controls.target.x, _camTargetLook.x, 8, dt);
        controls.target.y = THREE.MathUtils.damp(controls.target.y, _camTargetLook.y, 8, dt);
        controls.target.z = THREE.MathUtils.damp(controls.target.z, _camTargetLook.z, 8, dt);

        if (camera.position.distanceTo(_camTargetPos) < 0.015) {
          camTransitionRef.current = false;
        }
      }

      controls.autoRotate = !isSoftwareGl && autoRotateRef.current && !camTransitionRef.current;
      controls.update();

      renderer.render(scene, camera);

      if (isSoftwareGl) {
        afterDraw(tick);
      } else {
        frameId = requestAnimationFrame(tick);
      }
    };

    tick();

    const resizeObserver = new ResizeObserver(() => {
      if (!container || disposed) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      if (w > 0 && h > 0) {
        camera.aspect = w / h;
        camera.updateProjectionMatrix();
        renderer.setSize(w, h);
      }
    });
    resizeObserver.observe(container);

    return () => {
      disposed = true;
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      resizeObserver.disconnect();
      controls.dispose();
      renderer.domElement.removeEventListener('webglcontextlost', handleContextLost);
      renderer.domElement.removeEventListener('webglcontextrestored', handleContextRestored);
      activeMeshRef.current?.overlayMaterial?.dispose();
      activeMeshRef.current = null;
      disposeObject3D(modelHolder);
      contactShadow.geometry.dispose();
      (contactShadow.material as THREE.Material).dispose();
      shadowTex.dispose();
      envTexture.dispose();
      renderer.dispose();
      if (renderer.domElement.parentNode === container) {
        container.removeChild(renderer.domElement);
      }
      sceneObjectsRef.current = null;
    };
  }, []);

  // Sync grid visibility
  useEffect(() => {
    const objs = sceneObjectsRef.current;
    if (!objs) return;
    objs.grid.visible = showGrid;
    objs.axes.visible = showGrid;
  }, [showGrid]);

  // Sync lighting themes
  useEffect(() => {
    const objs = sceneObjectsRef.current;
    if (!objs) return;
    if (lighting === 'godot_sky') {
      objs.scene.background = new THREE.Color('#192231');
      objs.scene.fog = new THREE.FogExp2('#192231', 0.038);
      objs.hemiLight.color.set('#cde2ff');
      objs.hemiLight.groundColor.set('#36322d');
      objs.hemiLight.intensity = 1.0;
      objs.keyLight.color.set('#fff6e5');
      objs.keyLight.intensity = 2.35;
      objs.rimLight.color.set('#93c5fd');
      objs.rimLight.intensity = 1.0;
    } else if (lighting === 'dark_forge') {
      objs.scene.background = new THREE.Color('#07080c');
      objs.scene.fog = new THREE.FogExp2('#07080c', 0.052);
      objs.hemiLight.color.set('#64748b');
      objs.hemiLight.groundColor.set('#0f172a');
      objs.hemiLight.intensity = 0.55;
      objs.keyLight.color.set('#ffedd5');
      objs.keyLight.intensity = 2.55;
      objs.rimLight.color.set('#f59e0b');
      objs.rimLight.intensity = 1.35;
    } else {
      objs.scene.background = new THREE.Color('#0c0f15');
      objs.scene.fog = new THREE.FogExp2('#0c0f15', 0.045);
      objs.hemiLight.color.set('#a8c7ff');
      objs.hemiLight.groundColor.set('#1e222b');
      objs.hemiLight.intensity = 0.8;
      objs.keyLight.color.set('#fff2df');
      objs.keyLight.intensity = 2.2;
      objs.rimLight.color.set('#7dd3fc');
      objs.rimLight.intensity = 1.0;
    }
  }, [lighting]);

  // Rebuild 3D mesh whenever sourceImageUrl, backImageUrl, or settings change
  // Display renderMode swaps materials without triggering a mesh rebuild!
  useEffect(() => {
    const objs = sceneObjectsRef.current;
    if (!objs) return;

    if (!sourceImageUrl) {
      activeMeshRef.current?.overlayMaterial?.dispose();
      activeMeshRef.current = null;
      while (objs.modelHolder.children.length > 0) {
        const child = objs.modelHolder.children[0];
        objs.modelHolder.remove(child);
        disposeObject3D(child);
      }
      return;
    }

    let cancelled = false;

    const maxAniso = objs.renderer.capabilities.getMaxAnisotropy();
    const timer = window.setTimeout(async () => {
      if (cancelled) return;
      onBuildStateChange(true);
      onBuildError(null);

      try {
        const res = await build3DMeshFromImage(sourceImageUrl, settings, {
          backImageUrl,
          maxAnisotropy: maxAniso,
          renderMode: 'pbr',
        });

        if (cancelled) {
          disposeObject3D(res.group);
          return;
        }

        activeMeshRef.current?.overlayMaterial?.dispose();
        while (objs.modelHolder.children.length > 0) {
          const child = objs.modelHolder.children[0];
          objs.modelHolder.remove(child);
          disposeObject3D(child);
        }

        const overlayMat = applyDisplayMaterialMode(
          res.group,
          res.pbrMaterial,
          renderModeRef.current,
          settings.flatShading
        );

        activeMeshRef.current = {
          group: res.group,
          pbrMaterial: res.pbrMaterial,
          overlayMaterial: overlayMat,
          flatShading: settings.flatShading,
        };

        objs.modelHolder.add(res.group);
        objs.modelHeight = Math.max(0.35, res.stats.boundsMeters.height);

        const footprint = Math.max(
          0.6,
          Math.max(res.stats.boundsMeters.width, res.stats.boundsMeters.depth) * 1.45
        );
        objs.contactShadow.scale.set(footprint, footprint, 1);

        setLocalStats(res.stats);
        onStatsChange(res.stats, res.previews);

        // Export always uses the already-built PBR material with zero redundant rebuilds
        onExportGroupReady(async () => {
          const prevOverlay = activeMeshRef.current?.overlayMaterial;
          if (renderModeRef.current !== 'pbr') {
            res.group.traverse((obj) => {
              if (obj instanceof THREE.Mesh) obj.material = res.pbrMaterial;
            });
          }
          return {
            group: res.group,
            cleanup: () => {
              if (renderModeRef.current !== 'pbr' && prevOverlay) {
                res.group.traverse((obj) => {
                  if (obj instanceof THREE.Mesh) obj.material = prevOverlay;
                });
              }
            },
          };
        });
      } catch (err: unknown) {
        if (!cancelled) {
          const msg = err instanceof Error ? err.message : 'خطا در ساخت مش سه‌بعدی';
          onBuildError(msg);
        }
      } finally {
        if (!cancelled) onBuildStateChange(false);
      }
    }, 60);

    return () => {
      cancelled = true;
      window.clearTimeout(timer);
    };
  }, [
    sourceImageUrl,
    backImageUrl,
    settings,
    onBuildStateChange,
    onStatsChange,
    onExportGroupReady,
    onBuildError,
  ]);

  const applyCameraPreset = (preset: CameraPreset) => {
    setCameraPreset(preset);
    const h = sceneObjectsRef.current?.modelHeight ?? 1.0;
    const midY = h * 0.48;
    const dist = Math.max(0.95, h * 2.15);

    _camTargetLook.set(0, midY, 0);
    if (preset === 'front') {
      _camTargetPos.set(0, midY + 0.05, dist);
    } else if (preset === 'back') {
      _camTargetPos.set(0, midY + 0.05, -dist);
    } else if (preset === 'side') {
      _camTargetPos.set(dist, midY + 0.05, 0);
    } else if (preset === 'top') {
      _camTargetPos.set(0.01, dist * 1.15, 0.2);
    } else {
      _camTargetPos.set(dist * 0.78, midY + dist * 0.4, dist * 0.85);
    }
    camTransitionRef.current = true;
  };

  const overBudget =
    displayedStats.triangleCount > 0 && !displayedStats.validation.withinTriangleBudget;

  return (
    <div className="relative w-full h-full min-h-[540px] bg-[#0c0f15] overflow-hidden select-none">
      {/* Dedicated WebGL Mount Container */}
      <div ref={mountRef} className="w-full h-full" />

      {!sourceImageUrl && !contextLost && (
        <div className="pointer-events-none absolute inset-0 z-10 flex items-center justify-center p-6">
          <div className="max-w-sm rounded-xl bg-[#0e121a]/92 border border-zinc-800 px-6 py-5 text-center space-y-2">
            <Box className="w-8 h-8 text-amber-400 mx-auto" />
            <p className="text-sm font-semibold text-zinc-100">
              آماده تبدیل تصویر به مش سه‌بعدی
            </p>
            <p className="text-xs text-zinc-400 leading-relaxed">
              تصویر مورد نظر را از پنل سمت راست بارگذاری کنید یا با <span className="font-mono-code text-zinc-200" dir="ltr">Ctrl+V</span> بچسبانید تا مش سه‌بعدی آنی ساخته شود.
            </p>
          </div>
        </div>
      )}

      {contextLost && (
        <div className="absolute inset-0 z-20 flex flex-col items-center justify-center bg-zinc-950/95 p-6 text-center">
          <Box className="w-10 h-10 text-amber-400 mb-3" />
          <p className="text-sm font-medium text-zinc-200">
            زمینه گرافیکی WebGL موقتاً متوقف شد
          </p>
          <p className="text-xs text-zinc-400 mt-1">
            در حال بازیابی موتور رندر سه‌بعدی...
          </p>
        </div>
      )}

      {isBuilding && (
        <div className="pointer-events-none absolute top-16 left-5 z-20 flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[#12161f]/95 border border-amber-500/50 text-xs text-amber-200">
          <div className="w-3.5 h-3.5 border-2 border-amber-400/30 border-t-amber-400 rounded-full animate-spin" />
          <span>در حال پردازش مش در Worker...</span>
        </div>
      )}

      {/* Top Unobstructed Mesh Telemetry Bar (Unboxed metadata with middot separators) */}
      <div className="pointer-events-none absolute top-4 right-5 left-5 z-10 flex flex-wrap items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-2 text-xs text-zinc-300 bg-[#0d1118]/92 border border-zinc-800 px-3 py-1.5 rounded-lg">
          <span className="font-mono-code font-semibold text-zinc-100" dir="ltr">
            {settings.assetName}
          </span>
          <span aria-hidden="true" className="text-zinc-600">·</span>
          <span
            className={`font-mono-code tabular-nums ${
              overBudget ? 'text-rose-400 font-semibold' : 'text-amber-300'
            }`}
          >
            {displayedStats.triangleCount.toLocaleString('en-US')} tris
          </span>
          <span aria-hidden="true" className="text-zinc-600">·</span>
          <span className="font-mono-code tabular-nums">
            {displayedStats.vertexCount.toLocaleString('en-US')} verts
          </span>
          <span aria-hidden="true" className="text-zinc-600">·</span>
          <span className="font-mono-code tabular-nums text-zinc-400" dir="ltr">
            {displayedStats.boundsMeters.width}m × {displayedStats.boundsMeters.height}m × {displayedStats.boundsMeters.depth}m
          </span>
        </div>

        <div className="hidden sm:flex items-center gap-2 text-[11px] text-zinc-400 bg-[#0d1118]/92 border border-zinc-800 px-3 py-1.5 rounded-lg">
          <span>چرخش: کلیک چپ</span>
          <span aria-hidden="true" className="text-zinc-600">·</span>
          <span>بزرگنمایی: اسکرول</span>
          <span aria-hidden="true" className="text-zinc-600">·</span>
          <span>جابجایی: کلیک راست</span>
        </div>
      </div>

      {/* Collapsible Bottom Control Dock (Solid surface, zero backdrop-filter over WebGL) */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-10 w-max max-w-[94vw] flex flex-col items-center">
        <button
          type="button"
          onClick={() => setDockCollapsed((v) => !v)}
          className="mb-1.5 flex items-center gap-1.5 px-3 py-1 text-[11px] font-medium text-zinc-300 hover:text-white bg-[#12161f]/95 border border-zinc-700/80 rounded-t-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          {dockCollapsed ? (
            <>
              <ChevronUp className="w-3.5 h-3.5" />
              <span>نمایش کنترل‌های صحنه</span>
            </>
          ) : (
            <>
              <ChevronDown className="w-3.5 h-3.5" />
              <span>مخفی کردن کنترل‌ها</span>
            </>
          )}
        </button>

        {!dockCollapsed && (
          <div className="flex flex-wrap items-center justify-center gap-2 px-3 py-2 bg-[#12161f]/95 border border-zinc-700/80 rounded-xl shadow-2xl">
            {/* Camera Presets */}
            <div className="flex items-center gap-1 bg-zinc-950/80 p-1 rounded-lg border border-zinc-800">
              {(
                [
                  ['perspective', 'سه‌بعدی'],
                  ['front', 'جلو'],
                  ['back', 'پشت'],
                  ['side', 'کنار'],
                  ['top', 'بالا'],
                ] as const
              ).map(([key, label]) => (
                <button
                  key={key}
                  type="button"
                  onClick={() => applyCameraPreset(key)}
                  className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    cameraPreset === key
                      ? 'bg-amber-500 text-zinc-950'
                      : 'text-zinc-300 hover:text-white hover:bg-zinc-800'
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>

            {/* Shader / Topology Inspection Modes */}
            <div className="flex items-center gap-1 bg-zinc-950/80 p-1 rounded-lg border border-zinc-800">
              {(
                [
                  ['pbr', 'بافت PBR'],
                  ['wireframe', 'وایرفریم'],
                  ['normals', 'نرمال‌ها'],
                ] as const
              ).map(([key, label]) => (
                <button
                  key={key}
                  type="button"
                  onClick={() => setRenderMode(key)}
                  className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    renderMode === key
                      ? 'bg-zinc-700 text-amber-300'
                      : 'text-zinc-400 hover:text-zinc-200'
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>

            {/* Lighting Switcher */}
            <div className="flex items-center gap-1 bg-zinc-950/80 p-1 rounded-lg border border-zinc-800">
              <Sun className="w-3.5 h-3.5 text-zinc-400 mx-1" />
              {(
                [
                  ['studio', 'استودیو'],
                  ['godot_sky', 'گودو'],
                  ['dark_forge', 'دراماتیک'],
                ] as const
              ).map(([key, label]) => (
                <button
                  key={key}
                  type="button"
                  onClick={() => setLighting(key)}
                  className={`px-2 py-1 text-xs rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    lighting === key
                      ? 'bg-zinc-700 text-white'
                      : 'text-zinc-400 hover:text-zinc-200'
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>

            {/* Grid & Auto-Rotate */}
            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={() => setShowGrid((g) => !g)}
                className={`flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium rounded-lg border transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  showGrid
                    ? 'bg-zinc-800 border-zinc-600 text-white'
                    : 'bg-zinc-950/80 border-zinc-800 text-zinc-400 hover:text-white'
                }`}
              >
                <Grid3x3 className="w-3.5 h-3.5" />
                <span>شبکه</span>
              </button>

              <button
                type="button"
                onClick={() => setAutoRotate((r) => !r)}
                className={`flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium rounded-lg border transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  autoRotate
                    ? 'bg-zinc-800 border-zinc-600 text-white'
                    : 'bg-zinc-950/80 border-zinc-800 text-zinc-400 hover:text-white'
                }`}
              >
                <RotateCw className="w-3.5 h-3.5" />
                <span>چرخش</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
