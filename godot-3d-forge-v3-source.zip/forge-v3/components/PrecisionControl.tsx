'use client';

import React, { useState } from 'react';
import { Minus, Plus } from 'lucide-react';

interface PrecisionControlProps {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  fineStep?: number;
  decimals?: number;
  unit?: string;
  onChange: (nextValue: number) => void;
}

export default function PrecisionControl({
  label,
  value,
  min,
  max,
  step,
  fineStep,
  decimals = 2,
  unit = '',
  onChange,
}: PrecisionControlProps) {
  const formattedValue =
    decimals === 0 ? String(Math.round(value)) : value.toFixed(decimals);

  const [draft, setDraft] = useState<string>(formattedValue);
  const [focused, setFocused] = useState(false);

  const commitValue = (raw: string) => {
    const parsed = parseFloat(raw);
    if (!Number.isFinite(parsed)) {
      setDraft(formattedValue);
      return;
    }
    const clamped = Math.min(max, Math.max(min, parsed));
    const rounded =
      decimals === 0 ? Math.round(clamped) : Number(clamped.toFixed(decimals));
    onChange(rounded);
    setDraft(decimals === 0 ? String(rounded) : rounded.toFixed(decimals));
  };

  const nudge = (dir: -1 | 1) => {
    const next = Math.min(max, Math.max(min, value + dir * step));
    const rounded =
      decimals === 0 ? Math.round(next) : Number(next.toFixed(decimals));
    onChange(rounded);
  };

  return (
    <div className="space-y-1.5">
      <div className="flex items-center justify-between gap-2">
        <span className="text-xs text-zinc-300 truncate">{label}</span>

        <div
          dir="ltr"
          className="flex items-center bg-zinc-950 border border-zinc-800 rounded-md overflow-hidden shrink-0 focus-within:border-amber-500/80"
        >
          <button
            type="button"
            onClick={() => nudge(-1)}
            disabled={value <= min}
            className="px-1.5 py-1 text-zinc-400 hover:text-zinc-100 hover:bg-zinc-900 disabled:opacity-30 transition-colors cursor-pointer"
            aria-label={`کاهش ${label}`}
          >
            <Minus className="w-3 h-3" />
          </button>

          <input
            type="text"
            inputMode="decimal"
            value={focused ? draft : formattedValue}
            onFocus={() => {
              setDraft(formattedValue);
              setFocused(true);
            }}
            onChange={(e) => {
              const nextStr = e.target.value;
              setDraft(nextStr);
              const parsed = parseFloat(nextStr);
              if (Number.isFinite(parsed) && parsed >= min && parsed <= max) {
                onChange(
                  decimals === 0
                    ? Math.round(parsed)
                    : Number(parsed.toFixed(decimals))
                );
              }
            }}
            onBlur={() => {
              setFocused(false);
              commitValue(draft);
            }}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                commitValue(draft);
                (e.target as HTMLInputElement).blur();
              } else if (e.key === 'ArrowUp') {
                e.preventDefault();
                nudge(1);
              } else if (e.key === 'ArrowDown') {
                e.preventDefault();
                nudge(-1);
              }
            }}
            aria-label={label}
            className="w-16 px-1 py-0.5 text-center text-xs font-mono-code tabular-nums bg-transparent text-amber-300 focus:outline-none"
          />

          {unit && (
            <span className="pr-1.5 text-[10px] font-mono-code text-zinc-500 select-none">
              {unit}
            </span>
          )}

          <button
            type="button"
            onClick={() => nudge(1)}
            disabled={value >= max}
            className="px-1.5 py-1 text-zinc-400 hover:text-zinc-100 hover:bg-zinc-900 disabled:opacity-30 transition-colors cursor-pointer"
            aria-label={`افزایش ${label}`}
          >
            <Plus className="w-3 h-3" />
          </button>
        </div>
      </div>

      <input
        type="range"
        min={min}
        max={max}
        step={fineStep ?? step}
        value={value}
        onChange={(e) => {
          const val = parseFloat(e.target.value);
          onChange(
            decimals === 0 ? Math.round(val) : Number(val.toFixed(decimals))
          );
        }}
        className="w-full h-1.5 accent-amber-500 cursor-pointer"
      />
    </div>
  );
}
