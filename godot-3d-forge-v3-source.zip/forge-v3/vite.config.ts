import { fileURLToPath, URL } from 'node:url';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';
import { VitePWA } from 'vite-plugin-pwa';
import { defineConfig } from 'vite';

// Base path for static hosting. Default '/'. For a GitHub Project Page
// (https://<user>.github.io/<repo>/) set PAGES_BASE=/<repo>/ — see README.
const base = process.env.PAGES_BASE ?? '/';

export default defineConfig({
  base,
  plugins: [
    react(),
    tailwindcss(),
    // F-24: PWA — manifest + Service Worker + app-shell caching.
    // start_url/scope follow the Vite base so a GitHub Project Page
    // subpath (PAGES_BASE=/<repo>/) stays installable and offline-capable.
    VitePWA({
      registerType: 'autoUpdate',
      includeAssets: [
        'icons/icon-192.png',
        'icons/icon-512.png',
        'icons/apple-touch-icon.png',
      ],
      manifest: {
        name: 'Godot 3D Forge — تبدیل تصویر به مدل سه‌بعدی',
        short_name: '3D Forge',
        description:
          'ابزار تبدیل تصویر به مدل سه‌بعدی (GLB / GLTF / OBJ) سازگار با موتور بازی‌سازی گودو — کاملاً محلی و بدون وابستگی به سرویس خارجی.',
        theme_color: '#7138D4',
        background_color: '#090b0f',
        display: 'standalone',
        dir: 'rtl',
        lang: 'fa',
        start_url: base,
        scope: base,
        icons: [
          { src: 'icons/icon-192.png', sizes: '192x192', type: 'image/png' },
          { src: 'icons/icon-512.png', sizes: '512x512', type: 'image/png', purpose: 'any' },
          {
            src: 'icons/icon-512.png',
            sizes: '512x512',
            type: 'image/png',
            purpose: 'maskable',
          },
          {
            src: 'icons/apple-touch-icon.png',
            sizes: '180x180',
            type: 'image/png',
            purpose: 'any',
          },
        ],
      },
      workbox: {
        globPatterns: ['**/*.{js,css,html,ico,png,svg,woff,woff2}'],
        cleanupOutdatedCaches: true,
      },
      devOptions: { enabled: false },
    }),
  ],
  resolve: {
    alias: {
      '@': fileURLToPath(new URL('./', import.meta.url)),
    },
  },
  worker: {
    format: 'es',
  },
});
