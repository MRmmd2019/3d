/**
 * Argument parsing for the `forge` CLI (F-30). Kept in its own module so it
 * is unit-testable without spawning a process.
 *
 * Usage:
 *   forge build <photo.png> [--target godot|unity|unreal|blender|generic]
 *                           [--width 0.88] [--out out.glb]
 *                           [--back back.png] [--mode sculpted|lathe|voxel]
 *                           [--name AssetName]
 */
import { defaultGlbOutPath, parseTarget, type ForgeTarget } from '../lib/node-shim';
import type { MeshGenerationMode } from '../lib/meshTypes';

export const USAGE = `forge — Godot 3D Forge CLI (photo -> GLB mesh)

Usage:
  forge build <photo.png> [--target godot|unity|unreal|blender|generic]
                          [--width 0.88] [--out out.glb]
                          [--back back.png] [--mode sculpted|lathe|voxel]
                          [--name AssetName]
  forge --help

Options:
  --target   Export target (default: godot). All five names are accepted;
             target-specific transforms land with Group F (lib/targets.ts) —
             until then every target uses the Godot default geometry.
  --width    Real-world width of the model in metres (default: 1.0).
  --out      Output GLB path (default: <photo-basename>.glb in the cwd).
  --back     Optional second photo for the back face (dual-view atlas).
  --mode     Mesh mode: sculpted (default), lathe, voxel.
  --name     Asset/node name (default: photo file name, ASCII-sanitized).`;

export class CliUsageError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'CliUsageError';
  }
}

export interface BuildArgs {
  command: 'build';
  photo: string;
  target: ForgeTarget;
  width: number;
  out: string;
  back?: string;
  mode: MeshGenerationMode;
  name?: string;
}

export type ParsedArgs = BuildArgs | { command: 'help' };

const MODES: readonly string[] = ['sculpted', 'lathe', 'voxel'];

export function parseArgs(argv: string[]): ParsedArgs {
  if (argv.length === 0 || argv.includes('--help') || argv.includes('-h')) {
    return { command: 'help' };
  }

  const [command, ...rest] = argv;
  if (command !== 'build') {
    throw new CliUsageError(`Unknown command "${command}". Expected "build".`);
  }

  let photo: string | undefined;
  let target: ForgeTarget = 'godot';
  let width = 1.0;
  let out: string | undefined;
  let back: string | undefined;
  let mode: MeshGenerationMode = 'sculpted';
  let name: string | undefined;

  const takeValue = (flag: string, i: number): string => {
    const value = rest[i + 1];
    if (value === undefined || value.startsWith('--')) {
      throw new CliUsageError(`Option ${flag} requires a value.`);
    }
    return value;
  };

  for (let i = 0; i < rest.length; i++) {
    const token = rest[i];
    if (token.startsWith('--')) {
      const [flag, inlineValue] = token.split('=', 2);
      const value = inlineValue !== undefined ? inlineValue : takeValue(flag, i);
      if (inlineValue === undefined) i++;
      switch (flag) {
        case '--target': {
          try {
            target = parseTarget(value);
          } catch (err) {
            throw new CliUsageError(err instanceof Error ? err.message : String(err));
          }
          break;
        }
        case '--width': {
          width = Number(value);
          if (!Number.isFinite(width) || width < 0.05 || width > 20) {
            throw new CliUsageError(
              `--width must be a number between 0.05 and 20 (got "${value}").`
            );
          }
          break;
        }
        case '--out':
          out = value;
          break;
        case '--back':
          back = value;
          break;
        case '--mode':
          if (!MODES.includes(value)) {
            throw new CliUsageError(
              `--mode must be one of ${MODES.join(', ')} (got "${value}").`
            );
          }
          mode = value as MeshGenerationMode;
          break;
        case '--name':
          name = value;
          break;
        default:
          throw new CliUsageError(`Unknown option "${flag}".`);
      }
    } else if (token.startsWith('-')) {
      throw new CliUsageError(`Unknown option "${token}".`);
    } else if (!photo) {
      photo = token;
    } else {
      throw new CliUsageError(`Unexpected argument "${token}".`);
    }
  }

  if (!photo) {
    throw new CliUsageError('Missing <photo.png> argument.');
  }

  return {
    command: 'build',
    photo,
    target,
    width,
    out: out ?? defaultGlbOutPath(photo),
    back,
    mode,
    name,
  };
}
