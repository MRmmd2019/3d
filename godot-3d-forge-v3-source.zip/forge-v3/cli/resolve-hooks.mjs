// ESM resolve hook for Node's native TypeScript type stripping.
//
// Node 24 runs `.ts` entry points directly, but its ESM resolver requires
// explicit file extensions — while the Forge codebase (Vite/bundler style)
// imports sibling modules extensionless (`./meshAlgorithms`). This hook
// resolves extensionless relative imports to their `.ts` file (falling back
// to `.tsx` / `.js` / `.mjs` / `index.ts`) so `node cli/forge.ts` and
// `node mcp/server.ts` work with no build step and no extra flags.
//
// It only short-circuits relative specifiers that have no extension and
// resolve to an existing file; everything else falls through to Node's
// default resolver untouched.
import { existsSync } from 'node:fs';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { dirname, resolve as pathResolve } from 'node:path';

const EXTENSIONS = ['.ts', '.tsx', '.mts', '.js', '.mjs', '.cjs'];

export async function resolve(specifier, context, nextResolve) {
  const isRelative = specifier.startsWith('./') || specifier.startsWith('../');
  const hasExtension = /\.[a-zA-Z0-9]+$/.test(specifier);
  if (isRelative && !hasExtension) {
    const parentPath = fileURLToPath(context.parentURL);
    const base = pathResolve(dirname(parentPath), specifier);
    for (const ext of EXTENSIONS) {
      const candidate = base + ext;
      if (existsSync(candidate)) {
        return { url: pathToFileURL(candidate).href, shortCircuit: true };
      }
    }
    const indexCandidate = base + '/index.ts';
    if (existsSync(indexCandidate)) {
      return { url: pathToFileURL(indexCandidate).href, shortCircuit: true };
    }
  }
  return nextResolve(specifier, context);
}
