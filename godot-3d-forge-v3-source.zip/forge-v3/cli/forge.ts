#!/usr/bin/env node
/**
 * `forge` CLI entry point (F-30). Runs directly under Node 24 native
 * TypeScript type stripping — no build step:
 *
 *   node cli/forge.ts build photo.png --width 0.88 --out out.glb
 *
 * The entry is a thin bootstrap: it registers the ESM resolve hook
 * (cli/resolve-hooks.mjs) that lets extensionless `.ts` imports in the
 * engine resolve, then dynamic-imports the real implementation.
 */
import { register } from 'node:module';

register('./resolve-hooks.mjs', import.meta.url);

const { main } = await import('./forge-main.ts');
process.exitCode = await main(process.argv.slice(2));
