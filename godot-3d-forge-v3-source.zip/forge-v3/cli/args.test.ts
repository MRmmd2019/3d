import { describe, expect, it } from 'vitest';
import { CliUsageError, parseArgs } from './args';

describe('parseArgs', () => {
  it('parses the full documented invocation', () => {
    const args = parseArgs([
      'build',
      'photo.png',
      '--target',
      'unreal',
      '--width',
      '0.88',
      '--out',
      'out.glb',
    ]);
    expect(args).toEqual({
      command: 'build',
      photo: 'photo.png',
      target: 'unreal',
      width: 0.88,
      out: 'out.glb',
      back: undefined,
      mode: 'sculpted',
      name: undefined,
    });
  });

  it('applies defaults (godot target, width 1.0, <basename>.glb out)', () => {
    const args = parseArgs(['build', 'dir/my-crate.png']);
    expect(args.command).toBe('build');
    if (args.command === 'build') {
      expect(args.target).toBe('godot');
      expect(args.width).toBe(1.0);
      expect(args.out).toBe('my-crate.glb');
      expect(args.mode).toBe('sculpted');
    }
  });

  it('accepts --flag=value form', () => {
    const args = parseArgs(['build', 'p.png', '--width=2.5', '--mode=lathe']);
    if (args.command === 'build') {
      expect(args.width).toBe(2.5);
      expect(args.mode).toBe('lathe');
    } else {
      throw new Error('expected build args');
    }
  });

  it('returns help for --help and for no arguments', () => {
    expect(parseArgs(['--help'])).toEqual({ command: 'help' });
    expect(parseArgs([])).toEqual({ command: 'help' });
  });

  it('rejects an unknown target', () => {
    expect(() => parseArgs(['build', 'p.png', '--target', 'mars'])).toThrow(CliUsageError);
  });

  it('rejects an out-of-range width', () => {
    expect(() => parseArgs(['build', 'p.png', '--width', '0'])).toThrow(CliUsageError);
    expect(() => parseArgs(['build', 'p.png', '--width', 'abc'])).toThrow(CliUsageError);
  });

  it('rejects a missing photo, an unknown command, and an unknown option', () => {
    expect(() => parseArgs(['build'])).toThrow(CliUsageError);
    expect(() => parseArgs(['serve', 'p.png'])).toThrow(CliUsageError);
    expect(() => parseArgs(['build', 'p.png', '--nope', 'x'])).toThrow(CliUsageError);
  });
});
