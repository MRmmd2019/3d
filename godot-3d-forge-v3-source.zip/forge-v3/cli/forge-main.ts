/**
 * `forge` CLI implementation (F-30).
 *
 *   forge build <photo.png> [--target godot|unity|unreal|blender|generic]
 *                           [--width 0.88] [--out out.glb]
 *
 * Prints a JSON summary on success (stdout), a clear message on stderr
 * otherwise. Exit codes: 0 success, 2 usage error, 1 runtime error.
 */
import { basename } from 'node:path';
import { TARGET_NOTE, buildMeshGlb, writeFile } from '../lib/node-shim';
import { CliUsageError, USAGE, parseArgs } from './args';

export async function main(argv: string[]): Promise<number> {
  let args;
  try {
    args = parseArgs(argv);
  } catch (err) {
    if (err instanceof CliUsageError) {
      console.error(`forge: ${err.message}\n\n${USAGE}`);
      return 2;
    }
    throw err;
  }

  if (args.command === 'help') {
    console.log(USAGE);
    return 0;
  }

  try {
    const result = await buildMeshGlb({
      frontPath: args.photo,
      backPath: args.back ?? null,
      target: args.target,
      widthMeters: args.width,
      mode: args.mode,
      assetName: args.name ?? basename(args.photo).replace(/\.[^.]+$/, ''),
      optimize: true,
    });
    await writeFile(args.out, result.glbBytes);

    const summary: Record<string, unknown> = {
      ok: true,
      output: args.out,
      target: result.target,
      asset: result.assetName,
      triangles: result.triangles,
      vertices: result.vertices,
      sizeBytes: result.sizeBytes,
      widthMeters: result.widthMeters,
      watertight: result.watertight,
      openBoundaryEdges: result.openBoundaryEdges,
      degenerateTriangles: result.degenerateTriangles,
      withinTriangleBudget: result.withinTriangleBudget,
      boundsMeters: result.boundsMeters,
      foregroundCoveragePct: result.foregroundCoveragePct,
      metallicSurfacePct: result.metallicSurfacePct,
      hasBackImage: result.hasBackImage,
    };
    if (result.target !== 'godot') {
      summary.targetNote = TARGET_NOTE;
    }
    console.log(JSON.stringify(summary, null, 2));
    return 0;
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    console.error(`forge: ${message}`);
    return 1;
  }
}
