/**
 * Export-target registry (Forge v3, F-32..F-36).
 *
 * One registry entry per engine the studio can export for. The Godot
 * target is the default and must keep byte-identical behaviour to v2:
 * meters, OpenGL-style normal maps, standard glTF PBR textures and the
 * `-col` collision suffix. Every target-specific transform (unit scale,
 * normal green-channel flip, Unity metallic+smoothness packing, collision
 * naming) lives behind the selected target only — generic and godot
 * outputs are untouched.
 */

export type ExportTargetId = 'godot' | 'unity' | 'unreal' | 'blender' | 'generic';

export type ExportTargetUnit = 'm' | 'cm';

/** How this target packs its PBR textures. */
export type TexturePacking = 'standard-gltf' | 'unity-metallic-smoothness';

export type CollisionNamingStyle = 'suffix' | 'prefix' | 'none';

export type TargetScriptKind =
  | 'gdscript'
  | 'csharp'
  | 'unreal-python'
  | 'blender-python'
  | 'none';

export interface CollisionNaming {
  style: CollisionNamingStyle;
  /** Suffix or prefix string (empty when style is 'none'). */
  value: string;
  /** English note stating the convention and where it applies. */
  note: string;
  /** Persian version of the note, shown in the UI. */
  noteFa: string;
}

export interface ExportTarget {
  id: ExportTargetId;
  label: string;
  labelFa: string;
  /** Display unit of this target's world. */
  unit: ExportTargetUnit;
  /**
   * Multiply the model's meter dimensions by this factor on export.
   * Unreal works in centimeters, so it exports x100; every other
   * target stays in meters (x1).
   */
  unitScale: number;
  /**
   * Flip the green channel of the normal map on export. Unreal uses
   * DirectX-style normal maps (green down); glTF/Godot/Unity/Blender
   * use OpenGL-style (green up). Only Unreal flips.
   */
  flipNormalGreen: boolean;
  texturePacking: TexturePacking;
  collisionNaming: CollisionNaming;
  scriptKind: TargetScriptKind;
  scriptFileName: (assetName: string) => string;
  /** Short English import note, included in the per-target ZIP README. */
  readmeBlurb: string;
  /** Persian version of the README blurb, shown in the UI. */
  readmeBlurbFa: string;
}

export const EXPORT_TARGETS: readonly ExportTarget[] = [
  {
    id: 'godot',
    label: 'Godot 4',
    labelFa: 'گودو ۴',
    unit: 'm',
    unitScale: 1,
    flipNormalGreen: false,
    texturePacking: 'standard-gltf',
    collisionNaming: {
      style: 'suffix',
      value: '-col',
      note: 'Godot auto-creates a StaticBody3D + CollisionShape3D for any mesh node whose name ends in "-col" when a GLB is imported.',
      noteFa: 'گودو هنگام ایمپورت GLB برای هر نودی که نامش به «-col» ختم شود، خودکار StaticBody3D و CollisionShape3D می‌سازد.',
    },
    scriptKind: 'gdscript',
    scriptFileName: (assetName) => `${assetName}_Controller.gd`,
    readmeBlurb:
      'Import the .glb into your Godot 4 project (drag into res://assets/models/). The mesh node ends in "-col", so Godot builds its collision shape automatically. Attach the .gd script to a Node3D.',
    readmeBlurbFa:
      'فایل ‎.glb را به پروژه گودو ۴ بکشید. نام مش به «-col» ختم می‌شود و گودو خودکار شکل برخورد می‌سازد. اسکریپت ‎.gd را به یک Node3D وصل کنید.',
  },
  {
    id: 'unity',
    label: 'Unity',
    labelFa: 'یونیتی',
    unit: 'm',
    unitScale: 1,
    flipNormalGreen: false,
    texturePacking: 'unity-metallic-smoothness',
    collisionNaming: {
      style: 'none',
      value: '',
      note: 'Unity has no name-based collision convention. Add a MeshCollider component to the imported model in the editor (tick Convex for a dynamic Rigidbody).',
      noteFa: 'یونیتی قرارداد نام‌گذاری برای برخورد ندارد؛ در ادیتور به مدل ایمپورت‌شده یک MeshCollider اضافه کنید (برای Rigidbody متحرک، Convex را فعال کنید).',
    },
    scriptKind: 'csharp',
    scriptFileName: (assetName) => `${assetName}Controller.cs`,
    readmeBlurb:
      'Install the glTFast package (com.atteneder.gltfast) via Package Manager (Add package by git URL), then drag the .glb into Assets. Use the packed _MetallicSmoothness.png (R = metallic, A = smoothness) with the Standard shader. Add a MeshCollider for collision.',
    readmeBlurbFa:
      'اول پکیج glTFast را از Package Manager نصب کنید، بعد ‎.glb را به Assets بکشید. بافت ‎_MetallicSmoothness.png (کانال R متالیک، کانال A اسموت‌نس) برای شیدر Standard است. برای برخورد MeshCollider اضافه کنید.',
  },
  {
    id: 'unreal',
    label: 'Unreal Engine 5',
    labelFa: 'آنریل انجین ۵',
    unit: 'cm',
    unitScale: 100,
    flipNormalGreen: true,
    texturePacking: 'standard-gltf',
    collisionNaming: {
      style: 'prefix',
      value: 'UCX_',
      note: 'Unreal custom collision uses the UCX_ prefix on the FBX path: a mesh named "UCX_<MeshName>" is imported as the collision hull of "<MeshName>". The glTF importer does not carry custom collision, so this name is a marker for the FBX conversion step — convert the GLB to FBX (e.g. in Blender) and keep the UCX_ mesh.',
      noteFa: 'برخورد سفارشی آنریل در مسیر FBX با پیشوند UCX_ کار می‌کند: مشی به نام «UCX_<MeshName>» به‌عنوان پوسته برخورد «<MeshName>» ایمپورت می‌شود. ایمپورتر glTF برخورد سفارشی را منتقل نمی‌کند، پس این نام فقط نشانه‌ای برای مرحله تبدیل به FBX است.',
    },
    scriptKind: 'unreal-python',
    scriptFileName: (assetName) => `${assetName}_Import.py`,
    readmeBlurb:
      'The GLB in this ZIP is already scaled x100 to centimeters (Unreal world unit) and its normal map is DirectX-style (green channel flipped). Import it with the supplied Unreal Python editor script, or via Content Browser > Import. Collision: convert to FBX and keep the UCX_ mesh (see the collision note).',
    readmeBlurbFa:
      'فایل ‎.glb این ZIP از قبل ۱۰۰ برابر شده (سانتی‌متر، واحد آنریل) و نرمال‌مپ آن DirectX است (کانال سبز معکوس). با اسکریپت پایتون همراه یا از Content Browser ایمپورت کنید. برای برخورد، به FBX تبدیل کنید و مش UCX_ را نگه دارید.',
  },
  {
    id: 'blender',
    label: 'Blender',
    labelFa: 'بلندر',
    unit: 'm',
    unitScale: 1,
    flipNormalGreen: false,
    texturePacking: 'standard-gltf',
    collisionNaming: {
      style: 'none',
      value: '',
      note: 'Blender has no name-based collision convention. Collision is a physics property (Rigid Body / Collision modifier on the object), not a name.',
      noteFa: 'بلندر قرارداد نام‌گذاری برای برخورد ندارد؛ برخورد یک ویژگی فیزیکی است (Rigid Body یا Collision modifier روی آبجکت)، نه یک نام.',
    },
    scriptKind: 'blender-python',
    scriptFileName: (assetName) => `${assetName}_Setup.py`,
    readmeBlurb:
      'Run the supplied Python script in Blender (Scripting workspace, or blender -b --python <script>). It imports the .glb, wires the PNG textures into Principled BSDF materials, and adds a turntable animation.',
    readmeBlurbFa:
      'اسکریپت پایتون همراه را در بلندر اجرا کنید (تب Scripting یا با blender -b --python). فایل ‎.glb را ایمپورت می‌کند، بافت‌های PNG را به متریال Principled BSDF وصل می‌کند و یک انیمیشن چرخان (turntable) اضافه می‌کند.',
  },
  {
    id: 'generic',
    label: 'Generic glTF',
    labelFa: 'glTF عمومی',
    unit: 'm',
    unitScale: 1,
    flipNormalGreen: false,
    texturePacking: 'standard-gltf',
    collisionNaming: {
      style: 'none',
      value: '',
      note: 'No collision naming — a plain glTF 2.0 asset with standard PBR textures, usable in any glTF-compatible tool.',
      noteFa: 'بدون نام‌گذاری برخورد — یک دارایی ساده glTF 2.0 با بافت‌های استاندارد PBR برای هر ابزار سازگار با glTF.',
    },
    scriptKind: 'none',
    scriptFileName: () => '',
    readmeBlurb:
      'Plain glTF 2.0 asset: meters, OpenGL-style normal map, standard metallic-roughness PBR textures. No engine-specific script or collision naming.',
    readmeBlurbFa:
      'دارایی ساده glTF 2.0: متر، نرمال‌مپ OpenGL، بافت‌های استاندارد متالیک-رافنس. بدون اسکریپت یا نام‌گذاری برخورد مخصوص موتور.',
  },
];

/** Look a target up by id; unknown ids fall back to the Godot default. */
export function getExportTarget(id: string): ExportTarget {
  return EXPORT_TARGETS.find((t) => t.id === id) ?? EXPORT_TARGETS[0];
}

/**
 * Flip the green channel of an RGBA normal map (OpenGL <-> DirectX).
 * Pure function: returns a new array, the input is untouched.
 * Only the Unreal target applies this (F-34).
 */
export function flipNormalMapGreenChannel(
  rgba: Uint8ClampedArray
): Uint8ClampedArray {
  const out = new Uint8ClampedArray(rgba.length);
  for (let i = 0; i + 3 < rgba.length; i += 4) {
    out[i] = rgba[i];
    out[i + 1] = 255 - rgba[i + 1];
    out[i + 2] = rgba[i + 2];
    out[i + 3] = rgba[i + 3];
  }
  return out;
}

/**
 * Pack metallic + roughness maps into Unity's metallic-smoothness map
 * (F-35): R = metallic, G = 0, B = 0, A = smoothness = 1 - roughness.
 * Both inputs are grayscale RGBA maps of the same size; the R channel
 * of each carries the value. Pure function: returns a new array.
 */
export function packUnityMetallicSmoothness(
  metalRgba: Uint8ClampedArray,
  roughRgba: Uint8ClampedArray
): Uint8ClampedArray {
  const len = Math.min(metalRgba.length, roughRgba.length);
  const out = new Uint8ClampedArray(len);
  for (let i = 0; i + 3 < len; i += 4) {
    out[i] = metalRgba[i];
    out[i + 1] = 0;
    out[i + 2] = 0;
    out[i + 3] = 255 - roughRgba[i];
  }
  return out;
}

/**
 * Apply a target's collision naming to an already-built mesh node name
 * (F-36). The builder always names the mesh `<Name>_Mesh` plus the Godot
 * `-col` suffix when enabled, so the Godot suffix is stripped first and
 * the target's own convention is applied: Godot keeps `-col`, Unreal
 * gets the `UCX_` prefix, Unity/Blender/generic get the plain name.
 */
export function targetCollisionMeshName(
  builtMeshName: string,
  target: ExportTarget
): string {
  const plain = builtMeshName.endsWith('-col')
    ? builtMeshName.slice(0, -'-col'.length)
    : builtMeshName;
  if (target.collisionNaming.style === 'prefix') {
    return `${target.collisionNaming.value}${plain}`;
  }
  if (target.collisionNaming.style === 'suffix') {
    return `${plain}${target.collisionNaming.value}`;
  }
  return plain;
}
