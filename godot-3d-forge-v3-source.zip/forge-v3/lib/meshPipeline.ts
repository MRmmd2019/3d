import * as THREE from 'three';
import {
  applyTaubinSmoothingRaw,
  computeCylindricalLatheUv,
  computeForegroundMask,
  computeHeightField,
  segmentPbrMaterials,
  validateMeshTopology,
} from './meshAlgorithms';
import type { MeshBuildSettings, MeshValidationReport } from './meshTypes';

export interface MeshPipelineInput {
  cols: number;
  rows: number;
  aspect: number;
  frontSegRgba: Uint8ClampedArray;
  backSegRgba: Uint8ClampedArray | null;
  mapW: number;
  mapH: number;
  frontMapRgba: Uint8ClampedArray;
  backMapRgba: Uint8ClampedArray | null;
  /** ML-cut mask (from lib/mlCutout). Used only when cutoutMethod is 'ml'; ignored otherwise. */
  mlMask?: Uint8Array | null;
  backMlMask?: Uint8Array | null;
  settings: MeshBuildSettings;
}

export interface MeshPipelineOutput {
  positions: Float32Array;
  normals: Float32Array | null;
  uvs: Float32Array;
  colors: Float32Array | null;
  indices: Uint32Array;
  albedoOutRgba: Uint8ClampedArray;
  normalOutRgba: Uint8ClampedArray;
  roughOutRgba: Uint8ClampedArray;
  metalOutRgba: Uint8ClampedArray;
  maskPreviewRgba: Uint8ClampedArray;
  atlasW: number;
  atlasH: number;
  foregroundCoveragePct: number;
  metallicSurfacePct: number;
  hasBackImage: boolean;
  validation: MeshValidationReport;
}

function flipRgbaHorizontally(
  src: Uint8ClampedArray,
  w: number,
  h: number
): Uint8ClampedArray {
  const out = new Uint8ClampedArray(src.length);
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const si = (y * w + (w - 1 - x)) * 4;
      const di = (y * w + x) * 4;
      out[di] = src[si];
      out[di + 1] = src[si + 1];
      out[di + 2] = src[si + 2];
      out[di + 3] = src[si + 3];
    }
  }
  return out;
}

function generateFaceTextures(
  rgbaInput: Uint8ClampedArray,
  mask: Uint8Array,
  maskCols: number,
  maskRows: number,
  mapW: number,
  mapH: number,
  settings: MeshBuildSettings,
  effectiveNormalStrength: number,
  effectiveRoughness: number,
  effectiveMetalness: number,
  nearestSampling: boolean
): {
  albedoRgba: Uint8ClampedArray;
  normalRgba: Uint8ClampedArray;
  roughRgba: Uint8ClampedArray;
  metalRgba: Uint8ClampedArray;
  metallicSurfacePct: number;
} {
  const albedoRgba = new Uint8ClampedArray(rgbaInput);
  const polishOn = Boolean(settings.polish?.enabled);

  // Subtle unsharp detail boost on albedo when polish detailSharpen > 0
  if (polishOn && settings.polish.detailSharpen > 0.05 && !nearestSampling) {
    const src = new Uint8ClampedArray(albedoRgba);
    const amt = Math.min(1.2, settings.polish.detailSharpen * 0.45);
    for (let y = 1; y < mapH - 1; y++) {
      for (let x = 1; x < mapW - 1; x++) {
        const i = (y * mapW + x) * 4;
        for (let c = 0; c < 3; c++) {
          const blur =
            (src[i - 4 + c] +
              src[i + 4 + c] +
              src[i - mapW * 4 + c] +
              src[i + mapW * 4 + c]) *
            0.25;
          albedoRgba[i + c] = Math.min(
            255,
            Math.max(0, Math.round(src[i + c] + (src[i + c] - blur) * amt))
          );
        }
      }
    }
  }

  // 3px edge color bleed outside foreground mask to avoid dark fringe sampling
  if (settings.cutoutEnabled && !nearestSampling) {
    let currMask = new Uint8Array(mapW * mapH);
    for (let y = 0; y < mapH; y++) {
      const sy = Math.min(maskRows - 1, Math.floor((y / mapH) * maskRows));
      for (let x = 0; x < mapW; x++) {
        const sx = Math.min(maskCols - 1, Math.floor((x / mapW) * maskCols));
        currMask[y * mapW + x] = mask[sy * maskCols + sx];
      }
    }

    for (let step = 0; step < 3; step++) {
      const nextMask = new Uint8Array(currMask);
      for (let y = 1; y < mapH - 1; y++) {
        for (let x = 1; x < mapW - 1; x++) {
          const i = y * mapW + x;
          if (currMask[i]) continue;
          const dirs = [i - 1, i + 1, i - mapW, i + mapW];
          for (const d of dirs) {
            if (currMask[d]) {
              const p = i * 4;
              const dp = d * 4;
              albedoRgba[p] = albedoRgba[dp];
              albedoRgba[p + 1] = albedoRgba[dp + 1];
              albedoRgba[p + 2] = albedoRgba[dp + 2];
              albedoRgba[p + 3] = 255;
              nextMask[i] = 1;
              break;
            }
          }
        }
      }
      currMask = nextMask;
    }
  }

  const totalMapPx = mapW * mapH;
  const lumaBuf = new Float32Array(totalMapPx);
  for (let i = 0; i < totalMapPx; i++) {
    const p = i * 4;
    const l = (0.299 * rgbaInput[p] + 0.587 * rgbaInput[p + 1] + 0.114 * rgbaInput[p + 2]) / 255;
    lumaBuf[i] = settings.invertDepth ? 1 - l : l;
  }

  // Per-pixel PBR material segmentation (wood/organic matte vs dark steel/brass metallic)
  const segPbr = segmentPbrMaterials(
    rgbaInput,
    mapW,
    mapH,
    effectiveRoughness,
    effectiveMetalness,
    settings.autoMaterialSegmentation && !nearestSampling,
    settings.materialSensitivity,
    mask,
    maskCols,
    maskRows
  );

  const normalRgba = new Uint8ClampedArray(totalMapPx * 4);
  const roughRgba = new Uint8ClampedArray(totalMapPx * 4);
  const metalRgba = new Uint8ClampedArray(totalMapPx * 4);

  const polishDetailBoost =
    polishOn ? 1 + settings.polish.detailSharpen * 0.45 : 1;
  const strength = effectiveNormalStrength * 2.4 * polishDetailBoost;

  for (let y = 0; y < mapH; y++) {
    const ym = Math.max(0, y - 1);
    const yp = Math.min(mapH - 1, y + 1);
    for (let x = 0; x < mapW; x++) {
      const xm = Math.max(0, x - 1);
      const xp = Math.min(mapW - 1, x + 1);

      const tl = lumaBuf[ym * mapW + xm];
      const t = lumaBuf[ym * mapW + x];
      const tr = lumaBuf[ym * mapW + xp];
      const l = lumaBuf[y * mapW + xm];
      const r = lumaBuf[y * mapW + xp];
      const bl = lumaBuf[yp * mapW + xm];
      const b = lumaBuf[yp * mapW + x];
      const br = lumaBuf[yp * mapW + xp];

      const dX = (tr + 2 * r + br - (tl + 2 * l + bl)) * strength;
      const dY = (bl + 2 * b + br - (tl + 2 * t + tr)) * strength;

      let nx = -dX;
      let ny = dY;
      let nz = 1.0;
      const len = Math.sqrt(nx * nx + ny * ny + nz * nz);
      nx /= len;
      ny /= len;
      nz /= len;

      const pixIdx = y * mapW + x;
      const idx = pixIdx * 4;
      normalRgba[idx] = Math.round((nx * 0.5 + 0.5) * 255);
      normalRgba[idx + 1] = Math.round((ny * 0.5 + 0.5) * 255);
      normalRgba[idx + 2] = Math.round((nz * 0.5 + 0.5) * 255);
      normalRgba[idx + 3] = 255;

      const edgeMag = Math.min(1, Math.sqrt(dX * dX + dY * dY) * 0.35);
      const baseSegRough = segPbr.roughnessValues[pixIdx];
      const roughVal = Math.min(
        1,
        Math.max(0.05, baseSegRough + edgeMag * 0.14 - lumaBuf[pixIdx] * 0.06)
      );
      const rByte = Math.round(roughVal * 255);
      roughRgba[idx] = rByte;
      roughRgba[idx + 1] = rByte;
      roughRgba[idx + 2] = rByte;
      roughRgba[idx + 3] = 255;

      const mByte = Math.round(segPbr.metalnessValues[pixIdx] * 255);
      metalRgba[idx] = mByte;
      metalRgba[idx + 1] = mByte;
      metalRgba[idx + 2] = mByte;
      metalRgba[idx + 3] = 255;
    }
  }

  return {
    albedoRgba,
    normalRgba,
    roughRgba,
    metalRgba,
    metallicSurfacePct: segPbr.metallicSurfacePct,
  };
}

function packVerticalAtlas(
  topRgba: Uint8ClampedArray,
  bottomRgba: Uint8ClampedArray,
  w: number,
  h: number
): Uint8ClampedArray {
  const rowBytes = w * 4;
  const out = new Uint8ClampedArray(rowBytes * h * 2);
  out.set(topRgba, 0);
  out.set(bottomRgba, rowBytes * h);
  return out;
}

function buildSculptedRaw(
  cols: number,
  rows: number,
  aspect: number,
  frontMask: Uint8Array,
  frontHeight: Float32Array,
  backHeight: Float32Array | null,
  backMask: Uint8Array | null,
  settings: MeshBuildSettings
): {
  positions: Float32Array;
  uvs: Float32Array;
  indices: Uint32Array;
} {
  const scaleRef = settings.targetWidthMeters;
  const widthWorld = aspect >= 1 ? scaleRef : scaleRef * aspect;
  const heightWorld = aspect >= 1 ? scaleRef / aspect : scaleRef;
  const hasBack = Boolean(backHeight && backMask);

  const positions: number[] = [];
  const uvs: number[] = [];
  const indices: number[] = [];

  const cellActive = (cx: number, cy: number) => {
    if (cx < 0 || cx >= cols - 1 || cy < 0 || cy >= rows - 1) return false;
    return (
      frontMask[cy * cols + cx] === 1 ||
      frontMask[cy * cols + cx + 1] === 1 ||
      frontMask[(cy + 1) * cols + cx] === 1 ||
      frontMask[(cy + 1) * cols + cx + 1] === 1
    );
  };

  const frontIdx = new Int32Array(cols * rows).fill(-1);
  const backIdx = new Int32Array(cols * rows).fill(-1);

  const ensureVertex = (gx: number, gy: number, isFront: boolean): number => {
    const pIdx = gy * cols + gx;
    const cache = isFront ? frontIdx : backIdx;
    if (cache[pIdx] !== -1) return cache[pIdx];

    const u = gx / (cols - 1);
    const v = 1 - gy / (rows - 1);
    const wx = (u - 0.5) * widthWorld;
    const wy = v * heightWorld;
    const hf = frontHeight[pIdx] * settings.depthScale;

    let wz: number;
    if (isFront) {
      wz = hf * 0.5 + 0.008;
    } else if (backHeight) {
      const hb = backHeight[pIdx] * settings.depthScale;
      wz = -(hb * 0.5 + 0.008);
    } else {
      wz = settings.doubleSidedSymmetry ? -(hf * 0.5 + 0.008) : -0.012;
    }

    const vIdx = positions.length / 3;
    positions.push(wx, wy, wz);
    // Initial UV mapped into top half if back atlas exists (sides will inherit front rim cleanly)
    const atlasV = hasBack ? 0.505 + v * 0.49 : v;
    uvs.push(u, atlasV);
    cache[pIdx] = vIdx;
    return vIdx;
  };

  const backTriIndices: number[] = [];

  for (let cy = 0; cy < rows - 1; cy++) {
    for (let cx = 0; cx < cols - 1; cx++) {
      if (!cellActive(cx, cy)) continue;

      const f00 = ensureVertex(cx, cy, true);
      const f10 = ensureVertex(cx + 1, cy, true);
      const f01 = ensureVertex(cx, cy + 1, true);
      const f11 = ensureVertex(cx + 1, cy + 1, true);

      indices.push(f00, f01, f10);
      indices.push(f10, f01, f11);

      const b00 = ensureVertex(cx, cy, false);
      const b10 = ensureVertex(cx + 1, cy, false);
      const b01 = ensureVertex(cx, cy + 1, false);
      const b11 = ensureVertex(cx + 1, cy + 1, false);

      const btStart = indices.length;
      indices.push(b00, b10, b01);
      indices.push(b10, b11, b01);
      if (hasBack) {
        for (let k = btStart; k < indices.length; k++) backTriIndices.push(k);
      }

      if (!cellActive(cx, cy - 1)) {
        indices.push(f00, f10, b00);
        indices.push(f10, b10, b00);
      }
      if (!cellActive(cx, cy + 1)) {
        indices.push(f11, f01, b11);
        indices.push(f01, b01, b11);
      }
      if (!cellActive(cx - 1, cy)) {
        indices.push(f01, f00, b01);
        indices.push(f00, b00, b01);
      }
      if (!cellActive(cx + 1, cy)) {
        indices.push(f10, f11, b10);
        indices.push(f11, b11, b10);
      }
    }
  }

  const posArr = new Float32Array(positions);
  const idxArr = new Uint32Array(indices);

  // Always apply anti-staircase Taubin silhouette smoothing (plus any extra AI polish passes)
  const totalTaubin =
    Math.max(0, settings.silhouetteTaubinPasses) +
    (settings.polish?.enabled ? settings.polish.laplacianIterations : 0);
  const taubinLambda = settings.polish?.enabled ? settings.polish.taubinLambda : 0.42;

  if (totalTaubin > 0) {
    applyTaubinSmoothingRaw(posArr, idxArr, totalTaubin, taubinLambda);
  }

  // If a separate back-view image is uploaded, split back-face triangles to sample bottom atlas [0.005..0.495]
  if (hasBack && backTriIndices.length > 0) {
    const posList = Array.from(posArr);
    const uvList = [...uvs];
    const backRemap = new Map<number, number>();

    for (const idxSlot of backTriIndices) {
      const oldV = idxArr[idxSlot];
      let newV = backRemap.get(oldV);
      if (newV === undefined) {
        newV = posList.length / 3;
        posList.push(posList[oldV * 3], posList[oldV * 3 + 1], posList[oldV * 3 + 2]);
        const origU = uvList[oldV * 2];
        const origAtlasV = uvList[oldV * 2 + 1];
        const normV = Math.min(1, Math.max(0, (origAtlasV - 0.505) / 0.49));
        // Mirror U back to align back photo left-to-right when viewed from -Z
        const backAtlasV = 0.005 + normV * 0.49;
        uvList.push(1 - origU, backAtlasV);
        backRemap.set(oldV, newV);
      }
      idxArr[idxSlot] = newV;
    }

    return {
      positions: new Float32Array(posList),
      uvs: new Float32Array(uvList),
      indices: idxArr,
    };
  }

  return {
    positions: posArr,
    uvs: new Float32Array(uvs),
    indices: idxArr,
  };
}

function buildLatheRaw(
  cols: number,
  rows: number,
  aspect: number,
  mask: Uint8Array,
  hasBack: boolean,
  settings: MeshBuildSettings
): {
  positions: Float32Array;
  uvs: Float32Array;
  indices: Uint32Array;
} {
  const scaleRef = settings.targetWidthMeters;
  const heightWorld = aspect >= 1 ? scaleRef / aspect : scaleRef;
  const maxWidthWorld = aspect >= 1 ? scaleRef : scaleRef * aspect;

  let minY = rows - 1;
  let maxY = 0;
  for (let y = 0; y < rows; y++) {
    for (let x = 0; x < cols; x++) {
      if (mask[y * cols + x]) {
        if (y < minY) minY = y;
        if (y > maxY) maxY = y;
      }
    }
  }
  if (maxY <= minY) {
    minY = 0;
    maxY = rows - 1;
  }

  const rawRadii: number[] = [];
  const rawYs: number[] = [];

  for (let y = maxY; y >= minY; y--) {
    let leftX = cols;
    let rightX = -1;
    for (let x = 0; x < cols; x++) {
      if (mask[y * cols + x]) {
        if (x < leftX) leftX = x;
        if (x > rightX) rightX = x;
      }
    }
    const span = rightX >= leftX ? (rightX - leftX + 1) / cols : 0.04;
    const radius = Math.max(0.005, span * maxWidthWorld * 0.5);
    const wy = (1 - y / Math.max(1, rows - 1)) * heightWorld;
    rawRadii.push(radius);
    rawYs.push(wy);
  }

  let smoothed = [...rawRadii];
  for (let pass = 0; pass < Math.max(1, settings.smoothPasses); pass++) {
    const next = [...smoothed];
    for (let i = 1; i < smoothed.length - 1; i++) {
      next[i] = (smoothed[i - 1] + smoothed[i] * 2 + smoothed[i + 1]) / 4;
    }
    smoothed = next;
  }

  const points: THREE.Vector2[] = [];
  points.push(new THREE.Vector2(0, rawYs[0]));
  for (let i = 0; i < smoothed.length; i++) {
    points.push(new THREE.Vector2(smoothed[i], rawYs[i]));
  }
  points.push(new THREE.Vector2(0, rawYs[rawYs.length - 1]));

  const geom = new THREE.LatheGeometry(points, settings.latheSegments);
  const posAttr = geom.attributes.position;
  const uvAttr = geom.attributes.uv;
  const idxAttr = geom.index;

  // Preserve LatheGeometry's cylindrical U (angle around Y) & V (profile height)
  // without stretching sides via planar projection!
  const uvs = new Float32Array(posAttr.count * 2);
  for (let i = 0; i < posAttr.count; i++) {
    const rawU = uvAttr.getX(i);
    const rawV = uvAttr.getY(i);
    const [cu, cv] = computeCylindricalLatheUv(rawU, rawV, hasBack);
    uvs[i * 2] = cu;
    uvs[i * 2 + 1] = cv;
  }

  const positions = new Float32Array(posAttr.array);
  const indices = idxAttr
    ? new Uint32Array(idxAttr.array)
    : Uint32Array.from({ length: posAttr.count }, (_, idx) => idx);

  geom.dispose();

  const totalTaubin =
    Math.max(0, settings.silhouetteTaubinPasses) +
    (settings.polish?.enabled ? settings.polish.laplacianIterations : 0);
  if (totalTaubin > 0) {
    applyTaubinSmoothingRaw(
      positions,
      indices,
      Math.min(2, totalTaubin),
      settings.polish?.enabled ? settings.polish.taubinLambda : 0.35
    );
  }

  return { positions, uvs, indices };
}

function buildVoxelRaw(
  cols: number,
  rows: number,
  aspect: number,
  mask: Uint8Array,
  heightField: Float32Array,
  hasBack: boolean,
  settings: MeshBuildSettings
): {
  positions: Float32Array;
  normals: Float32Array;
  uvs: Float32Array;
  indices: Uint32Array;
} {
  const scaleRef = settings.targetWidthMeters;
  const widthWorld = aspect >= 1 ? scaleRef : scaleRef * aspect;
  const heightWorld = aspect >= 1 ? scaleRef / aspect : scaleRef;

  const voxelW = widthWorld / cols;
  const voxelH = heightWorld / rows;

  const positions: number[] = [];
  const normals: number[] = [];
  const uvs: number[] = [];
  const indices: number[] = [];

  const pushQuad = (
    p0: [number, number, number],
    p1: [number, number, number],
    p2: [number, number, number],
    p3: [number, number, number],
    n: [number, number, number],
    u: number,
    v: number
  ) => {
    const base = positions.length / 3;
    positions.push(...p0, ...p1, ...p2, ...p3);
    normals.push(...n, ...n, ...n, ...n);
    uvs.push(u, v, u, v, u, v, u, v);
    indices.push(base, base + 1, base + 2, base, base + 2, base + 3);
  };

  const hasMask = (x: number, y: number) =>
    x >= 0 && x < cols && y >= 0 && y < rows && mask[y * cols + x] === 1;

  for (let y = 0; y < rows; y++) {
    for (let x = 0; x < cols; x++) {
      const idx = y * cols + x;
      if (!mask[idx]) continue;

      const u = (x + 0.5) / cols;
      const vRaw = 1 - (y + 0.5) / rows;
      const vFront = hasBack ? 0.505 + vRaw * 0.49 : vRaw;
      const vBack = hasBack ? 0.005 + vRaw * 0.49 : vRaw;

      const x0 = -widthWorld / 2 + x * voxelW;
      const x1 = x0 + voxelW;
      const y1 = heightWorld - y * voxelH;
      const y0 = y1 - voxelH;

      const halfD = Math.max(voxelW * 0.5, heightField[idx] * settings.depthScale * 0.5);
      const z0 = settings.doubleSidedSymmetry ? -halfD : -voxelW * 0.5;
      const z1 = halfD;

      pushQuad([x0, y0, z1], [x1, y0, z1], [x1, y1, z1], [x0, y1, z1], [0, 0, 1], u, vFront);
      pushQuad(
        [x1, y0, z0],
        [x0, y0, z0],
        [x0, y1, z0],
        [x1, y1, z0],
        [0, 0, -1],
        hasBack ? 1 - u : u,
        vBack
      );

      const leftH = hasMask(x - 1, y) ? heightField[idx - 1] * settings.depthScale * 0.5 : 0;
      if (!hasMask(x - 1, y) || halfD > leftH + 0.002) {
        pushQuad([x0, y0, z0], [x0, y0, z1], [x0, y1, z1], [x0, y1, z0], [-1, 0, 0], u, vFront);
      }
      const rightH = hasMask(x + 1, y) ? heightField[idx + 1] * settings.depthScale * 0.5 : 0;
      if (!hasMask(x + 1, y) || halfD > rightH + 0.002) {
        pushQuad([x1, y0, z1], [x1, y0, z0], [x1, y1, z0], [x1, y1, z1], [1, 0, 0], u, vFront);
      }
      const topH = hasMask(x, y - 1) ? heightField[idx - cols] * settings.depthScale * 0.5 : 0;
      if (!hasMask(x, y - 1) || halfD > topH + 0.002) {
        pushQuad([x0, y1, z1], [x1, y1, z1], [x1, y1, z0], [x0, y1, z0], [0, 1, 0], u, vFront);
      }
      const botH = hasMask(x, y + 1) ? heightField[idx + cols] * settings.depthScale * 0.5 : 0;
      if (!hasMask(x, y + 1) || halfD > botH + 0.002) {
        pushQuad([x0, y0, z0], [x1, y0, z0], [x1, y0, z1], [x0, y0, z1], [0, -1, 0], u, vFront);
      }
    }
  }

  return {
    positions: new Float32Array(positions),
    normals: new Float32Array(normals),
    uvs: new Float32Array(uvs),
    indices: new Uint32Array(indices),
  };
}

function computeCavityColors(
  positions: Float32Array,
  normals: Float32Array,
  indices: Uint32Array,
  intensity: number
): Float32Array | null {
  if (intensity <= 0.02 || positions.length === 0 || indices.length === 0) return null;
  const count = Math.floor(positions.length / 3);
  const adj: Array<Set<number>> = Array.from({ length: count }, () => new Set<number>());

  for (let i = 0; i < indices.length; i += 3) {
    const a = indices[i];
    const b = indices[i + 1];
    const c = indices[i + 2];
    adj[a].add(b);
    adj[a].add(c);
    adj[b].add(a);
    adj[b].add(c);
    adj[c].add(a);
    adj[c].add(b);
  }

  const colors = new Float32Array(count * 3);
  for (let i = 0; i < count; i++) {
    const neighbors = adj[i];
    if (neighbors.size === 0) {
      colors[i * 3] = 1;
      colors[i * 3 + 1] = 1;
      colors[i * 3 + 2] = 1;
      continue;
    }
    const px = positions[i * 3];
    const py = positions[i * 3 + 1];
    const pz = positions[i * 3 + 2];
    const nx = normals[i * 3];
    const ny = normals[i * 3 + 1];
    const nz = normals[i * 3 + 2];

    let ax = 0;
    let ay = 0;
    let az = 0;
    for (const n of neighbors) {
      ax += positions[n * 3];
      ay += positions[n * 3 + 1];
      az += positions[n * 3 + 2];
    }
    const inv = 1 / neighbors.size;
    const vx = ax * inv - px;
    const vy = ay * inv - py;
    const vz = az * inv - pz;

    const concavity = vx * nx + vy * ny + vz * nz;
    const occlusion = concavity > 0 ? Math.min(0.48, concavity * 14 * intensity) : 0;
    const shade = 1 - occlusion;
    colors[i * 3] = shade;
    colors[i * 3 + 1] = shade;
    colors[i * 3 + 2] = shade;
  }
  return colors;
}

function maskCoveragePct(mask: Uint8Array): number {
  if (mask.length === 0) return 0;
  let fg = 0;
  for (let i = 0; i < mask.length; i++) fg += mask[i];
  return Math.round((fg / mask.length) * 100);
}

export function runMeshBuildPipeline(input: MeshPipelineInput): MeshPipelineOutput {
  const {
    cols,
    rows,
    aspect,
    frontSegRgba,
    backSegRgba,
    mapW,
    mapH,
    frontMapRgba,
    backMapRgba,
    mlMask,
    backMlMask,
    settings,
  } = input;

  const polishOn = Boolean(settings.polish?.enabled);
  const effectiveRoughness =
    polishOn && typeof settings.polish.roughnessOverride === 'number'
      ? settings.polish.roughnessOverride
      : settings.roughness;
  const effectiveMetalness =
    polishOn && typeof settings.polish.metalnessOverride === 'number'
      ? settings.polish.metalnessOverride
      : settings.metalness;
  const effectiveNormalStrength =
    polishOn && typeof settings.polish.normalStrengthOverride === 'number'
      ? settings.polish.normalStrengthOverride
      : settings.normalStrength;

  // Cutout mask source: ML mask when method is 'ml' and one was supplied
  // (produced in meshEngine from the ML-cut image's alpha channel); the
  // flood-fill path runs otherwise, and also when the ML step fell back.
  const useMlFrontMask =
    settings.cutoutEnabled && settings.cutoutMethod === 'ml' && mlMask != null;
  const frontMaskRes = useMlFrontMask
    ? { mask: mlMask, foregroundCoveragePct: maskCoveragePct(mlMask) }
    : computeForegroundMask(
        frontSegRgba,
        cols,
        rows,
        settings.cutoutEnabled,
        settings.cutoutTolerance,
        settings.edgeErode
      );

  const frontHeight = computeHeightField(frontSegRgba, frontMaskRes.mask, cols, rows, {
    balloonWeight: settings.balloonWeight,
    detailWeight: settings.detailWeight,
    invertDepth: settings.invertDepth,
    smoothPasses: settings.smoothPasses,
    polish: settings.polish,
  });

  const hasBackImage = Boolean(backSegRgba && backMapRgba);
  let backMask: Uint8Array | null = null;
  let backHeight: Float32Array | null = null;
  let flippedBackMapRgba: Uint8ClampedArray | null = null;

  if (hasBackImage && backSegRgba && backMapRgba) {
    const flippedBackSeg = flipRgbaHorizontally(backSegRgba, cols, rows);
    const useMlBackMask =
      settings.cutoutEnabled && settings.cutoutMethod === 'ml' && backMlMask != null;
    const backMaskRes = useMlBackMask
      ? { mask: backMlMask, foregroundCoveragePct: maskCoveragePct(backMlMask) }
      : computeForegroundMask(
          flippedBackSeg,
          cols,
          rows,
          settings.cutoutEnabled,
          settings.cutoutTolerance,
          settings.edgeErode
        );
    backMask = backMaskRes.mask;
    backHeight = computeHeightField(flippedBackSeg, backMask, cols, rows, {
      balloonWeight: settings.balloonWeight,
      detailWeight: settings.detailWeight,
      invertDepth: settings.invertDepth,
      smoothPasses: settings.smoothPasses,
      polish: settings.polish,
    });
    flippedBackMapRgba = flipRgbaHorizontally(backMapRgba, mapW, mapH);
  }

  const nearestSampling = settings.mode === 'voxel';
  const frontTex = generateFaceTextures(
    frontMapRgba,
    frontMaskRes.mask,
    cols,
    rows,
    mapW,
    mapH,
    settings,
    effectiveNormalStrength,
    effectiveRoughness,
    effectiveMetalness,
    nearestSampling
  );

  let albedoOutRgba = frontTex.albedoRgba;
  let normalOutRgba = frontTex.normalRgba;
  let roughOutRgba = frontTex.roughRgba;
  let metalOutRgba = frontTex.metalRgba;
  let metallicSurfacePct = frontTex.metallicSurfacePct;
  const atlasW = mapW;
  let atlasH = mapH;

  if (hasBackImage && flippedBackMapRgba && backMask) {
    const backTex = generateFaceTextures(
      flippedBackMapRgba,
      backMask,
      cols,
      rows,
      mapW,
      mapH,
      settings,
      effectiveNormalStrength,
      effectiveRoughness,
      effectiveMetalness,
      nearestSampling
    );
    albedoOutRgba = packVerticalAtlas(frontTex.albedoRgba, backTex.albedoRgba, mapW, mapH);
    normalOutRgba = packVerticalAtlas(frontTex.normalRgba, backTex.normalRgba, mapW, mapH);
    roughOutRgba = packVerticalAtlas(frontTex.roughRgba, backTex.roughRgba, mapW, mapH);
    metalOutRgba = packVerticalAtlas(frontTex.metalRgba, backTex.metalRgba, mapW, mapH);
    metallicSurfacePct = Math.round((frontTex.metallicSurfacePct + backTex.metallicSurfacePct) * 0.5);
    atlasH = mapH * 2;
  }

  const maskPreviewRgba = new Uint8ClampedArray(cols * rows * 4);
  for (let i = 0; i < cols * rows; i++) {
    const p = i * 4;
    if (frontMaskRes.mask[i]) {
      maskPreviewRgba[p] = frontSegRgba[p];
      maskPreviewRgba[p + 1] = frontSegRgba[p + 1];
      maskPreviewRgba[p + 2] = frontSegRgba[p + 2];
      maskPreviewRgba[p + 3] = 255;
    } else {
      const cx = i % cols;
      const cy = Math.floor(i / cols);
      const checker = ((cx >> 2) + (cy >> 2)) % 2 === 0 ? 22 : 34;
      maskPreviewRgba[p] = checker;
      maskPreviewRgba[p + 1] = checker + 2;
      maskPreviewRgba[p + 2] = checker + 6;
      maskPreviewRgba[p + 3] = 255;
    }
  }

  let positions: Float32Array;
  let normals: Float32Array | null = null;
  let uvs: Float32Array;
  let indices: Uint32Array;

  if (settings.mode === 'lathe') {
    const lathe = buildLatheRaw(cols, rows, aspect, frontMaskRes.mask, hasBackImage, settings);
    positions = lathe.positions;
    uvs = lathe.uvs;
    indices = lathe.indices;
  } else if (settings.mode === 'voxel') {
    const voxel = buildVoxelRaw(
      cols,
      rows,
      aspect,
      frontMaskRes.mask,
      frontHeight,
      hasBackImage,
      settings
    );
    positions = voxel.positions;
    normals = voxel.normals;
    uvs = voxel.uvs;
    indices = voxel.indices;
  } else {
    const sculpted = buildSculptedRaw(
      cols,
      rows,
      aspect,
      frontMaskRes.mask,
      frontHeight,
      backHeight,
      backMask,
      settings
    );
    positions = sculpted.positions;
    uvs = sculpted.uvs;
    indices = sculpted.indices;
  }

  // Compute vertex normals using Three.js BufferGeometry on worker/pipeline
  const tmpGeom = new THREE.BufferGeometry();
  tmpGeom.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  tmpGeom.setAttribute('uv', new THREE.BufferAttribute(uvs, 2));
  tmpGeom.setIndex(new THREE.BufferAttribute(indices, 1));
  if (normals) {
    tmpGeom.setAttribute('normal', new THREE.BufferAttribute(normals, 3));
  } else {
    tmpGeom.computeVertexNormals();
    normals = new Float32Array(tmpGeom.attributes.normal.array);
  }
  tmpGeom.dispose();

  let colors: Float32Array | null = null;
  if (polishOn && settings.mode !== 'voxel' && settings.polish.cavityAoIntensity > 0.02 && normals) {
    colors = computeCavityColors(positions, normals, indices, settings.polish.cavityAoIntensity);
  }

  const validation = validateMeshTopology(
    positions,
    indices,
    settings.targetTriangleBudget,
    null
  );

  return {
    positions,
    normals,
    uvs,
    colors,
    indices,
    albedoOutRgba,
    normalOutRgba,
    roughOutRgba,
    metalOutRgba,
    maskPreviewRgba,
    atlasW,
    atlasH,
    foregroundCoveragePct: frontMaskRes.foregroundCoveragePct,
    metallicSurfacePct,
    hasBackImage,
    validation,
  };
}
