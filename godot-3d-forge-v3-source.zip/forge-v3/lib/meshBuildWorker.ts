import { runMeshBuildPipeline, type MeshPipelineInput } from './meshPipeline';

interface WorkerBuildRequest {
  jobId: number;
  type?: 'build';
  payload: MeshPipelineInput;
}

interface WorkerSampleRequest {
  jobId: number;
  type: 'sample-image';
  bitmap: ImageBitmap;
  width: number;
  height: number;
}

type WorkerRequest = WorkerBuildRequest | WorkerSampleRequest;

/**
 * F-28: OffscreenCanvas support inside the worker.
 * Feature-detected at call time — browsers without OffscreenCanvas (or
 * without a 2D context) simply report unavailable and the caller falls
 * back to main-thread canvas sampling.
 */
export function isOffscreenCanvasAvailable(): boolean {
  return typeof OffscreenCanvas !== 'undefined';
}

/**
 * Draw an ImageBitmap into an OffscreenCanvas and read its RGBA pixels.
 * Throws when OffscreenCanvas (or its 2D context) is unavailable.
 */
export function sampleImageBitmapOffscreen(
  bitmap: ImageBitmap,
  width: number,
  height: number
): Uint8ClampedArray {
  if (!isOffscreenCanvasAvailable()) {
    throw new Error('OffscreenCanvas is not available in this context');
  }
  const canvas = new OffscreenCanvas(width, height);
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  if (!ctx) throw new Error('OffscreenCanvas 2D context unavailable');
  ctx.drawImage(bitmap, 0, 0, width, height);
  return ctx.getImageData(0, 0, width, height).data;
}

function postReply(message: unknown, transfer?: Transferable[]): void {
  (self as unknown as Worker).postMessage(message, transfer ?? []);
}

function handleSampleImage(req: WorkerSampleRequest): void {
  try {
    const rgba = sampleImageBitmapOffscreen(req.bitmap, req.width, req.height);
    postReply({ jobId: req.jobId, ok: true, rgba }, [rgba.buffer]);
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : String(err);
    postReply({ jobId: req.jobId, ok: false, error: message });
  } finally {
    try {
      req.bitmap.close();
    } catch {
      // Bitmap may already be detached after transfer — ignore.
    }
  }
}

function handleBuild(req: WorkerBuildRequest): void {
  try {
    const out = runMeshBuildPipeline(req.payload);
    const transferables: Transferable[] = [
      out.positions.buffer,
      out.uvs.buffer,
      out.indices.buffer,
      out.albedoOutRgba.buffer,
      out.normalOutRgba.buffer,
      out.roughOutRgba.buffer,
      out.metalOutRgba.buffer,
      out.maskPreviewRgba.buffer,
    ];
    if (out.normals) transferables.push(out.normals.buffer);
    if (out.colors) transferables.push(out.colors.buffer);

    postReply({ jobId: req.jobId, ok: true, result: out }, transferables);
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : String(err);
    postReply({ jobId: req.jobId, ok: false, error: message });
  }
}

// Guarded so the module can be imported in Node (unit tests) where `self`
// is not a Worker global — the handler only registers in a real worker.
if (typeof self !== 'undefined' && typeof self.addEventListener === 'function') {
  self.addEventListener('message', (event: MessageEvent<WorkerRequest>) => {
    const req = event.data;
    if (!req || typeof req.jobId !== 'number') return;
    if (req.type === 'sample-image') {
      handleSampleImage(req as WorkerSampleRequest);
    } else {
      handleBuild(req as WorkerBuildRequest);
    }
  });
}
