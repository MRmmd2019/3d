import type { MeshPolishProfile, MeshValidationReport } from './meshTypes';

export interface MaskResult {
  mask: Uint8Array;
  foregroundCoveragePct: number;
}

/**
 * Pure flood-fill + alpha cutout background segmentation with morphological edge erosion.
 * Runs identically in browser main thread, Web Worker, and Node/Vitest.
 */
export function computeForegroundMask(
  rgba: Uint8ClampedArray,
  cols: number,
  rows: number,
  cutoutEnabled: boolean,
  cutoutTolerance: number,
  edgeErode: number
): MaskResult {
  const total = cols * rows;
  let mask = new Uint8Array(total);

  if (!cutoutEnabled) {
    mask.fill(1);
    return { mask, foregroundCoveragePct: 100 };
  }

  let minBorderAlpha = 255;
  for (let x = 0; x < cols; x++) {
    minBorderAlpha = Math.min(minBorderAlpha, rgba[x * 4 + 3]);
    minBorderAlpha = Math.min(minBorderAlpha, rgba[((rows - 1) * cols + x) * 4 + 3]);
  }
  for (let y = 0; y < rows; y++) {
    minBorderAlpha = Math.min(minBorderAlpha, rgba[(y * cols) * 4 + 3]);
    minBorderAlpha = Math.min(minBorderAlpha, rgba[(y * cols + cols - 1) * 4 + 3]);
  }

  if (minBorderAlpha < 220) {
    for (let i = 0; i < total; i++) {
      mask[i] = rgba[i * 4 + 3] > 35 ? 1 : 0;
    }
  } else {
    mask.fill(1);
    const visited = new Uint8Array(total);
    const bgMap = new Uint8Array(total);
    const queue = new Int32Array(total);
    let head = 0;
    let tail = 0;

    let sumR = 0;
    let sumG = 0;
    let sumB = 0;
    let borderCount = 0;

    const pushBorder = (idx: number) => {
      if (visited[idx]) return;
      visited[idx] = 1;
      bgMap[idx] = 1;
      queue[tail++] = idx;
      const p = idx * 4;
      sumR += rgba[p];
      sumG += rgba[p + 1];
      sumB += rgba[p + 2];
      borderCount++;
    };

    for (let x = 0; x < cols; x++) {
      pushBorder(x);
      pushBorder((rows - 1) * cols + x);
    }
    for (let y = 1; y < rows - 1; y++) {
      pushBorder(y * cols);
      pushBorder(y * cols + cols - 1);
    }

    const seedR = sumR / Math.max(1, borderCount);
    const seedG = sumG / Math.max(1, borderCount);
    const seedB = sumB / Math.max(1, borderCount);

    const globalThresh = cutoutTolerance * 441.67;
    const stepThresh = Math.max(18, cutoutTolerance * 220);

    while (head < tail) {
      const curr = queue[head++];
      const cx = curr % cols;
      const cy = (curr - cx) / cols;
      const cp = curr * 4;
      const cr = rgba[cp];
      const cg = rgba[cp + 1];
      const cb = rgba[cp + 2];

      const neighbors = [
        cx > 0 ? curr - 1 : -1,
        cx < cols - 1 ? curr + 1 : -1,
        cy > 0 ? curr - cols : -1,
        cy < rows - 1 ? curr + cols : -1,
      ];

      for (const nIdx of neighbors) {
        if (nIdx < 0 || visited[nIdx]) continue;
        visited[nIdx] = 1;
        const np = nIdx * 4;
        const nr = rgba[np];
        const ng = rgba[np + 1];
        const nb = rgba[np + 2];

        const distSeed = Math.sqrt(
          (nr - seedR) ** 2 + (ng - seedG) ** 2 + (nb - seedB) ** 2
        );
        const distStep = Math.sqrt(
          (nr - cr) ** 2 + (ng - cg) ** 2 + (nb - cb) ** 2
        );

        if (distSeed <= globalThresh && distStep <= stepThresh) {
          bgMap[nIdx] = 1;
          queue[tail++] = nIdx;
        }
      }
    }

    for (let i = 0; i < total; i++) {
      mask[i] = bgMap[i] ? 0 : 1;
    }

    let fgCount = 0;
    for (let i = 0; i < total; i++) fgCount += mask[i];
    if (fgCount < total * 0.025) {
      mask.fill(1);
    }
  }

  for (let e = 0; e < edgeErode; e++) {
    const eroded = new Uint8Array(mask);
    for (let y = 1; y < rows - 1; y++) {
      for (let x = 1; x < cols - 1; x++) {
        const i = y * cols + x;
        if (!mask[i]) continue;
        if (!mask[i - 1] || !mask[i + 1] || !mask[i - cols] || !mask[i + cols]) {
          eroded[i] = 0;
        }
      }
    }
    mask = eroded;
  }

  let fgTotal = 0;
  for (let i = 0; i < total; i++) fgTotal += mask[i];
  const foregroundCoveragePct = Math.round((fgTotal / total) * 100);

  return { mask, foregroundCoveragePct };
}

export interface HeightFieldOptions {
  balloonWeight: number;
  detailWeight: number;
  invertDepth: boolean;
  smoothPasses: number;
  polish?: MeshPolishProfile;
}

/**
 * Computes a normalized [0..1+] heightfield via 2-Pass Chamfer Distance Transform + luminance relief.
 */
export function computeHeightField(
  rgba: Uint8ClampedArray,
  mask: Uint8Array,
  cols: number,
  rows: number,
  options: HeightFieldOptions
): Float32Array {
  const total = cols * rows;
  const dist = new Float32Array(total);
  const INF = 1e6;

  for (let y = 0; y < rows; y++) {
    for (let x = 0; x < cols; x++) {
      const i = y * cols + x;
      if (!mask[i] || x === 0 || y === 0 || x === cols - 1 || y === rows - 1) {
        dist[i] = mask[i] ? 1 : 0;
      } else {
        dist[i] = INF;
      }
    }
  }

  for (let y = 1; y < rows - 1; y++) {
    for (let x = 1; x < cols - 1; x++) {
      const i = y * cols + x;
      if (!mask[i]) continue;
      let d = dist[i];
      d = Math.min(d, dist[i - 1] + 1);
      d = Math.min(d, dist[i - cols] + 1);
      d = Math.min(d, dist[i - cols - 1] + 1.414);
      d = Math.min(d, dist[i - cols + 1] + 1.414);
      dist[i] = d;
    }
  }

  let maxDist = 1;
  for (let y = rows - 2; y >= 1; y--) {
    for (let x = cols - 2; x >= 1; x--) {
      const i = y * cols + x;
      if (!mask[i]) continue;
      let d = dist[i];
      d = Math.min(d, dist[i + 1] + 1);
      d = Math.min(d, dist[i + cols] + 1);
      d = Math.min(d, dist[i + cols - 1] + 1.414);
      d = Math.min(d, dist[i + cols + 1] + 1.414);
      dist[i] = d;
      if (d < INF && d > maxDist) maxDist = d;
    }
  }

  const lumaGrid = new Float32Array(total);
  for (let i = 0; i < total; i++) {
    const p = i * 4;
    const l = (0.299 * rgba[p] + 0.587 * rgba[p + 1] + 0.114 * rgba[p + 2]) / 255;
    lumaGrid[i] = options.invertDepth ? 1 - l : l;
  }

  let heightA = new Float32Array(total);
  let heightB = new Float32Array(total);
  const normWeightSum = Math.max(0.01, options.balloonWeight + options.detailWeight);

  for (let i = 0; i < total; i++) {
    if (!mask[i]) {
      heightA[i] = 0;
      continue;
    }
    const dNorm = Math.min(1, dist[i] / maxDist);
    const inflated = Math.sqrt(Math.max(0, 1 - (1 - dNorm) * (1 - dNorm)));
    const combined =
      (options.balloonWeight * inflated + options.detailWeight * lumaGrid[i]) / normWeightSum;
    heightA[i] = 0.08 + 0.92 * combined;
  }

  // Smooth heightfield inside foreground with soft silhouette roll-off
  for (let pass = 0; pass < options.smoothPasses; pass++) {
    for (let y = 0; y < rows; y++) {
      for (let x = 0; x < cols; x++) {
        const i = y * cols + x;
        if (!mask[i]) {
          heightB[i] = 0;
          continue;
        }
        let sum = heightA[i] * 2.2;
        let w = 2.2;
        const nCoords = [
          [x - 1, y],
          [x + 1, y],
          [x, y - 1],
          [x, y + 1],
        ];
        for (const [nx, ny] of nCoords) {
          if (nx >= 0 && nx < cols && ny >= 0 && ny < rows) {
            const ni = ny * cols + nx;
            if (mask[ni]) {
              sum += heightA[ni];
              w += 1;
            } else {
              sum += 0.03;
              w += 0.85;
            }
          }
        }
        heightB[i] = sum / w;
      }
    }
    const tmp = heightA;
    heightA = heightB;
    heightB = tmp;
  }

  // AI Polish Pass: High-Frequency Micro-Displacement & Edge Beveling
  if (options.polish?.enabled) {
    const micro = options.polish.microDisplacement;
    const edgeBevel = options.polish.edgeBevelStrength;
    if (Math.abs(micro) > 0.002) {
      for (let y = 1; y < rows - 1; y++) {
        for (let x = 1; x < cols - 1; x++) {
          const i = y * cols + x;
          if (!mask[i]) continue;
          const localAvg =
            (lumaGrid[i - 1] + lumaGrid[i + 1] + lumaGrid[i - cols] + lumaGrid[i + cols]) * 0.25;
          const highPass = lumaGrid[i] - localAvg;
          heightA[i] = Math.max(0.03, Math.min(1.25, heightA[i] + highPass * micro * 3.5));
        }
      }
    }
    if (edgeBevel > 0.02) {
      for (let y = 1; y < rows - 1; y++) {
        for (let x = 1; x < cols - 1; x++) {
          const i = y * cols + x;
          if (!mask[i]) continue;
          const isBoundary =
            !mask[i - 1] || !mask[i + 1] || !mask[i - cols] || !mask[i + cols];
          if (isBoundary) {
            heightA[i] *= 1 - edgeBevel * 0.55;
          }
        }
      }
    }
  }

  return heightA;
}

export interface SegmentedPbrResult {
  roughnessValues: Float32Array; // 0..1 per pixel
  metalnessValues: Float32Array; // 0..1 per pixel
  metallicSurfacePct: number;
}

/**
 * Per-pixel PBR material segmentation (metallic vs wood/organic/matte dielectric)
 * using HSV chromaticity & luminance clustering so wooden stocks stay matte while steel/brass parts gleam.
 */
export function segmentPbrMaterials(
  rgba: Uint8ClampedArray,
  width: number,
  height: number,
  baseRoughness: number,
  baseMetalness: number,
  enabled: boolean,
  sensitivity: number,
  fgMask?: Uint8Array,
  maskW?: number,
  maskH?: number
): SegmentedPbrResult {
  const total = width * height;
  const roughA = new Float32Array(total);
  const metalA = new Float32Array(total);

  if (!enabled) {
    roughA.fill(baseRoughness);
    metalA.fill(baseMetalness);
    return {
      roughnessValues: roughA,
      metalnessValues: metalA,
      metallicSurfacePct: Math.round(baseMetalness * 100),
    };
  }

  const sens = Math.min(1.6, Math.max(0.2, sensitivity));

  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const i = y * width + x;
      const p = i * 4;
      const r = rgba[p] / 255;
      const g = rgba[p + 1] / 255;
      const b = rgba[p + 2] / 255;

      const max = Math.max(r, g, b);
      const min = Math.min(r, g, b);
      const delta = max - min;
      const sat = max > 1e-4 ? delta / max : 0;
      const luma = 0.299 * r + 0.587 * g + 0.114 * b;

      let hue = 0;
      if (delta > 1e-4) {
        if (max === r) hue = ((g - b) / delta) % 6;
        else if (max === g) hue = (b - r) / delta + 2;
        else hue = (r - g) / delta + 4;
        hue *= 60;
        if (hue < 0) hue += 360;
      }

      // Warm organic wood/leather/earth tones: orange/brown/red-brown hue with saturation
      const isWarmWoodOrLeather =
        hue >= 6 && hue <= 52 && sat >= 0.22 / sens && luma >= 0.08 && luma <= 0.78;
      // Brass / gold / copper metallic highlight: warm yellow-amber & bright specular luma
      const isBrassOrGold =
        hue >= 34 && hue <= 60 && sat >= 0.28 && luma > 0.42;
      // Neutral steel / gunmetal / chrome / dark iron: low saturation
      const isAchromaticMetal =
        sat <= 0.24 * sens && luma >= 0.04 && luma <= 0.88 && !isWarmWoodOrLeather;

      let localRough = baseRoughness;
      let localMetal = baseMetalness;

      if (isWarmWoodOrLeather && !isBrassOrGold) {
        // Matte organic wood / leather / fabric
        localRough = Math.min(0.95, Math.max(0.62, baseRoughness + 0.24));
        localMetal = 0.02;
      } else if (isBrassOrGold) {
        localRough = Math.max(0.14, Math.min(0.42, baseRoughness * 0.65));
        localMetal = Math.min(0.95, Math.max(0.75, baseMetalness + 0.55));
      } else if (isAchromaticMetal) {
        // Gunmetal darker when low luma, polished steel when brighter
        const sheenFactor = 0.35 + (1 - Math.abs(luma - 0.35)) * 0.5;
        localRough = Math.max(0.16, Math.min(0.55, baseRoughness * 0.68 + (1 - luma) * 0.1));
        localMetal = Math.min(0.92, Math.max(0.58 * sheenFactor, baseMetalness + 0.48 * sens));
      } else if (luma > 0.88 && sat < 0.12) {
        // Bright ceramic/paint/white polymer
        localRough = Math.max(0.18, baseRoughness * 0.78);
        localMetal = 0.05;
      } else {
        // Painted / composite / dyed dielectric
        localRough = Math.min(0.9, Math.max(0.32, baseRoughness + 0.08));
        localMetal = Math.min(0.25, baseMetalness * 0.5);
      }

      roughA[i] = Math.min(1, Math.max(0.05, localRough));
      metalA[i] = Math.min(1, Math.max(0, localMetal));
    }
  }

  // 1-pass 3x3 box filter to eliminate harsh pixel transitions at material borders
  const roughB = new Float32Array(total);
  const metalB = new Float32Array(total);
  let metallicFg = 0;
  let totalFg = 0;

  for (let y = 0; y < height; y++) {
    const sy = maskH && fgMask ? Math.min(maskH - 1, Math.floor((y / height) * maskH)) : 0;
    for (let x = 0; x < width; x++) {
      const i = y * width + x;
      let rSum = 0;
      let mSum = 0;
      let count = 0;
      for (let dy = -1; dy <= 1; dy++) {
        const ny = y + dy;
        if (ny < 0 || ny >= height) continue;
        for (let dx = -1; dx <= 1; dx++) {
          const nx = x + dx;
          if (nx < 0 || nx >= width) continue;
          const ni = ny * width + nx;
          rSum += roughA[ni];
          mSum += metalA[ni];
          count++;
        }
      }
      roughB[i] = rSum / count;
      metalB[i] = mSum / count;

      const isFg =
        fgMask && maskW && maskH
          ? fgMask[sy * maskW + Math.min(maskW - 1, Math.floor((x / width) * maskW))] === 1
          : true;
      if (isFg) {
        totalFg++;
        if (metalB[i] >= 0.45) metallicFg++;
      }
    }
  }

  return {
    roughnessValues: roughB,
    metalnessValues: metalB,
    metallicSurfacePct: totalFg > 0 ? Math.round((metallicFg / totalFg) * 100) : 0,
  };
}

/**
 * Taubin Volume-Preserving Mesh Smoothing (λ / μ two-step Laplacian filter)
 * Eliminates jagged staircase faceting on silhouettes while preserving overall volume.
 */
export function applyTaubinSmoothingRaw(
  positions: Float32Array,
  indices: ArrayLike<number>,
  iterations: number,
  lambda: number
): void {
  if (iterations <= 0 || positions.length === 0 || indices.length === 0) return;
  const count = Math.floor(positions.length / 3);
  const adj: Array<Set<number>> = Array.from({ length: count }, () => new Set<number>());

  for (let i = 0; i < indices.length; i += 3) {
    const a = indices[i];
    const b = indices[i + 1];
    const c = indices[i + 2];
    adj[a].add(b);
    adj[a].add(c);
    adj[b].add(a);
    adj[b].add(c);
    adj[c].add(a);
    adj[c].add(b);
  }

  const mu = -lambda * 1.03;
  const scratch = new Float32Array(positions.length);

  const step = (factor: number) => {
    for (let i = 0; i < count; i++) {
      const neighbors = adj[i];
      if (neighbors.size === 0) {
        scratch[i * 3] = positions[i * 3];
        scratch[i * 3 + 1] = positions[i * 3 + 1];
        scratch[i * 3 + 2] = positions[i * 3 + 2];
        continue;
      }
      let sx = 0;
      let sy = 0;
      let sz = 0;
      for (const n of neighbors) {
        sx += positions[n * 3];
        sy += positions[n * 3 + 1];
        sz += positions[n * 3 + 2];
      }
      const inv = 1 / neighbors.size;
      const dx = sx * inv - positions[i * 3];
      const dy = sy * inv - positions[i * 3 + 1];
      const dz = sz * inv - positions[i * 3 + 2];

      scratch[i * 3] = positions[i * 3] + dx * factor;
      scratch[i * 3 + 1] = positions[i * 3 + 1] + dy * factor;
      scratch[i * 3 + 2] = positions[i * 3 + 2] + dz * factor;
    }
    positions.set(scratch);
  };

  for (let it = 0; it < iterations; it++) {
    step(lambda);
    step(mu);
  }
}

/**
 * Computes seam-safe cylindrical UV coordinates for Lathe meshes.
 * With single image: mirrors U (0 -> 1 -> 0) around the 360-degree sweep so the front photo wraps cleanly without stretching.
 * With back image atlas: maps front angle to top atlas half [0.5..1.0] and back angle to bottom atlas half [0.0..0.5].
 */
export function computeCylindricalLatheUv(
  rawU: number,
  rawV: number,
  hasBackAtlas: boolean
): [number, number] {
  const clampedU = Math.min(1, Math.max(0, rawU));
  const clampedV = Math.min(0.995, Math.max(0.005, rawV));

  if (!hasBackAtlas) {
    // Symmetric wrap: 0 -> 1 -> 0 eliminates harsh planar distortion on sides
    const mirroredU = 1 - Math.abs(2 * clampedU - 1);
    return [Math.min(0.99, Math.max(0.01, mirroredU)), clampedV];
  }

  if (clampedU <= 0.5) {
    const frontU = clampedU * 2;
    const atlasV = 0.505 + clampedV * 0.49;
    return [Math.min(0.99, Math.max(0.01, frontU)), atlasV];
  } else {
    const backU = (clampedU - 0.5) * 2;
    const atlasV = 0.005 + clampedV * 0.49;
    return [Math.min(0.99, Math.max(0.01, backU)), atlasV];
  }
}

/**
 * Pre-export geometry validator:
 * Welds positions by quantized spatial key, counts open boundary edges (watertight check),
 * counts degenerate triangles (zero area / duplicate vertices), and checks NaN + triangle budget.
 */
export function validateMeshTopology(
  positions: Float32Array,
  indices: ArrayLike<number> | null,
  triangleBudget: number,
  decimatedFromTriangles: number | null = null
): MeshValidationReport {
  const vertexCount = Math.floor(positions.length / 3);
  let hasInvalidPositions = false;
  for (let i = 0; i < positions.length; i++) {
    if (!Number.isFinite(positions[i])) {
      hasInvalidPositions = true;
      break;
    }
  }

  // Map vertices by spatial position key so split UV/normal seams still count as watertight manifold edges
  const spatialId = new Int32Array(vertexCount);
  const spatialMap = new Map<string, number>();
  let nextSpatial = 0;

  for (let i = 0; i < vertexCount; i++) {
    const kx = Math.round(positions[i * 3] * 10000);
    const ky = Math.round(positions[i * 3 + 1] * 10000);
    const kz = Math.round(positions[i * 3 + 2] * 10000);
    const key = `${kx}_${ky}_${kz}`;
    let id = spatialMap.get(key);
    if (id === undefined) {
      id = nextSpatial++;
      spatialMap.set(key, id);
    }
    spatialId[i] = id;
  }

  const edgeCounts = new Map<string, number>();
  let degenerateTriangles = 0;
  const triCount = indices ? Math.floor(indices.length / 3) : Math.floor(vertexCount / 3);

  for (let t = 0; t < triCount; t++) {
    const ia = indices ? indices[t * 3] : t * 3;
    const ib = indices ? indices[t * 3 + 1] : t * 3 + 1;
    const ic = indices ? indices[t * 3 + 2] : t * 3 + 2;

    const sa = spatialId[ia];
    const sb = spatialId[ib];
    const sc = spatialId[ic];

    if (sa === sb || sb === sc || sa === sc) {
      degenerateTriangles++;
      continue;
    }

    const ax = positions[ia * 3];
    const ay = positions[ia * 3 + 1];
    const az = positions[ia * 3 + 2];
    const bx = positions[ib * 3] - ax;
    const by = positions[ib * 3 + 1] - ay;
    const bz = positions[ib * 3 + 2] - az;
    const cx = positions[ic * 3] - ax;
    const cy = positions[ic * 3 + 1] - ay;
    const cz = positions[ic * 3 + 2] - az;

    const crossX = by * cz - bz * cy;
    const crossY = bz * cx - bx * cz;
    const crossZ = bx * cy - by * cx;
    const areaSq = crossX * crossX + crossY * crossY + crossZ * crossZ;
    if (areaSq < 1e-18) {
      degenerateTriangles++;
      continue;
    }

    const edges: Array<[number, number]> = [
      [sa, sb],
      [sb, sc],
      [sc, sa],
    ];
    for (const [u, v] of edges) {
      const eKey = u < v ? `${u}:${v}` : `${v}:${u}`;
      edgeCounts.set(eKey, (edgeCounts.get(eKey) ?? 0) + 1);
    }
  }

  let openBoundaryEdges = 0;
  for (const count of edgeCounts.values()) {
    if (count === 1) openBoundaryEdges++;
  }

  return {
    isWatertight: openBoundaryEdges === 0 && !hasInvalidPositions,
    openBoundaryEdges,
    degenerateTriangles,
    hasInvalidPositions,
    withinTriangleBudget: triCount <= triangleBudget,
    triangleBudget,
    decimatedFromTriangles,
  };
}
