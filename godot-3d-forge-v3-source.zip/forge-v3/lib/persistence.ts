// F-25 / F-26 — local persistence for Godot 3D Forge v3.
//
// F-25: settings live in localStorage under a versioned key and are merged
// over the defaults on load, so a missing or corrupt entry never breaks
// first-load defaults.
// F-26: presets (settings snapshot + name) and projects (settings +
// thumbnail data URL) live in IndexedDB via idb-keyval, in one small
// dedicated database. All IndexedDB helpers throw on real storage errors
// so the UI can report them; they are not silently swallowed.
import { createStore, get, set } from 'idb-keyval';
import {
  DEFAULT_MESH_SETTINGS,
  DEFAULT_POLISH_PROFILE,
  type MeshBuildSettings,
  type MeshGenerationMode,
  type PivotMode,
  type TextureResolution,
} from './meshTypes';

// ---------------------------------------------------------------- F-25: settings

export const SETTINGS_STORAGE_KEY = 'godot-3d-forge:settings:v1';

/** Merge a stored (possibly partial / stale-shape) value over the defaults. */
export function mergeStoredSettings(stored: unknown): MeshBuildSettings {
  if (!stored || typeof stored !== 'object') return DEFAULT_MESH_SETTINGS;
  const src = stored as Partial<MeshBuildSettings>;
  const out: MeshBuildSettings = { ...DEFAULT_MESH_SETTINGS };

  (Object.keys(DEFAULT_MESH_SETTINGS) as (keyof MeshBuildSettings)[]).forEach((key) => {
    if (key === 'polish') return;
    const storedVal = src[key];
    const defVal = DEFAULT_MESH_SETTINGS[key];
    if (typeof storedVal === typeof defVal) {
      (out as unknown as Record<string, unknown>)[key] = storedVal;
    }
  });

  if (src.polish && typeof src.polish === 'object') {
    const polishSrc = src.polish as Partial<typeof DEFAULT_POLISH_PROFILE>;
    const polish = { ...DEFAULT_POLISH_PROFILE };
    (Object.keys(DEFAULT_POLISH_PROFILE) as (keyof typeof DEFAULT_POLISH_PROFILE)[]).forEach(
      (key) => {
        const storedVal = polishSrc[key];
        const defVal = DEFAULT_POLISH_PROFILE[key];
        if (typeof storedVal === typeof defVal) {
          (polish as unknown as Record<string, unknown>)[key] = storedVal;
        }
      }
    );
    out.polish = polish;
  }

  // Enum-typed fields: fall back to the default when the stored value is not valid.
  const modes: MeshGenerationMode[] = ['sculpted', 'lathe', 'voxel'];
  if (!modes.includes(out.mode)) out.mode = DEFAULT_MESH_SETTINGS.mode;
  const pivots: PivotMode[] = ['bottom_center', 'center'];
  if (!pivots.includes(out.pivotMode)) out.pivotMode = DEFAULT_MESH_SETTINGS.pivotMode;
  const texRes: TextureResolution[] = [512, 1024, 2048];
  if (!texRes.includes(out.textureResolution)) {
    out.textureResolution = DEFAULT_MESH_SETTINGS.textureResolution;
  }

  return out;
}

/** Load persisted settings, or null when nothing (usable) is stored. */
export function loadStoredSettings(): MeshBuildSettings | null {
  try {
    if (typeof localStorage === 'undefined') return null;
    const raw = localStorage.getItem(SETTINGS_STORAGE_KEY);
    if (!raw) return null;
    return mergeStoredSettings(JSON.parse(raw) as unknown);
  } catch {
    return null;
  }
}

/** Persist settings. Never throws (private mode / quota) — the app keeps working. */
export function saveStoredSettings(settings: MeshBuildSettings): void {
  try {
    if (typeof localStorage === 'undefined') return;
    localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(settings));
  } catch {
    // Storage unavailable (private mode, quota) — settings stay in-memory only.
  }
}

// ------------------------------------------------------- F-26: presets & projects

export interface StoredPreset {
  id: string;
  name: string;
  settings: MeshBuildSettings;
  updatedAt: number;
}

export interface StoredProject {
  id: string;
  name: string;
  settings: MeshBuildSettings;
  /** Small thumbnail (usually the source photo data URL, or null). */
  thumbnailDataUrl: string | null;
  updatedAt: number;
}

const forgeStore = createStore('godot-3d-forge', 'keyval');
const PRESETS_KEY = 'presets';
const PROJECTS_KEY = 'projects';

function newId(): string {
  if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) {
    return crypto.randomUUID();
  }
  return `id-${Date.now()}-${Math.floor(Math.random() * 1e9)}`;
}

function isValidSettings(value: unknown): value is MeshBuildSettings {
  return Boolean(value && typeof value === 'object' && 'assetName' in (value as object));
}

function sanitizePresetList(raw: unknown): StoredPreset[] {
  if (!Array.isArray(raw)) return [];
  return raw.filter(
    (item): item is StoredPreset =>
      Boolean(item) &&
      typeof (item as StoredPreset).id === 'string' &&
      typeof (item as StoredPreset).name === 'string' &&
      isValidSettings((item as StoredPreset).settings)
  );
}

function sanitizeProjectList(raw: unknown): StoredProject[] {
  if (!Array.isArray(raw)) return [];
  return raw.filter(
    (item): item is StoredProject =>
      Boolean(item) &&
      typeof (item as StoredProject).id === 'string' &&
      typeof (item as StoredProject).name === 'string' &&
      isValidSettings((item as StoredProject).settings)
  );
}

export async function listPresets(): Promise<StoredPreset[]> {
  return sanitizePresetList(await get<unknown>(PRESETS_KEY, forgeStore));
}

export async function savePreset(
  name: string,
  settings: MeshBuildSettings
): Promise<StoredPreset> {
  const preset: StoredPreset = {
    id: newId(),
    name: name.trim() || 'پرست بدون نام',
    settings: mergeStoredSettings(settings),
    updatedAt: Date.now(),
  };
  const list = await listPresets();
  list.unshift(preset);
  await set(PRESETS_KEY, list, forgeStore);
  return preset;
}

export async function deletePreset(id: string): Promise<void> {
  const list = await listPresets();
  await set(
    PRESETS_KEY,
    list.filter((p) => p.id !== id),
    forgeStore
  );
}

export async function listProjects(): Promise<StoredProject[]> {
  return sanitizeProjectList(await get<unknown>(PROJECTS_KEY, forgeStore));
}

export async function saveProject(
  name: string,
  settings: MeshBuildSettings,
  thumbnailDataUrl: string | null
): Promise<StoredProject> {
  const project: StoredProject = {
    id: newId(),
    name: name.trim() || settings.assetName || 'پروژه بدون نام',
    settings: mergeStoredSettings(settings),
    thumbnailDataUrl,
    updatedAt: Date.now(),
  };
  const list = await listProjects();
  list.unshift(project);
  await set(PROJECTS_KEY, list, forgeStore);
  return project;
}

export async function deleteProject(id: string): Promise<void> {
  const list = await listProjects();
  await set(
    PROJECTS_KEY,
    list.filter((p) => p.id !== id),
    forgeStore
  );
}
