import type { ExportTargetId } from './targets';

export type MeshGenerationMode = 'sculpted' | 'lathe' | 'voxel';
export type CutoutMethod = 'flood' | 'ml'; // 'flood' = offline flood-fill (default); 'ml' = @imgly/background-removal (ONNX/WASM, model downloads on first use)
export type PivotMode = 'bottom_center' | 'center';
export type LightingPreset = 'studio' | 'godot_sky' | 'dark_forge';
export type CameraPreset = 'perspective' | 'front' | 'back' | 'side' | 'top';
export type ViewportRenderMode = 'pbr' | 'wireframe' | 'normals';
export type TextureResolution = 512 | 1024 | 2048;

export interface MeshPolishProfile {
  enabled: boolean;
  summary: string;
  laplacianIterations: number; // 0..5 Taubin volume-preserving smoothing passes
  taubinLambda: number; // 0.15..0.65
  edgeBevelStrength: number; // 0..1 silhouette rim rounding
  microDisplacement: number; // -0.06..0.14 high-frequency relief boost
  detailSharpen: number; // 0..2.0 unsharp detail boost
  cavityAoIntensity: number; // 0..1.0 baked vertex ambient occlusion in crevices
  clearcoat: number; // 0..1.0 physical clearcoat
  clearcoatRoughness: number; // 0.05..0.8
  envMapIntensity: number; // 0.5..2.2
  normalStrengthOverride?: number;
  roughnessOverride?: number;
  metalnessOverride?: number;
}

export const DEFAULT_POLISH_PROFILE: MeshPolishProfile = {
  enabled: false,
  summary: '',
  laplacianIterations: 2,
  taubinLambda: 0.42,
  edgeBevelStrength: 0.3,
  microDisplacement: 0.0,
  detailSharpen: 0.0,
  cavityAoIntensity: 0.0,
  clearcoat: 0.0,
  clearcoatRoughness: 0.2,
  envMapIntensity: 1.0,
};

export interface MeshBuildSettings {
  assetName: string;
  mode: MeshGenerationMode;
  resolution: number; // 32..192
  targetWidthMeters: number; // 0.05..20.0 real-world scale in meters
  targetTriangleBudget: number; // 1000..60000 FPS/asset budget
  autoDecimate: boolean; // Meshopt edge-collapse decimation when exceeding budget
  cutoutEnabled: boolean;
  cutoutMethod: CutoutMethod; // flood-fill default keeps offline behavior; 'ml' uses the ML cutout instead
  cutoutTolerance: number; // 0.03..0.55 (flood-fill only)
  edgeErode: number; // 0..3 px
  depthScale: number; // 0.02..2.0 meters
  balloonWeight: number; // 0..1
  detailWeight: number; // 0..1
  invertDepth: boolean;
  smoothPasses: number; // 0..6
  silhouetteTaubinPasses: number; // 0..4 default anti-staircase smoothing
  doubleSidedSymmetry: boolean;
  latheSegments: number; // 16..64
  textureResolution: TextureResolution; // 512 | 1024 | 2048
  autoMaterialSegmentation: boolean; // Per-pixel wood/metal/matte PBR segmentation
  materialSensitivity: number; // 0.2..1.5
  roughness: number; // 0.05..1.0
  metalness: number; // 0.0..1.0
  normalStrength: number; // 0.0..2.5
  flatShading: boolean;
  godotCollisionSuffix: boolean;
  optimizeGltfOnExport: boolean;
  webpTextures: boolean; // WebP texture compression on GLB export (EXT_texture_webp); Godot 4.7 reads it — verified headless 2026-11-15
  /** Export target engine (F-32). Default 'godot' keeps v2 behaviour. */
  exportTarget: ExportTargetId;
  pivotMode: PivotMode;
  polish: MeshPolishProfile;
}

export const DEFAULT_MESH_SETTINGS: MeshBuildSettings = {
  assetName: 'GameAsset_3D',
  mode: 'sculpted',
  resolution: 112,
  targetWidthMeters: 1.0,
  targetTriangleBudget: 12000,
  autoDecimate: false,
  cutoutEnabled: true,
  cutoutMethod: 'flood',
  cutoutTolerance: 0.16,
  edgeErode: 1,
  depthScale: 0.22,
  balloonWeight: 0.68,
  detailWeight: 0.32,
  invertDepth: false,
  smoothPasses: 2,
  silhouetteTaubinPasses: 2,
  doubleSidedSymmetry: true,
  latheSegments: 36,
  textureResolution: 1024,
  autoMaterialSegmentation: true,
  materialSensitivity: 1.0,
  roughness: 0.52,
  metalness: 0.18,
  normalStrength: 1.15,
  flatShading: false,
  godotCollisionSuffix: true,
  optimizeGltfOnExport: true,
  webpTextures: true,
  exportTarget: 'godot',
  pivotMode: 'bottom_center',
  polish: DEFAULT_POLISH_PROFILE,
};

export interface MeshValidationReport {
  isWatertight: boolean;
  openBoundaryEdges: number;
  degenerateTriangles: number;
  hasInvalidPositions: boolean;
  withinTriangleBudget: boolean;
  triangleBudget: number;
  decimatedFromTriangles: number | null;
}

export interface MeshStats {
  meshCount: number;
  triangleCount: number;
  vertexCount: number;
  materialCount: number;
  foregroundCoveragePct: number;
  metallicSurfacePct: number;
  hasBackImage: boolean;
  textureResolution: string;
  polishActive: boolean;
  boundsMeters: {
    width: number;
    height: number;
    depth: number;
  };
  validation: MeshValidationReport;
}

export const EMPTY_VALIDATION: MeshValidationReport = {
  isWatertight: true,
  openBoundaryEdges: 0,
  degenerateTriangles: 0,
  hasInvalidPositions: false,
  withinTriangleBudget: true,
  triangleBudget: DEFAULT_MESH_SETTINGS.targetTriangleBudget,
  decimatedFromTriangles: null,
};

export interface GeneratedTexturesPreview {
  cutoutMaskUrl: string;
  normalMapUrl: string;
  roughnessMapUrl: string;
  metalnessMapUrl: string;
}

export function sanitizeAsciiNodeName(raw: string, fallback = 'GameAsset_3D'): string {
  const cleaned = raw
    .trim()
    .replace(/[^a-zA-Z0-9_-]+/g, '_')
    .replace(/^_+|_+$/g, '');
  if (!cleaned) return fallback;
  return /^[0-9]/.test(cleaned) ? `Asset_${cleaned}` : cleaned;
}

export function clampNum(val: unknown, min: number, max: number, fallback: number): number {
  if (typeof val !== 'number' || !Number.isFinite(val)) return fallback;
  return Math.min(max, Math.max(min, val));
}
