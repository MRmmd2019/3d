// F-27 — File System Access API (Godot 3D Forge v3).
//
// - Open a folder of photos for batch processing (read image files from a
//   picked directory).
// - Save a GLB directly into a picked folder.
// Both feature-detect the API and fall back to the normal file-input /
// download flow on unsupported browsers — nothing here ever crashes when
// the API is missing, and a cancelled picker is not an error.

import * as THREE from 'three';
import { GLTFExporter } from 'three/examples/jsm/exporters/GLTFExporter.js';
import { optimizeGlbBinary } from './optimizeGlb';
import { sanitizeAsciiNodeName } from './meshTypes';

// Minimal local typings: the File System Access API is not in TS's DOM lib.
interface FileSystemWritableFileStreamLike extends WritableStream {
  write(data: Blob | BufferSource | string): Promise<void>;
  close(): Promise<void>;
}

interface FileSystemFileHandleLike {
  getFile(): Promise<File>;
  createWritable(): Promise<FileSystemWritableFileStreamLike>;
}

interface FileSystemDirectoryHandleLike {
  getFileHandle(
    name: string,
    options?: { create?: boolean }
  ): Promise<FileSystemFileHandleLike>;
  values(): AsyncIterableIterator<FileSystemFileHandleLike | FileSystemDirectoryHandleLike>;
}

interface WindowWithFSA {
  showDirectoryPicker?: (options?: {
    mode?: 'read' | 'readwrite';
    id?: string;
    startIn?: string;
  }) => Promise<FileSystemDirectoryHandleLike>;
}

function isFileHandle(
  handle: FileSystemFileHandleLike | FileSystemDirectoryHandleLike
): handle is FileSystemFileHandleLike {
  return typeof (handle as FileSystemFileHandleLike).getFile === 'function';
}

export function supportsFileSystemAccess(): boolean {
  return (
    typeof window !== 'undefined' &&
    typeof (window as unknown as WindowWithFSA).showDirectoryPicker === 'function'
  );
}

function isAbortError(err: unknown): boolean {
  return err instanceof DOMException && err.name === 'AbortError';
}

/**
 * Pick a directory and return its image files (sorted by name).
 * Returns null when the API is unsupported or the user cancels the picker.
 */
export async function pickPhotoDirectory(): Promise<File[] | null> {
  if (!supportsFileSystemAccess()) return null;
  try {
    const dir = await (window as unknown as WindowWithFSA).showDirectoryPicker!({
      mode: 'read',
      id: 'godot-3d-forge-photos',
    });
    const files: File[] = [];
    for await (const handle of dir.values()) {
      if (!isFileHandle(handle)) continue;
      const file = await handle.getFile();
      if (file.type.startsWith('image/')) files.push(file);
    }
    files.sort((a, b) => a.name.localeCompare(b.name));
    return files;
  } catch (err: unknown) {
    if (isAbortError(err)) return null;
    throw err;
  }
}

export type SaveToFolderResult = 'saved' | 'unsupported' | 'cancelled';

/** Write a blob into a user-picked folder (asks once per call). */
export async function saveBlobToDirectory(
  blob: Blob,
  filename: string
): Promise<SaveToFolderResult> {
  if (!supportsFileSystemAccess()) return 'unsupported';
  try {
    const dir = await (window as unknown as WindowWithFSA).showDirectoryPicker!({
      mode: 'readwrite',
      id: 'godot-3d-forge-export',
    });
    const handle = await dir.getFileHandle(filename, { create: true });
    const writable = await handle.createWritable();
    await writable.write(blob);
    await writable.close();
    return 'saved';
  } catch (err: unknown) {
    if (isAbortError(err)) return 'cancelled';
    throw err;
  }
}

/** Plain anchor download — the fallback when FSA is unavailable. */
export function downloadBlob(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

function exportGroupToGlbBlob(
  group: THREE.Group,
  optimizeGltf: boolean
): Promise<Blob> {
  group.updateMatrixWorld(true);
  const exporter = new GLTFExporter();
  return new Promise<Blob>((resolve, reject) => {
    exporter.parse(
      group,
      (output) => {
        void (async () => {
          try {
            if (!(output instanceof ArrayBuffer)) {
              throw new Error('خروجی GLB باینری نبود.');
            }
            const finalBytes = optimizeGltf
              ? await optimizeGlbBinary(output).catch(
                  () => new Uint8Array(output)
                )
              : new Uint8Array(output);
            const copy = new Uint8Array(finalBytes.byteLength);
            copy.set(finalBytes);
            resolve(new Blob([copy.buffer], { type: 'model/gltf-binary' }));
          } catch (err: unknown) {
            reject(err instanceof Error ? err : new Error('GLB export failed'));
          }
        })();
      },
      (error) => reject(error instanceof Error ? error : new Error('GLB export failed')),
      { binary: true, onlyVisible: true, trs: false }
    );
  });
}

/**
 * Save the current mesh as GLB into a user-picked folder when FSA is
 * available; otherwise fall back to the normal browser download.
 * Returns 'saved' | 'downloaded' | 'cancelled'.
 */
export async function saveGlbToFolder(
  group: THREE.Group,
  baseFilename: string,
  options: { optimizeGltf?: boolean } = {}
): Promise<'saved' | 'downloaded' | 'cancelled'> {
  const safeName = sanitizeAsciiNodeName(baseFilename, 'GameAsset_3D');
  const blob = await exportGroupToGlbBlob(group, options.optimizeGltf ?? true);
  const filename = `${safeName}.glb`;
  const result = await saveBlobToDirectory(blob, filename);
  if (result === 'saved') return 'saved';
  if (result === 'cancelled') return 'cancelled';
  downloadBlob(blob, filename);
  return 'downloaded';
}
