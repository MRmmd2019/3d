import { WebIO } from '@gltf-transform/core';
import { Document } from '@gltf-transform/core';
import { describe, expect, it } from 'vitest';
import { mlAlphaMaskFromRgba } from '../mlCutout';
import { runMeshBuildPipeline } from '../meshPipeline';
import { DEFAULT_MESH_SETTINGS } from '../meshTypes';
import { optimizeGlbBinary } from '../optimizeGlb';

function makeRgbaGrid(
  cols: number,
  rows: number,
  painter: (x: number, y: number) => [number, number, number, number]
): Uint8ClampedArray {
  const arr = new Uint8ClampedArray(cols * rows * 4);
  for (let y = 0; y < rows; y++) {
    for (let x = 0; x < cols; x++) {
      const [r, g, b, a] = painter(x, y);
      const p = (y * cols + x) * 4;
      arr[p] = r;
      arr[p + 1] = g;
      arr[p + 2] = b;
      arr[p + 3] = a;
    }
  }
  return arr;
}

describe('cutout method defaults (F-22)', () => {
  it('defaults to flood-fill so offline behavior is preserved', () => {
    expect(DEFAULT_MESH_SETTINGS.cutoutMethod).toBe('flood');
  });

  it('defaults WebP texture compression on (F-23, Godot 4.7 verified)', () => {
    expect(DEFAULT_MESH_SETTINGS.webpTextures).toBe(true);
  });
});

describe('mlAlphaMaskFromRgba', () => {
  it('converts the ML-cut alpha channel into a binary mask', () => {
    const cols = 4;
    const rows = 2;
    const rgba = makeRgbaGrid(cols, rows, (x) =>
      x < 2 ? [200, 100, 50, 255] : [0, 0, 0, 0]
    );
    const mask = mlAlphaMaskFromRgba(rgba, cols, rows);
    expect(mask[0]).toBe(1);
    expect(mask[1]).toBe(1);
    expect(mask[2]).toBe(0);
    expect(mask[3]).toBe(0);
    expect(mask[cols]).toBe(1);
    expect(mask[cols + 3]).toBe(0);
  });

  it('treats alpha at the threshold as background, above it as foreground', () => {
    const rgba = new Uint8ClampedArray([10, 10, 10, 35, 10, 10, 10, 36]);
    const mask = mlAlphaMaskFromRgba(rgba, 2, 1);
    expect(mask[0]).toBe(0);
    expect(mask[1]).toBe(1);
  });
});

describe('runMeshBuildPipeline ML mask wiring (F-22)', () => {
  const cols = 32;
  const rows = 24;
  const mapW = 32;
  const mapH = 24;

  // Flood-fill sees a brown box (x 6..25, y 5..18) on a dark-blue backdrop.
  const frontSeg = makeRgbaGrid(cols, rows, (x, y) =>
    x >= 6 && x <= 25 && y >= 5 && y <= 18
      ? [120, 70, 40, 255]
      : [20, 30, 60, 255]
  );

  // ML mask covers exactly the left half — deliberately different from the flood box.
  const mlMask = new Uint8Array(cols * rows);
  for (let y = 0; y < rows; y++) {
    for (let x = 0; x < 16; x++) mlMask[y * cols + x] = 1;
  }

  function runWith(settingsOverride: Record<string, unknown>, mask?: Uint8Array) {
    return runMeshBuildPipeline({
      cols,
      rows,
      aspect: 4 / 3,
      frontSegRgba: frontSeg,
      backSegRgba: null,
      mapW,
      mapH,
      frontMapRgba: frontSeg,
      backMapRgba: null,
      mlMask: mask ?? null,
      settings: { ...DEFAULT_MESH_SETTINGS, resolution: 32, ...settingsOverride },
    });
  }

  it('uses the ML mask as the mask source when cutoutMethod is ml', () => {
    const out = runWith({ cutoutMethod: 'ml' }, mlMask);
    // Left half = 384/768 px = exactly 50%.
    expect(out.foregroundCoveragePct).toBe(50);
    // Mask preview shows foreground color inside the ML mask, checker outside.
    const inside = 2 * cols + 2;
    expect(out.maskPreviewRgba[inside * 4]).toBe(20);
    expect(out.maskPreviewRgba[inside * 4 + 2]).toBe(60);
    const outside = 2 * cols + 20;
    expect(out.maskPreviewRgba[outside * 4]).not.toBe(20);
  });

  it('ignores a supplied ML mask when cutoutMethod is flood', () => {
    const out = runWith({ cutoutMethod: 'flood' }, mlMask);
    // Flood box 20×14, eroded 1px rim → 18×12 = 216/768 ≈ 28% — not the ML mask's 50%.
    expect(out.foregroundCoveragePct).toBeGreaterThan(25);
    expect(out.foregroundCoveragePct).toBeLessThan(32);
  });

  it('falls back to flood-fill when cutoutMethod is ml but no mask is supplied', () => {
    const out = runWith({ cutoutMethod: 'ml' });
    expect(out.foregroundCoveragePct).toBeGreaterThan(25);
    expect(out.foregroundCoveragePct).toBeLessThan(32);
    expect(out.validation.isWatertight).toBe(true);
  });
});

describe('optimizeGlbBinary (F-23)', () => {
  async function makeTinyGlb(): Promise<ArrayBuffer> {
    const doc = new Document();
    const buffer = doc.createBuffer();
    const pos = doc
      .createAccessor()
      .setType('VEC3')
      .setArray(new Float32Array([0, 0, 0, 1, 0, 0, 0, 1, 0]))
      .setBuffer(buffer);
    const prim = doc.createPrimitive().setAttribute('POSITION', pos);
    const mesh = doc.createMesh().addPrimitive(prim);
    const node = doc.createNode().setMesh(mesh);
    doc.createScene().addChild(node); // keep the node referenced so prune() keeps it
    const io = new WebIO();
    const bin = await io.writeBinary(doc);
    const copy = new Uint8Array(bin.byteLength);
    copy.set(bin);
    return copy.buffer as ArrayBuffer;
  }

  it('optimizes a GLB without WebP and returns a re-readable GLB', async () => {
    const raw = await makeTinyGlb();
    const out = await optimizeGlbBinary(raw, { webpTextures: false });
    expect(out.byteLength).toBeGreaterThan(0);
    const io = new WebIO();
    const doc = await io.readBinary(out);
    expect(doc.getRoot().listMeshes().length).toBe(1);
  });

  it('rejects empty input', async () => {
    await expect(optimizeGlbBinary(new ArrayBuffer(0))).rejects.toThrow();
  });
});
