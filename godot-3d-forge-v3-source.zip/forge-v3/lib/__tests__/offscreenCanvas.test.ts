import { afterEach, describe, expect, it, vi } from 'vitest';
import { canUseWorkerImageSampling } from '../meshEngine';
import {
  isOffscreenCanvasAvailable,
  sampleImageBitmapOffscreen,
} from '../meshBuildWorker';

describe('F-28 OffscreenCanvas in the worker (feature detection + fallback)', () => {
  afterEach(() => {
    vi.unstubAllGlobals();
  });

  it('reports worker sampling unavailable in Node (no OffscreenCanvas)', () => {
    expect(isOffscreenCanvasAvailable()).toBe(false);
    expect(canUseWorkerImageSampling()).toBe(false);
  });

  it('sampleImageBitmapOffscreen throws when OffscreenCanvas is missing', () => {
    expect(() =>
      sampleImageBitmapOffscreen({} as ImageBitmap, 2, 2)
    ).toThrow('OffscreenCanvas is not available');
  });

  it('samples pixels through a fake OffscreenCanvas when available', () => {
    const pixels = new Uint8ClampedArray([
      10, 20, 30, 255, 40, 50, 60, 255, 70, 80, 90, 255, 100, 110, 120, 255,
    ]);
    const drawn: Array<{ w: number; h: number }> = [];
    class FakeContext {
      drawImage(_bitmap: unknown, _x: number, _y: number, w: number, h: number) {
        drawn.push({ w, h });
      }
      getImageData() {
        return { data: pixels, width: 2, height: 2 };
      }
    }
    class FakeOffscreenCanvas {
      constructor(
        public width: number,
        public height: number
      ) {}
      getContext() {
        return new FakeContext();
      }
    }
    vi.stubGlobal('OffscreenCanvas', FakeOffscreenCanvas);

    expect(isOffscreenCanvasAvailable()).toBe(true);
    const out = sampleImageBitmapOffscreen({} as ImageBitmap, 2, 2);
    expect(out).toEqual(pixels);
    expect(drawn).toEqual([{ w: 2, h: 2 }]);
  });
});
