import 'fake-indexeddb/auto';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import {
  DEFAULT_MESH_SETTINGS,
  DEFAULT_POLISH_PROFILE,
} from '../meshTypes';
import {
  deletePreset,
  deleteProject,
  listPresets,
  listProjects,
  loadStoredSettings,
  mergeStoredSettings,
  savePreset,
  saveProject,
  saveStoredSettings,
  SETTINGS_STORAGE_KEY,
} from '../persistence';

// Minimal localStorage stand-in for the Node test environment.
const lsStore = new Map<string, string>();
vi.stubGlobal('localStorage', {
  getItem: (key: string) => lsStore.get(key) ?? null,
  setItem: (key: string, value: string) => {
    lsStore.set(key, value);
  },
  removeItem: (key: string) => {
    lsStore.delete(key);
  },
  clear: () => lsStore.clear(),
});

describe('F-25 settings persistence (localStorage)', () => {
  beforeEach(() => {
    lsStore.clear();
  });

  it('returns the defaults for missing, corrupt or non-object stored values', () => {
    expect(loadStoredSettings()).toBeNull();
    lsStore.set(SETTINGS_STORAGE_KEY, 'not-json{');
    expect(loadStoredSettings()).toBeNull();
    expect(mergeStoredSettings(null)).toEqual(DEFAULT_MESH_SETTINGS);
    expect(mergeStoredSettings('garbage')).toEqual(DEFAULT_MESH_SETTINGS);
    expect(mergeStoredSettings(42)).toEqual(DEFAULT_MESH_SETTINGS);
  });

  it('merges a partial stored value over the defaults, keeping unknown keys out', () => {
    const merged = mergeStoredSettings({
      resolution: 150,
      mode: 'lathe',
      assetName: 'MyAsset',
      polish: { enabled: true, clearcoat: 0.5 },
      unknownFutureKey: true,
    });
    expect(merged.resolution).toBe(150);
    expect(merged.mode).toBe('lathe');
    expect(merged.assetName).toBe('MyAsset');
    expect(merged.polish.enabled).toBe(true);
    expect(merged.polish.clearcoat).toBe(0.5);
    expect(merged.polish.taubinLambda).toBe(DEFAULT_POLISH_PROFILE.taubinLambda);
    expect(merged.targetWidthMeters).toBe(DEFAULT_MESH_SETTINGS.targetWidthMeters);
    expect('unknownFutureKey' in merged).toBe(false);
  });

  it('ignores wrong-typed values and invalid enums, falling back to defaults', () => {
    const merged = mergeStoredSettings({
      resolution: 'high',
      mode: 'banana',
      pivotMode: 'sideways',
      textureResolution: 777,
      targetWidthMeters: 2.5,
    });
    expect(merged.resolution).toBe(DEFAULT_MESH_SETTINGS.resolution);
    expect(merged.mode).toBe('sculpted');
    expect(merged.pivotMode).toBe('bottom_center');
    expect(merged.textureResolution).toBe(1024);
    expect(merged.targetWidthMeters).toBe(2.5);
  });

  it('round-trips settings through save + load', () => {
    const custom = {
      ...DEFAULT_MESH_SETTINGS,
      resolution: 96,
      mode: 'voxel' as const,
      polish: { ...DEFAULT_POLISH_PROFILE, enabled: true, clearcoat: 0.25 },
    };
    saveStoredSettings(custom);
    expect(loadStoredSettings()).toEqual(custom);
  });

  it('save never throws when storage is unavailable', () => {
    vi.stubGlobal('localStorage', undefined);
    expect(() => saveStoredSettings(DEFAULT_MESH_SETTINGS)).not.toThrow();
    expect(loadStoredSettings()).toBeNull();
  });
});

describe('F-26 presets & projects (IndexedDB via idb-keyval)', () => {
  it('starts empty', async () => {
    expect(await listPresets()).toEqual([]);
    expect(await listProjects()).toEqual([]);
  });

  it('saves, lists and deletes a preset (settings snapshot + name)', async () => {
    const settings = { ...DEFAULT_MESH_SETTINGS, resolution: 80, assetName: 'Rifle' };
    const preset = await savePreset('چوب تیره', settings);
    expect(preset.name).toBe('چوب تیره');
    expect(preset.settings.resolution).toBe(80);

    const listed = await listPresets();
    expect(listed).toHaveLength(1);
    expect(listed[0].id).toBe(preset.id);
    expect(listed[0].settings.assetName).toBe('Rifle');

    await deletePreset(preset.id);
    expect(await listPresets()).toEqual([]);
  });

  it('saves, lists and deletes a project (settings + thumbnail data URL)', async () => {
    const settings = { ...DEFAULT_MESH_SETTINGS, assetName: 'Crate' };
    const thumb = 'data:image/png;base64,iVBORw0KGgo=';
    const project = await saveProject('جعبه', settings, thumb);
    expect(project.thumbnailDataUrl).toBe(thumb);

    const listed = await listProjects();
    expect(listed).toHaveLength(1);
    expect(listed[0].settings.assetName).toBe('Crate');
    expect(listed[0].thumbnailDataUrl).toBe(thumb);

    await deleteProject(project.id);
    expect(await listProjects()).toEqual([]);
  });

  it('keeps newest-first order', async () => {
    const a = await savePreset('اول', DEFAULT_MESH_SETTINGS);
    const b = await savePreset('دوم', DEFAULT_MESH_SETTINGS);
    const listed = await listPresets();
    expect(listed.map((p) => p.id)).toEqual([b.id, a.id]);
    await deletePreset(a.id);
    await deletePreset(b.id);
  });
});
