import { describe, expect, it } from 'vitest';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import sharp from 'sharp';
import {
  buildMeshGlb,
  decodeImageToRgba,
  encodeRgbaToPng,
  readGlbMeshStats,
  validateGlbBytes,
  writeFile,
} from '../node-shim';

async function makeTestPng(path: string): Promise<void> {
  // 128x96: dark crate rectangle on a plain light background.
  const raw = Buffer.alloc(128 * 96 * 4);
  for (let y = 0; y < 96; y++) {
    for (let x = 0; x < 128; x++) {
      const p = (y * 128 + x) * 4;
      const inside = x >= 24 && x < 104 && y >= 20 && y < 76;
      raw[p] = inside ? 122 : 240;
      raw[p + 1] = inside ? 74 : 240;
      raw[p + 2] = inside ? 38 : 245;
      raw[p + 3] = 255;
    }
  }
  await sharp(raw, { raw: { width: 128, height: 96, channels: 4 } })
    .png()
    .toFile(path);
}

describe('node-shim image primitives', () => {
  it('round-trips RGBA through encodeRgbaToPng + decodeImageToRgba', async () => {
    const dir = await mkdtemp(join(tmpdir(), 'forge-shim-'));
    try {
      const pngPath = join(dir, 'roundtrip.png');
      const rgba = new Uint8ClampedArray([
        10, 20, 30, 255, 200, 150, 100, 255, 0, 0, 0, 255, 255, 255, 255, 255,
      ]);
      const png = await encodeRgbaToPng(rgba, 2, 2);
      await writeFile(pngPath, png);
      const decoded = await decodeImageToRgba(pngPath);
      expect(decoded.width).toBe(2);
      expect(decoded.height).toBe(2);
      expect(Array.from(decoded.data)).toEqual(Array.from(rgba));
    } finally {
      await rm(dir, { recursive: true, force: true });
    }
  });

  it('decodeImageToRgba rejects a missing file with a clear error', async () => {
    await expect(decodeImageToRgba('/definitely/not/here.png')).rejects.toThrow();
  });
});

describe('buildMeshGlb (Node path through the engine core)', () => {
  it('builds a valid GLB from a synthetic crate photo', async () => {
    const dir = await mkdtemp(join(tmpdir(), 'forge-shim-'));
    try {
      const photo = join(dir, 'crate.png');
      await makeTestPng(photo);

      const result = await buildMeshGlb({
        frontPath: photo,
        target: 'godot',
        widthMeters: 0.88,
        resolution: 32,
        textureResolution: 512,
        assetName: 'TestCrate',
      });

      expect(result.sizeBytes).toBeGreaterThan(1000);
      expect(result.triangles).toBeGreaterThan(0);
      expect(result.vertices).toBeGreaterThan(0);
      expect(result.target).toBe('godot');
      expect(result.widthMeters).toBe(0.88);
      expect(result.watertight).toBe(true);
      expect(result.openBoundaryEdges).toBe(0);
      expect(result.boundsMeters.width).toBeGreaterThan(0.5);
      expect(result.boundsMeters.width).toBeLessThanOrEqual(0.89);

      // GLB magic header + parseable geometry.
      expect(String.fromCharCode(...result.glbBytes.subarray(0, 4))).toBe('glTF');
      const stats = await readGlbMeshStats(result.glbBytes);
      expect(stats.meshes).toBe(1);
      expect(stats.triangles).toBe(result.triangles);
      expect(stats.materials).toBe(1);
      expect(stats.textures).toBe(3); // albedo + normal + ORM

      const validation = await validateGlbBytes(result.glbBytes);
      expect(validation.valid).toBe(true);
      expect(validation.triangles).toBe(result.triangles);
    } finally {
      await rm(dir, { recursive: true, force: true });
    }
  }, 60000);
});
