import * as THREE from 'three';
import { describe, expect, it } from 'vitest';
import {
  generateBlenderPythonScript,
  generateGodot4Script,
  generateTargetScript,
  generateUnityCSharpScript,
  generateUnrealPythonScript,
  prepareExportGroup,
} from '../godotExport';
import { DEFAULT_MESH_SETTINGS, EMPTY_VALIDATION, type MeshStats } from '../meshTypes';
import { getExportTarget } from '../targets';

const STATS: MeshStats = {
  meshCount: 1,
  triangleCount: 1234,
  vertexCount: 800,
  materialCount: 1,
  foregroundCoveragePct: 55,
  metallicSurfacePct: 10,
  hasBackImage: false,
  textureResolution: '1024×1024',
  polishActive: false,
  boundsMeters: { width: 1, height: 0.5, depth: 0.25 },
  validation: { ...EMPTY_VALIDATION, triangleBudget: 12000 },
};

const SETTINGS = { ...DEFAULT_MESH_SETTINGS, assetName: 'TestRifle' };

describe('target script generators (F-37..F-39)', () => {
  it('unity C# is a MonoBehaviour with spin/pickup and a glTFast note', () => {
    const script = generateUnityCSharpScript(SETTINGS, STATS);
    expect(script).toContain('public class TestRifleController : MonoBehaviour');
    expect(script).toContain('glTFast');
    expect(script).toContain('spinSpeed');
    expect(script).toContain('PickUp');
    expect(script).toContain('MeshCollider');
  });

  it('unreal python imports the GLB, spawns an actor, and notes cm scale', () => {
    const script = generateUnrealPythonScript(SETTINGS, STATS);
    expect(script).toContain('AssetImportTask');
    expect(script).toContain('spawn_actor_from_object');
    expect(script).toContain('centimeters');
    expect(script).toContain('UCX_TestRifle_Mesh');
    expect(script).toContain('import unreal');
  });

  it('blender python imports the GLB, wires Principled BSDF, and adds a turntable', () => {
    const script = generateBlenderPythonScript(SETTINGS, STATS);
    expect(script).toContain('import_scene.gltf');
    expect(script).toContain('BSDF_PRINCIPLED');
    expect(script).toContain('"Turntable_" + ASSET_NAME');
    expect(script).toContain('BLENDER_SETUP_OK');
    expect(script).toContain('import bpy');
  });

  it('generateTargetScript routes by target and generic has no script', () => {
    expect(generateTargetScript(getExportTarget('unity'), SETTINGS, STATS)).toContain(
      'MonoBehaviour'
    );
    expect(generateTargetScript(getExportTarget('unreal'), SETTINGS, STATS)).toContain(
      'import unreal'
    );
    expect(generateTargetScript(getExportTarget('blender'), SETTINGS, STATS)).toContain(
      'import bpy'
    );
    expect(generateTargetScript(getExportTarget('godot'), SETTINGS, STATS)).toBe(
      generateGodot4Script(SETTINGS, STATS)
    );
    expect(generateTargetScript(getExportTarget('generic'), SETTINGS, STATS)).toBe('');
  });
});

describe('prepareExportGroup (F-33/F-36)', () => {
  function makeGroup(): THREE.Group {
    const group = new THREE.Group();
    group.name = 'TestRifle';
    const mesh = new THREE.Mesh(
      new THREE.BoxGeometry(1, 0.5, 0.25),
      new THREE.MeshStandardMaterial()
    );
    mesh.name = 'TestRifle_Mesh-col';
    mesh.position.set(0.2, 0.25, 0);
    group.add(mesh);
    group.updateMatrixWorld(true);
    return group;
  }

  it('godot returns the live group untouched', () => {
    const group = makeGroup();
    const prepared = prepareExportGroup(group, getExportTarget('godot'));
    expect(prepared.group).toBe(group);
    prepared.cleanup();
  });

  it('generic returns the live group untouched', () => {
    const group = makeGroup();
    const prepared = prepareExportGroup(group, getExportTarget('generic'));
    expect(prepared.group).toBe(group);
    prepared.cleanup();
  });

  it('unreal clones, renames to UCX_, and bakes the x100 cm scale', () => {
    const group = makeGroup();
    const prepared = prepareExportGroup(group, getExportTarget('unreal'));
    expect(prepared.group).not.toBe(group);
    const mesh = prepared.group.children[0] as THREE.Mesh;
    expect(mesh.name).toBe('UCX_TestRifle_Mesh');
    // BoxGeometry x half-extent 0.5, pivot offset x +0.2 -> baked max x = 70
    const pos = mesh.geometry.getAttribute('position') as THREE.BufferAttribute;
    let maxX = -Infinity;
    for (let i = 0; i < pos.count; i++) maxX = Math.max(maxX, pos.getX(i));
    expect(maxX).toBeCloseTo(70, 5);
    // live group untouched
    const liveMesh = group.children[0] as THREE.Mesh;
    expect(liveMesh.name).toBe('TestRifle_Mesh-col');
    expect(liveMesh.position.x).toBe(0.2);
    prepared.cleanup();
  });

  it('unity clones and strips -col with no scale change', () => {
    const group = makeGroup();
    const prepared = prepareExportGroup(group, getExportTarget('unity'));
    const mesh = prepared.group.children[0] as THREE.Mesh;
    expect(mesh.name).toBe('TestRifle_Mesh');
    const pos = mesh.geometry.getAttribute('position') as THREE.BufferAttribute;
    let maxX = -Infinity;
    for (let i = 0; i < pos.count; i++) maxX = Math.max(maxX, pos.getX(i));
    expect(maxX).toBeCloseTo(0.7, 5);
    prepared.cleanup();
  });
});
