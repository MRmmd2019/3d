import { describe, expect, it } from 'vitest';
import {
  EXPORT_TARGETS,
  flipNormalMapGreenChannel,
  getExportTarget,
  packUnityMetallicSmoothness,
  targetCollisionMeshName,
} from '../targets';

describe('target registry (F-32)', () => {
  it('registers exactly the five targets, godot first', () => {
    expect(EXPORT_TARGETS.map((t) => t.id)).toEqual([
      'godot',
      'unity',
      'unreal',
      'blender',
      'generic',
    ]);
  });

  it('every target has a script kind and a script file name rule', () => {
    for (const t of EXPORT_TARGETS) {
      expect(t.scriptKind).toBeDefined();
      if (t.scriptKind !== 'none') {
        expect(t.scriptFileName('TestAsset')).toContain('TestAsset');
      } else {
        expect(t.scriptFileName('TestAsset')).toBe('');
      }
    }
  });

  it('falls back to godot for unknown ids', () => {
    expect(getExportTarget('nope').id).toBe('godot');
    expect(getExportTarget('').id).toBe('godot');
  });
});

describe('per-target unit scale (F-33)', () => {
  it('unreal is centimeters (x100), every other target is meters (x1)', () => {
    expect(getExportTarget('unreal').unit).toBe('cm');
    expect(getExportTarget('unreal').unitScale).toBe(100);
    for (const id of ['godot', 'unity', 'blender', 'generic'] as const) {
      expect(getExportTarget(id).unit).toBe('m');
      expect(getExportTarget(id).unitScale).toBe(1);
    }
  });
});

describe('normal-map green-channel flip (F-34)', () => {
  it('flips only the green channel of a small RGBA array', () => {
    const input = new Uint8ClampedArray([
      128, 200, 64, 255,
      10, 0, 250, 128,
    ]);
    const out = flipNormalMapGreenChannel(input);
    expect(Array.from(out)).toEqual([128, 55, 64, 255, 10, 255, 250, 128]);
  });

  it('does not mutate the input and is its own inverse', () => {
    const input = new Uint8ClampedArray([1, 2, 3, 4, 250, 251, 252, 253]);
    const once = flipNormalMapGreenChannel(input);
    expect(Array.from(input)).toEqual([1, 2, 3, 4, 250, 251, 252, 253]);
    expect(Array.from(flipNormalMapGreenChannel(once))).toEqual(Array.from(input));
  });

  it('only the unreal target flips', () => {
    expect(getExportTarget('unreal').flipNormalGreen).toBe(true);
    for (const id of ['godot', 'unity', 'blender', 'generic'] as const) {
      expect(getExportTarget(id).flipNormalGreen).toBe(false);
    }
  });
});

describe('unity metallic+smoothness packing (F-35)', () => {
  it('packs R = metallic, A = smoothness = 1 - roughness, G/B = 0', () => {
    const metal = new Uint8ClampedArray([255, 255, 255, 255, 0, 0, 0, 255]);
    const rough = new Uint8ClampedArray([64, 64, 64, 255, 255, 255, 255, 255]);
    const out = packUnityMetallicSmoothness(metal, rough);
    // pixel 1: metal 255, roughness 64 -> smoothness 191
    // pixel 2: metal 0, roughness 255 -> smoothness 0
    expect(Array.from(out)).toEqual([255, 0, 0, 191, 0, 0, 0, 0]);
  });

  it('only unity uses the packed texture', () => {
    expect(getExportTarget('unity').texturePacking).toBe('unity-metallic-smoothness');
    for (const id of ['godot', 'unreal', 'blender', 'generic'] as const) {
      expect(getExportTarget(id).texturePacking).toBe('standard-gltf');
    }
  });
});

describe('per-target collision naming (F-36)', () => {
  it('godot keeps the -col suffix', () => {
    expect(targetCollisionMeshName('Rifle_Mesh-col', getExportTarget('godot'))).toBe(
      'Rifle_Mesh-col'
    );
  });

  it('unreal gets the UCX_ prefix and loses -col', () => {
    expect(targetCollisionMeshName('Rifle_Mesh-col', getExportTarget('unreal'))).toBe(
      'UCX_Rifle_Mesh'
    );
  });

  it('unity, blender and generic get the plain name', () => {
    for (const id of ['unity', 'blender', 'generic'] as const) {
      expect(targetCollisionMeshName('Rifle_Mesh-col', getExportTarget(id))).toBe(
        'Rifle_Mesh'
      );
    }
  });

  it('leaves a name without -col alone except for the target convention', () => {
    expect(targetCollisionMeshName('Rifle_Mesh', getExportTarget('unreal'))).toBe(
      'UCX_Rifle_Mesh'
    );
    expect(targetCollisionMeshName('Rifle_Mesh', getExportTarget('godot'))).toBe(
      'Rifle_Mesh-col'
    );
  });
});
