import { describe, expect, it } from 'vitest';
import {
  pickPhotoDirectory,
  saveBlobToDirectory,
  supportsFileSystemAccess,
} from '../fileSystemAccess';

describe('F-27 File System Access API (feature detection + fallback)', () => {
  it('reports unsupported in an environment without showDirectoryPicker', () => {
    expect(supportsFileSystemAccess()).toBe(false);
  });

  it('pickPhotoDirectory returns null when the API is unsupported', async () => {
    await expect(pickPhotoDirectory()).resolves.toBeNull();
  });

  it('saveBlobToDirectory reports unsupported instead of crashing', async () => {
    const blob = new Blob(['x'], { type: 'model/gltf-binary' });
    await expect(saveBlobToDirectory(blob, 'test.glb')).resolves.toBe('unsupported');
  });
});
