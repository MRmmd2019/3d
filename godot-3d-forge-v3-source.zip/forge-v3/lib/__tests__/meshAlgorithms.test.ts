import { describe, expect, it } from 'vitest';
import {
  applyTaubinSmoothingRaw,
  computeCylindricalLatheUv,
  computeForegroundMask,
  computeHeightField,
  segmentPbrMaterials,
  validateMeshTopology,
} from '../meshAlgorithms';
import { runMeshBuildPipeline } from '../meshPipeline';
import { DEFAULT_MESH_SETTINGS } from '../meshTypes';

function makeRgbaGrid(
  cols: number,
  rows: number,
  painter: (x: number, y: number) => [number, number, number, number]
): Uint8ClampedArray {
  const arr = new Uint8ClampedArray(cols * rows * 4);
  for (let y = 0; y < rows; y++) {
    for (let x = 0; x < cols; x++) {
      const [r, g, b, a] = painter(x, y);
      const p = (y * cols + x) * 4;
      arr[p] = r;
      arr[p + 1] = g;
      arr[p + 2] = b;
      arr[p + 3] = a;
    }
  }
  return arr;
}

describe('computeForegroundMask', () => {
  it('separates a solid foreground box from a uniform background', () => {
    const cols = 32;
    const rows = 32;
    const rgba = makeRgbaGrid(cols, rows, (x, y) => {
      if (x >= 8 && x <= 23 && y >= 8 && y <= 23) {
        return [160, 85, 35, 255]; // brown foreground
      }
      return [240, 240, 245, 255]; // bright studio backdrop
    });

    const res = computeForegroundMask(rgba, cols, rows, true, 0.16, 0);
    expect(res.mask[16 * cols + 16]).toBe(1);
    expect(res.mask[0]).toBe(0);
    expect(res.foregroundCoveragePct).toBeGreaterThan(20);
    expect(res.foregroundCoveragePct).toBeLessThan(35);
  });

  it('uses alpha channel directly when border has transparency', () => {
    const cols = 24;
    const rows = 24;
    const rgba = makeRgbaGrid(cols, rows, (x, y) => {
      const inside = x >= 6 && x <= 17 && y >= 6 && y <= 17;
      return inside ? [100, 100, 120, 255] : [0, 0, 0, 0];
    });

    const res = computeForegroundMask(rgba, cols, rows, true, 0.16, 1);
    expect(res.mask[12 * cols + 12]).toBe(1);
    expect(res.mask[6 * cols + 6]).toBe(0); // eroded 1px rim
  });
});

describe('computeHeightField', () => {
  it('inflates the center higher than foreground boundaries', () => {
    const cols = 25;
    const rows = 25;
    const rgba = makeRgbaGrid(cols, rows, () => [128, 128, 128, 255]);
    const mask = new Uint8Array(cols * rows);
    for (let y = 4; y <= 20; y++) {
      for (let x = 4; x <= 20; x++) {
        mask[y * cols + x] = 1;
      }
    }

    const hf = computeHeightField(rgba, mask, cols, rows, {
      balloonWeight: 0.85,
      detailWeight: 0.15,
      invertDepth: false,
      smoothPasses: 1,
    });

    const centerVal = hf[12 * cols + 12];
    const edgeVal = hf[4 * cols + 12];
    const bgVal = hf[0];
    expect(bgVal).toBe(0);
    expect(centerVal).toBeGreaterThan(edgeVal);
    expect(centerVal).toBeGreaterThan(0.7);
  });
});

describe('segmentPbrMaterials', () => {
  it('assigns matte dielectric roughness to warm wood and high metalness to dark steel', () => {
    const w = 16;
    const h = 16;
    const rgba = makeRgbaGrid(w, h, (x) =>
      x < 8 ? [138, 72, 32, 255] : [55, 62, 70, 255]
    );

    const seg = segmentPbrMaterials(rgba, w, h, 0.45, 0.15, true, 1.0);
    const woodIdx = 8 * w + 3;
    const steelIdx = 8 * w + 12;

    expect(seg.roughnessValues[woodIdx]).toBeGreaterThan(seg.roughnessValues[steelIdx]);
    expect(seg.metalnessValues[steelIdx]).toBeGreaterThan(seg.metalnessValues[woodIdx]);
    expect(seg.metalnessValues[woodIdx]).toBeLessThan(0.15);
    expect(seg.metalnessValues[steelIdx]).toBeGreaterThan(0.5);
  });
});

describe('applyTaubinSmoothingRaw', () => {
  it('reduces sharp local vertex spike while preserving mesh centroid', () => {
    // 5-vertex pyramid fan centered at (0,0,0) with center spike at z=1
    const positions = new Float32Array([
      0, 0, 1.0, // center spike
      -1, 0, 0,
      0, 1, 0,
      1, 0, 0,
      0, -1, 0,
    ]);
    const indices = new Uint32Array([
      0, 1, 2,
      0, 2, 3,
      0, 3, 4,
      0, 4, 1,
    ]);

    const initialZ = positions[2];
    applyTaubinSmoothingRaw(positions, indices, 3, 0.45);
    expect(positions[2]).toBeLessThan(initialZ);
    expect(Number.isFinite(positions[2])).toBe(true);
  });
});

describe('computeCylindricalLatheUv', () => {
  it('maps single-image lathe seam symmetrically without planar collapse', () => {
    const [uStart] = computeCylindricalLatheUv(0.0, 0.5, false);
    const [uMid] = computeCylindricalLatheUv(0.5, 0.5, false);
    const [uEnd] = computeCylindricalLatheUv(1.0, 0.5, false);

    expect(uStart).toBeCloseTo(0.01, 2);
    expect(uMid).toBeCloseTo(0.99, 2);
    expect(uEnd).toBeCloseTo(0.01, 2);
  });

  it('splits front and back halves across vertical UV atlas when back image is active', () => {
    const [, vFront] = computeCylindricalLatheUv(0.25, 0.5, true);
    const [, vBack] = computeCylindricalLatheUv(0.75, 0.5, true);

    expect(vFront).toBeGreaterThan(0.5);
    expect(vBack).toBeLessThan(0.5);
  });
});

describe('validateMeshTopology', () => {
  it('confirms a closed tetrahedron is watertight with 0 open edges', () => {
    const positions = new Float32Array([
      0, 0, 0,
      1, 0, 0,
      0, 1, 0,
      0, 0, 1,
    ]);
    const indices = new Uint32Array([
      0, 2, 1,
      0, 1, 3,
      1, 2, 3,
      2, 0, 3,
    ]);

    const report = validateMeshTopology(positions, indices, 100);
    expect(report.isWatertight).toBe(true);
    expect(report.openBoundaryEdges).toBe(0);
    expect(report.degenerateTriangles).toBe(0);
    expect(report.withinTriangleBudget).toBe(true);
  });

  it('flags open boundary edges, degenerate triangles, and budget overflow', () => {
    const positions = new Float32Array([
      0, 0, 0,
      1, 0, 0,
      0, 1, 0,
      0, 0, 0, // collapsed point
    ]);
    const indices = new Uint32Array([
      0, 1, 2, // open triangle (3 boundary edges)
      0, 1, 3, // degenerate zero-area triangle
    ]);

    const report = validateMeshTopology(positions, indices, 1);
    expect(report.isWatertight).toBe(false);
    expect(report.openBoundaryEdges).toBe(3);
    expect(report.degenerateTriangles).toBe(1);
    expect(report.withinTriangleBudget).toBe(false);
  });
});

describe('runMeshBuildPipeline integration', () => {
  it('builds a watertight sculpted mesh scaled to targetWidthMeters with dual-view atlas', () => {
    const cols = 32;
    const rows = 24;
    const mapW = 32;
    const mapH = 24;

    const frontSeg = makeRgbaGrid(cols, rows, (x, y) =>
      x >= 6 && x <= 25 && y >= 5 && y <= 18 ? [120, 70, 40, 255] : [250, 250, 250, 255]
    );
    const backSeg = makeRgbaGrid(cols, rows, (x, y) =>
      x >= 6 && x <= 25 && y >= 5 && y <= 18 ? [60, 65, 72, 255] : [250, 250, 250, 255]
    );

    const out = runMeshBuildPipeline({
      cols,
      rows,
      aspect: 4 / 3,
      frontSegRgba: frontSeg,
      backSegRgba: backSeg,
      mapW,
      mapH,
      frontMapRgba: frontSeg,
      backMapRgba: backSeg,
      settings: {
        ...DEFAULT_MESH_SETTINGS,
        targetWidthMeters: 0.88,
        resolution: 32,
      },
    });

    expect(out.hasBackImage).toBe(true);
    expect(out.atlasH).toBe(mapH * 2);
    expect(out.validation.isWatertight).toBe(true);
    expect(out.validation.openBoundaryEdges).toBe(0);
    expect(out.validation.degenerateTriangles).toBe(0);

    let minX = Infinity;
    let maxX = -Infinity;
    for (let i = 0; i < out.positions.length; i += 3) {
      if (out.positions[i] < minX) minX = out.positions[i];
      if (out.positions[i] > maxX) maxX = out.positions[i];
    }
    const spanX = maxX - minX;
    expect(spanX).toBeGreaterThan(0.5);
    expect(spanX).toBeLessThanOrEqual(0.89);
  });
});
