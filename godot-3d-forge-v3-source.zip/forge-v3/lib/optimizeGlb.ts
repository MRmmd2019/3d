import { WebIO } from '@gltf-transform/core';
import { EXTTextureWebP } from '@gltf-transform/extensions';
import { dedup, prune, textureCompress, weld } from '@gltf-transform/functions';

const MAX_GLB_BYTES = 25 * 1024 * 1024; // 25 MB safety cap

export interface OptimizeGlbOptions {
  /**
   * Convert textures to WebP (EXT_texture_webp) during optimization.
   * Default true: Godot 4.7 reads WebP textures in GLB — verified headless
   * 2026-11-15 (Godot_v4.7.2, akm_trellis_clean.glb: 1,094,684 → 277,412
   * bytes, albedo texture imported as CompressedTexture2D 1024×1024, zero
   * import errors). Normal maps are excluded — lossy WebP on normals
   * introduces shading artifacts — and stay lossless PNG.
   */
  webpTextures?: boolean;
  /** WebP quality 0..100 (browser fallback encoder ignores it). Default 85. */
  webpQuality?: number;
}

/**
 * Client-side GLB optimization (weld / dedup / prune [+ WebP textures]) —
 * the former `/api/optimize-glb` Next.js route, now running entirely in the
 * browser. Throws on empty or oversize input; callers fall back to the raw
 * buffer.
 *
 * The EXT_texture_webp extension MUST be registered on the WebIO instance:
 * without it the extension block is dropped on write and the file is left
 * with a bare `image/webp` mimeType, which is invalid core glTF.
 * textureCompress with no encoder uses gltf-transform's platform fallback
 * (canvas-based in the browser).
 */
export async function optimizeGlbBinary(
  rawBuffer: ArrayBuffer,
  options: OptimizeGlbOptions = {}
): Promise<Uint8Array> {
  if (!rawBuffer || rawBuffer.byteLength === 0) {
    throw new Error('فایل GLB خالی است.');
  }
  if (rawBuffer.byteLength > MAX_GLB_BYTES) {
    throw new Error('حجم فایل GLB بیش از حد مجاز است.');
  }

  const { webpTextures = true, webpQuality = 85 } = options;

  const io = new WebIO().registerExtensions([EXTTextureWebP]);
  const doc = await io.readBinary(new Uint8Array(rawBuffer));
  await doc.transform(
    weld(),
    dedup(),
    prune(),
    ...(webpTextures
      ? [
          textureCompress({
            targetFormat: 'webp',
            quality: webpQuality,
            slots: /^(?!normalTexture).*$/, // keep normal maps lossless PNG
          }),
        ]
      : [])
  );
  const optimized = await io.writeBinary(doc);

  const outCopy = new Uint8Array(optimized.byteLength);
  outCopy.set(optimized);
  return outCopy;
}
