/**
 * ML background removal via @imgly/background-removal (ONNX/WASM, browser-only).
 *
 * Second cutout method next to the offline flood-fill. The library (and the
 * onnxruntime-web peer) is lazily imported, so the ONNX/WASM chunk and the
 * model download (isnet_fp16) happen only on first ML use; the
 * library caches model + WASM in the browser (Cache Storage + model cache),
 * so later runs work offline until the cache is cleared.
 *
 * NOTE on licensing: @imgly/background-removal is AGPL-licensed, unlike the
 * MIT-only dependencies of the rest of the app. That matters for the
 * still-pending open-source licensing decision — see the v3 report.
 */

export type MlCutoutProgress = (key: string, current: number, total: number) => void;

/** Same alpha cut as the flood-fill path (computeForegroundMask: alpha > 35). */
export const ML_CUTOUT_ALPHA_THRESHOLD = 35;

/**
 * Run ML background removal on an image URL (data:, blob: or http(s):) and
 * return a PNG Blob with a transparent background. Throws when the model
 * cannot be downloaded or inference fails — callers fall back to flood-fill.
 */
export async function removeBackgroundFromImageUrl(
  imageUrl: string,
  onProgress?: MlCutoutProgress
): Promise<Blob> {
  // Lazy import: keep ONNX/WASM out of the main bundle until ML is selected.
  const { removeBackground } = await import('@imgly/background-removal');
  const response = await fetch(imageUrl);
  if (!response.ok) {
    throw new Error('خواندن تصویر برای برش ML ناموفق بود.');
  }
  const sourceBlob = await response.blob();
  return removeBackground(sourceBlob, {
    output: { format: 'image/png' },
    ...(onProgress ? { progress: onProgress } : {}),
  });
}

/**
 * Pure alpha → mask conversion for ML-cut RGBA (runs in Node/Vitest too).
 * The ML output already carries the segmentation in its alpha channel, so
 * the mask is just an alpha threshold — no flood-fill involved.
 */
export function mlAlphaMaskFromRgba(
  rgba: Uint8ClampedArray,
  cols: number,
  rows: number,
  threshold: number = ML_CUTOUT_ALPHA_THRESHOLD
): Uint8Array {
  const total = cols * rows;
  const mask = new Uint8Array(total);
  for (let i = 0; i < total; i++) {
    mask[i] = rgba[i * 4 + 3] > threshold ? 1 : 0;
  }
  return mask;
}
