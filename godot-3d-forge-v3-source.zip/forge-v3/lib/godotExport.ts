import * as THREE from 'three';
import { GLTFExporter } from 'three/examples/jsm/exporters/GLTFExporter.js';
import { OBJExporter } from 'three/examples/jsm/exporters/OBJExporter.js';
import { PLYExporter } from 'three/examples/jsm/exporters/PLYExporter.js';
import { STLExporter } from 'three/examples/jsm/exporters/STLExporter.js';
import JSZip from 'jszip';
import { optimizeGlbBinary as optimizeGlbBinaryClient } from './optimizeGlb';
import { sanitizeAsciiNodeName, type MeshBuildSettings, type MeshStats } from './meshTypes';
import {
  flipNormalMapGreenChannel,
  getExportTarget,
  packUnityMetallicSmoothness,
  targetCollisionMeshName,
  type ExportTarget,
  type ExportTargetId,
} from './targets';

export type ExportFormat = 'glb' | 'gltf' | 'obj';

function triggerDownload(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

async function optimizeGlbBinary(
  rawBuffer: ArrayBuffer,
  options: { webpTextures?: boolean } = {}
): Promise<Uint8Array> {
  try {
    return await optimizeGlbBinaryClient(rawBuffer, options);
  } catch {
    return new Uint8Array(rawBuffer);
  }
}

/**
 * Serialize a group to a GLB / glTF / OBJ blob. This is the exact code
 * exportThreeGroup used to run inline (same exporter options, same
 * optimize step); it was factored out so the per-target ZIP export
 * (F-40) can reuse it without changing the Godot download path.
 */
async function serializeGroupToBlob(
  group: THREE.Group,
  baseFilename: string,
  format: ExportFormat,
  options: { optimizeGltf?: boolean; webpTextures?: boolean } = {}
): Promise<{ blob: Blob; filename: string }> {
  const { optimizeGltf = true, webpTextures = true } = options;
  const safeName = sanitizeAsciiNodeName(baseFilename, 'GameAsset_3D');
  group.updateMatrixWorld(true);

  if (format === 'obj') {
    const exporter = new OBJExporter();
    const objText = exporter.parse(group);
    return {
      blob: new Blob([objText], { type: 'text/plain;charset=utf-8' }),
      filename: `${safeName}.obj`,
    };
  }

  const gltfExporter = new GLTFExporter();
  const binary = format === 'glb';

  const result = await new Promise<ArrayBuffer | Record<string, unknown>>((resolve, reject) => {
    gltfExporter.parse(
      group,
      (output) => resolve(output as ArrayBuffer | Record<string, unknown>),
      (error) => reject(error instanceof Error ? error : new Error('GLTF export failed')),
      {
        binary,
        onlyVisible: true,
        trs: false,
      }
    );
  });

  if (binary && result instanceof ArrayBuffer) {
    const finalBytes = optimizeGltf
      ? await optimizeGlbBinary(result, { webpTextures })
      : new Uint8Array(result);
    const copy = new Uint8Array(finalBytes.byteLength);
    copy.set(finalBytes);
    return {
      blob: new Blob([copy.buffer], { type: 'model/gltf-binary' }),
      filename: `${safeName}.glb`,
    };
  }

  const jsonString = JSON.stringify(result, null, 2);
  return {
    blob: new Blob([jsonString], { type: 'model/gltf+json;charset=utf-8' }),
    filename: `${safeName}.gltf`,
  };
}

export async function exportThreeGroup(
  group: THREE.Group,
  baseFilename: string,
  format: ExportFormat,
  options: { optimizeGltf?: boolean; webpTextures?: boolean } = {}
): Promise<number> {
  const { blob, filename } = await serializeGroupToBlob(group, baseFilename, format, options);
  triggerDownload(blob, filename);
  return blob.size;
}

/** STL / PLY single-mesh formats (F-41). Geometry only, no textures. */
export type MeshExportFormat = 'stl' | 'ply';

export async function exportMeshFormat(
  group: THREE.Group,
  baseFilename: string,
  format: MeshExportFormat
): Promise<number> {
  const safeName = sanitizeAsciiNodeName(baseFilename, 'GameAsset_3D');
  group.updateMatrixWorld(true);

  if (format === 'stl') {
    const exporter = new STLExporter();
    const data = exporter.parse(group, { binary: false });
    const text = typeof data === 'string' ? data : new TextDecoder().decode(data);
    const blob = new Blob([text], { type: 'model/stl;charset=utf-8' });
    triggerDownload(blob, `${safeName}.stl`);
    return blob.size;
  }

  const exporter = new PLYExporter();
  const data = await new Promise<string | ArrayBuffer>((resolve, reject) => {
    try {
      exporter.parse(
        group,
        (result: string | ArrayBuffer) => {
          if (typeof result === 'string' || result instanceof ArrayBuffer) {
            resolve(result);
          } else {
            reject(new Error('PLY export returned no data'));
          }
        },
        { binary: false }
      );
    } catch (err) {
      reject(err instanceof Error ? err : new Error('PLY export failed'));
    }
  });
  const blob = new Blob([data], { type: 'text/plain;charset=utf-8' });
  triggerDownload(blob, `${safeName}.ply`);
  return blob.size;
}

export function generateGodot4Script(
  settings: MeshBuildSettings,
  stats: MeshStats
): string {
  const safeName = sanitizeAsciiNodeName(settings.assetName, 'GameAsset_3D');
  const colSuffix = settings.godotCollisionSuffix ? '-col' : '';
  const modeLabel =
    settings.mode === 'sculpted'
      ? 'Sculpted Double-Sided Watertight Mesh'
      : settings.mode === 'lathe'
        ? '360-deg Rotational Cylindrical-UV Lathe Mesh'
        : 'Face-Culled Voxel Mesh';

  return `extends Node3D
class_name ${safeName}Controller

# Generated by Godot 3D Forge
# Setup: Copy '${safeName}.glb' into your Godot project folder at 'res://assets/models/${safeName}.glb'
# (or update the preload path below to match your project structure).
# Mode: ${modeLabel}
# Topology: ${stats.triangleCount} triangles | ${stats.vertexCount} vertices | Watertight: ${stats.validation.isWatertight ? 'YES' : 'NO'}
# Dimensions: ${stats.boundsMeters.width}m x ${stats.boundsMeters.height}m x ${stats.boundsMeters.depth}m
# Expected Mesh Node: ${safeName}_Mesh${colSuffix}

@export var model_scene: PackedScene = preload("res://assets/models/${safeName}.glb")
@export var spin_speed: float = 0.0

var _model_instance: Node3D

func _ready() -> void:
\tif model_scene:
\t\t_model_instance = model_scene.instantiate()
\t\t_model_instance.name = "${safeName}"
\t\tadd_child(_model_instance)
\t\t_enable_shadows(_model_instance)

func _process(delta: float) -> void:
\tif _model_instance and spin_speed != 0.0:
\t\t_model_instance.rotate_y(spin_speed * delta)

func _enable_shadows(node: Node) -> void:
\tif node is MeshInstance3D:
\t\tnode.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
\tfor child in node.get_children():
\t\t_enable_shadows(child)
`;
}

/* ------------------------------------------------------------------ */
/* Multi-engine targets (Forge v3, F-33..F-40)                        */
/* ------------------------------------------------------------------ */

/**
 * Unity C# controller (F-37): a MonoBehaviour with turntable spin and
 * click-to-pick-up behaviour, plus the glTFast import note. The class
 * name matches the script file name returned by the target registry.
 */
export function generateUnityCSharpScript(
  settings: MeshBuildSettings,
  stats: MeshStats
): string {
  const safeName = sanitizeAsciiNodeName(settings.assetName, 'GameAsset_3D');
  const modeLabel =
    settings.mode === 'sculpted'
      ? 'Sculpted Double-Sided Watertight Mesh'
      : settings.mode === 'lathe'
        ? '360-deg Rotational Cylindrical-UV Lathe Mesh'
        : 'Face-Culled Voxel Mesh';

  return `using UnityEngine;

// Generated by Godot 3D Forge — Unity target
// Import: install the glTFast package (com.atteneder.gltfast) first:
//   Unity Package Manager > Add package by git URL:
//   https://github.com/atteneder/glTFast.git
// Then drag '${safeName}.glb' into Assets and drop this script on the
// imported model's root GameObject. Unity works in meters, same as the
// exported GLB — no scale conversion needed.
// Mode: ${modeLabel}
// Topology: ${stats.triangleCount} triangles | ${stats.vertexCount} vertices | Watertight: ${stats.validation.isWatertight ? 'YES' : 'NO'}
// Dimensions: ${stats.boundsMeters.width}m x ${stats.boundsMeters.height}m x ${stats.boundsMeters.depth}m
// Collision: Unity has no name-based collision — add a MeshCollider
// component to this GameObject (tick Convex for a dynamic Rigidbody).

[RequireComponent(typeof(MeshCollider))]
public class ${safeName}Controller : MonoBehaviour
{
    [Header("Spin")]
    [Tooltip("Turntable speed in degrees per second. 0 = no spin.")]
    public float spinSpeed = 0f;

    [Header("Pickup")]
    [Tooltip("Destroy the object when it is clicked / picked up.")]
    public bool pickupOnClick = true;

    [Tooltip("Seconds to wait after pickup before destroying the object.")]
    public float pickupDestroyDelay = 0.25f;

    private bool _pickedUp;

    void Update()
    {
        if (!_pickedUp && spinSpeed != 0f)
        {
            transform.Rotate(Vector3.up, spinSpeed * Time.deltaTime, Space.Self);
        }
    }

    void OnMouseDown()
    {
        if (pickupOnClick)
        {
            PickUp();
        }
    }

    public void PickUp()
    {
        if (_pickedUp) return;
        _pickedUp = true;
        var col = GetComponent<Collider>();
        if (col != null) col.enabled = false;
        Destroy(gameObject, pickupDestroyDelay);
    }
}
`;
}

/**
 * Unreal Engine 5 Python editor script (F-38). Imports the GLB that
 * ships in the ZIP (already scaled x100 to centimeters, DirectX-style
 * normal map), finds the imported StaticMesh and spawns it as an actor
 * in the current level. Run it from the editor:
 * Tools > Execute Python Script, or Content/Python in the Content Browser.
 */
export function generateUnrealPythonScript(
  settings: MeshBuildSettings,
  stats: MeshStats
): string {
  const safeName = sanitizeAsciiNodeName(settings.assetName, 'GameAsset_3D');

  return `# Generated by Godot 3D Forge — Unreal Engine 5 target
# Run in the Unreal Editor: Tools > Execute Python Script.
#
# SCALE NOTE: the GLB in this ZIP is already scaled x100 to centimeters
# (Unreal's world unit) and its normal map is DirectX-style (green
# channel flipped). Do NOT apply an extra scale on import.
# Mode: ${settings.mode} | Triangles: ${stats.triangleCount} | Vertices: ${stats.vertexCount}
# Dimensions (cm, as exported): ${stats.boundsMeters.width * 100} x ${stats.boundsMeters.height * 100} x ${stats.boundsMeters.depth * 100}
# COLLISION NOTE: the mesh node is named UCX_${safeName}_Mesh. Unreal
# custom collision only works on the FBX path — convert the GLB to FBX
# (e.g. in Blender) and keep the UCX_ mesh; the glTF importer does not
# carry custom collision. Until then, add a collision in the Static Mesh
# Editor (Collision > Add Box/Sphere Simplified Collision).
import os
import unreal

ASSET_NAME = "${safeName}"
GLB_FILENAME = "${safeName}.glb"
DESTINATION_PATH = "/Game/Imported/${safeName}"


def _glb_path():
    # The GLB sits next to this script inside the exported ZIP.
    try:
        here = os.path.dirname(os.path.abspath(__file__))
    except NameError:
        here = os.getcwd()
    return os.path.join(here, GLB_FILENAME)


def main():
    glb_path = _glb_path()
    if not os.path.isfile(glb_path):
        unreal.log_error(
            "Godot 3D Forge: GLB not found next to the script: %s" % glb_path
        )
        return

    task = unreal.AssetImportTask()
    task.filename = glb_path
    task.destination_path = DESTINATION_PATH
    task.destination_name = ASSET_NAME
    task.replace_existing = True
    task.automated = True
    task.save = True
    unreal.AssetToolsHelpers.get_asset_tools().import_asset_tasks([task])
    unreal.log("Godot 3D Forge: imported %s to %s" % (GLB_FILENAME, DESTINATION_PATH))

    registry = unreal.AssetRegistryHelpers.get_asset_registry()
    assets = registry.get_assets_by_path(DESTINATION_PATH, recursive=True)
    static_meshes = []
    for asset_data in assets:
        if asset_data.asset_class_path.asset_name == "StaticMesh":
            asset = asset_data.get_asset()
            if asset is not None:
                static_meshes.append(asset)
    if not static_meshes:
        unreal.log_error(
            "Godot 3D Forge: no StaticMesh found under %s after import" % DESTINATION_PATH
        )
        return

    static_mesh = static_meshes[0]
    actor_subsystem = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
    actor = actor_subsystem.spawn_actor_from_object(
        static_mesh, unreal.Vector(0.0, 0.0, 0.0)
    )
    actor.set_actor_label(ASSET_NAME)
    unreal.log(
        "Godot 3D Forge: spawned actor '%s' (mesh already in cm, no extra scale applied)"
        % ASSET_NAME
    )


try:
    main()
except Exception as exc:  # noqa: BLE001 - surface any editor error plainly
    unreal.log_error("Godot 3D Forge: Unreal import script failed: %s" % exc)
`;
}

/**
 * Blender Python setup script (F-39). Imports the GLB, wires the PNG
 * textures from the ZIP into Principled BSDF materials, and adds a
 * turntable animation. Run headless:
 *   blender -b --python <Name>_Setup.py -- <Name>.glb
 * or from Blender's Scripting workspace (GLB is then looked for next
 * to this script).
 */
export function generateBlenderPythonScript(
  settings: MeshBuildSettings,
  stats: MeshStats
): string {
  const safeName = sanitizeAsciiNodeName(settings.assetName, 'GameAsset_3D');

  return `# Generated by Godot 3D Forge — Blender target
# Usage (headless):  blender -b --python ${safeName}_Setup.py -- ${safeName}.glb
# Usage (UI):        open the Scripting workspace and run this file; the
#                    GLB is looked for next to this script.
# What it does: imports the GLB, wires the ZIP's PNG textures into
# Principled BSDF materials, and adds a 120-frame turntable animation.
# Blender works in meters, same as the exported GLB — no scale conversion.
# Mode: ${settings.mode} | Triangles: ${stats.triangleCount} | Vertices: ${stats.vertexCount}
# Dimensions (m): ${stats.boundsMeters.width} x ${stats.boundsMeters.height} x ${stats.boundsMeters.depth}
import bpy
import math
import os
import sys

ASSET_NAME = "${safeName}"
TURNTABLE_FRAMES = 120


def glb_path_from_argv():
    argv = sys.argv
    if "--" in argv:
        args = argv[argv.index("--") + 1:]
        if args:
            return os.path.abspath(args[0])
    try:
        here = os.path.dirname(os.path.abspath(__file__))
    except NameError:
        here = os.getcwd()
    return os.path.join(here, ASSET_NAME + ".glb")


def texture_path(name):
    try:
        here = os.path.dirname(os.path.abspath(__file__))
    except NameError:
        here = os.getcwd()
    path = os.path.join(here, name)
    return path if os.path.isfile(path) else None


def wire_material(material):
    """Wire Albedo/Normal/Roughness/Metalness PNGs into Principled BSDF."""
    if material is None:
        return
    material.use_nodes = True
    bsdf = None
    for node in material.node_tree.nodes:
        if node.type == "BSDF_PRINCIPLED":
            bsdf = node
            break
    if bsdf is None:
        print("Godot 3D Forge: no Principled BSDF in material %s" % material.name)
        return
    nodes = material.node_tree.nodes
    links = material.node_tree.links

    def add_image(path, colorspace):
        img = bpy.data.images.load(path)
        tex = nodes.new("ShaderNodeTexImage")
        tex.image = img
        tex.image.colorspace_settings.name = colorspace
        return tex

    albedo = texture_path(ASSET_NAME + "_Albedo.png")
    if albedo:
        tex = add_image(albedo, "sRGB")
        links.new(tex.outputs["Color"], bsdf.inputs["Base Color"])
    normal = texture_path(ASSET_NAME + "_Normal.png")
    if normal:
        tex = add_image(normal, "Non-Color")
        nmap = nodes.new("ShaderNodeNormalMap")
        links.new(tex.outputs["Color"], nmap.inputs["Color"])
        links.new(nmap.outputs["Normal"], bsdf.inputs["Normal"])
    roughness = texture_path(ASSET_NAME + "_Roughness.png")
    if roughness:
        tex = add_image(roughness, "Non-Color")
        links.new(tex.outputs["Color"], bsdf.inputs["Roughness"])
    metalness = texture_path(ASSET_NAME + "_Metalness.png")
    if metalness:
        tex = add_image(metalness, "Non-Color")
        links.new(tex.outputs["Color"], bsdf.inputs["Metallic"])
    print("Godot 3D Forge: wired textures into material %s" % material.name)


def main():
    glb_path = glb_path_from_argv()
    if not os.path.isfile(glb_path):
        raise RuntimeError("Godot 3D Forge: GLB not found: %s" % glb_path)

    # Clean scene (default cube / light / camera).
    bpy.ops.object.select_all(action="SELECT")
    bpy.ops.object.delete()

    bpy.ops.import_scene.gltf(filepath=glb_path)
    imported = [obj for obj in bpy.context.selected_objects]
    if not imported:
        imported = list(bpy.context.scene.objects)
    print("Godot 3D Forge: imported %d objects from %s" % (len(imported), glb_path))

    for obj in imported:
        if obj.type != "MESH":
            continue
        for slot in obj.material_slots:
            wire_material(slot.material)

    # Turntable: parent everything under one empty and spin it 0..360 deg.
    bpy.ops.object.empty_add(type="PLAIN_AXES", location=(0.0, 0.0, 0.0))
    rig = bpy.context.active_object
    rig.name = "Turntable_" + ASSET_NAME
    for obj in imported:
        if obj.parent is None and obj != rig:
            obj.parent = rig
            obj.matrix_parent_inverse = rig.matrix_world.inverted()

    scene = bpy.context.scene
    scene.frame_start = 1
    scene.frame_end = TURNTABLE_FRAMES
    rig.rotation_euler = (0.0, 0.0, 0.0)
    rig.keyframe_insert(data_path="rotation_euler", frame=1)
    rig.rotation_euler = (0.0, 0.0, math.radians(360.0))
    rig.keyframe_insert(data_path="rotation_euler", frame=TURNTABLE_FRAMES)

    # Simple camera looking at the origin, so a render works out of the box.
    cam_data = bpy.data.cameras.new("Camera_" + ASSET_NAME)
    cam = bpy.data.objects.new("Camera_" + ASSET_NAME, cam_data)
    scene.collection.objects.link(cam)
    cam.location = (2.5, -2.5, 1.6)
    constraint = cam.constraints.new("TRACK_TO")
    constraint.target = rig
    constraint.track_axis = "TRACK_NEGATIVE_Z"
    constraint.up_axis = "UP_Y"
    scene.camera = cam

    try:
        scene.render.engine = "BLENDER_EEVEE_NEXT"
    except Exception:
        scene.render.engine = "BLENDER_EEVEE"
    print("BLENDER_SETUP_OK %s (%d objects, %d-frame turntable)" % (ASSET_NAME, len(imported), TURNTABLE_FRAMES))


main()
`;
}

/** Script text for a target, or '' when the target ships no script. */
export function generateTargetScript(
  target: ExportTarget,
  settings: MeshBuildSettings,
  stats: MeshStats
): string {
  switch (target.scriptKind) {
    case 'gdscript':
      return generateGodot4Script(settings, stats);
    case 'csharp':
      return generateUnityCSharpScript(settings, stats);
    case 'unreal-python':
      return generateUnrealPythonScript(settings, stats);
    case 'blender-python':
      return generateBlenderPythonScript(settings, stats);
    case 'none':
    default:
      return '';
  }
}

/**
 * Prepare a group for a target-aware export (F-33 unit scale, F-36
 * collision naming). Godot and generic return the live group untouched
 * (zero behaviour change). Every other target gets a deep clone whose
 * mesh names are renamed per the target convention and whose geometry
 * has the world transform — and the target unit scale — baked in, so
 * the exported file is correct even if the importer ignores node
 * transforms. Call cleanup() to dispose the cloned geometries.
 */
export function prepareExportGroup(
  group: THREE.Group,
  target: ExportTarget
): { group: THREE.Group; cleanup: () => void } {
  if (target.id === 'godot' || target.id === 'generic') {
    return { group, cleanup: () => undefined };
  }
  const clone = group.clone(true);
  clone.updateMatrixWorld(true);
  const clonedGeometries: THREE.BufferGeometry[] = [];
  clone.traverse((obj) => {
    if (obj instanceof THREE.Mesh) {
      obj.name = targetCollisionMeshName(obj.name, target);
      const baked = obj.geometry.clone();
      baked.applyMatrix4(obj.matrixWorld);
      if (target.unitScale !== 1) {
        baked.scale(target.unitScale, target.unitScale, target.unitScale);
      }
      clonedGeometries.push(baked);
      obj.geometry = baked;
      obj.position.set(0, 0, 0);
      obj.rotation.set(0, 0, 0);
      obj.scale.set(1, 1, 1);
    }
  });
  clone.updateMatrixWorld(true);
  return {
    group: clone,
    cleanup: () => {
      clonedGeometries.forEach((g) => g.dispose());
    },
  };
}

interface CollectedTextures {
  albedo?: HTMLCanvasElement;
  normal?: HTMLCanvasElement;
  roughness?: HTMLCanvasElement;
  metalness?: HTMLCanvasElement;
}

function canvasOfTexture(tex: unknown): HTMLCanvasElement | undefined {
  const t = tex as THREE.Texture | null | undefined;
  if (t && t.image instanceof HTMLCanvasElement) return t.image;
  return undefined;
}

function collectMaterialTextures(group: THREE.Group): CollectedTextures {
  const out: CollectedTextures = {};
  group.traverse((obj) => {
    if (!(obj instanceof THREE.Mesh)) return;
    const materials = Array.isArray(obj.material) ? obj.material : [obj.material];
    for (const mat of materials) {
      const std = mat as THREE.MeshStandardMaterial | THREE.MeshPhysicalMaterial | null;
      if (!std || typeof std !== 'object') continue;
      out.albedo ??= canvasOfTexture(std.map);
      out.normal ??= canvasOfTexture(std.normalMap);
      out.roughness ??= canvasOfTexture(std.roughnessMap);
      out.metalness ??= canvasOfTexture(std.metalnessMap);
    }
  });
  return out;
}

function canvasToPngBlob(canvas: HTMLCanvasElement): Promise<Blob> {
  return new Promise((resolve, reject) => {
    canvas.toBlob((blob) => {
      if (blob) resolve(blob);
      else reject(new Error('Failed to encode PNG texture'));
    }, 'image/png');
  });
}

function readCanvasRgba(canvas: HTMLCanvasElement): {
  data: Uint8ClampedArray;
  width: number;
  height: number;
} {
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  if (!ctx) throw new Error('Canvas 2D context unavailable');
  const img = ctx.getImageData(0, 0, canvas.width, canvas.height);
  return { data: img.data, width: canvas.width, height: canvas.height };
}

function rgbaToCanvas(
  rgba: Uint8ClampedArray,
  width: number,
  height: number
): HTMLCanvasElement {
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Canvas 2D context unavailable');
  ctx.putImageData(new ImageData(new Uint8ClampedArray(rgba), width, height), 0, 0);
  return canvas;
}

/**
 * Build the Unity metallic-smoothness canvas (F-35) from the collected
 * maps, falling back to the scalar metalness/roughness settings when a
 * map is absent. Returns null when there is no map and no albedo to
 * size the canvas from.
 */
function buildUnityPackedCanvas(
  tex: CollectedTextures,
  settings: MeshBuildSettings
): HTMLCanvasElement | null {
  const ref = tex.roughness ?? tex.metalness ?? tex.albedo;
  if (!ref) return null;
  const width = ref.width;
  const height = ref.height;
  const pixelCount = width * height;
  const metalRgba = new Uint8ClampedArray(pixelCount * 4);
  const roughRgba = new Uint8ClampedArray(pixelCount * 4);
  const fill = (
    out: Uint8ClampedArray,
    canvas: HTMLCanvasElement | undefined,
    scalar: number
  ) => {
    if (canvas && canvas.width === width && canvas.height === height) {
      out.set(readCanvasRgba(canvas).data);
    } else {
      const v = Math.round(Math.min(1, Math.max(0, scalar)) * 255);
      for (let i = 0; i < pixelCount * 4; i += 4) {
        out[i] = v;
        out[i + 1] = v;
        out[i + 2] = v;
        out[i + 3] = 255;
      }
    }
  };
  fill(metalRgba, tex.metalness, settings.metalness);
  fill(roughRgba, tex.roughness, settings.roughness);
  return rgbaToCanvas(packUnityMetallicSmoothness(metalRgba, roughRgba), width, height);
}

function buildTargetReadme(
  target: ExportTarget,
  settings: MeshBuildSettings,
  stats: MeshStats,
  includedFiles: string[]
): string {
  const safeName = sanitizeAsciiNodeName(settings.assetName, 'GameAsset_3D');
  const unitLine =
    target.unit === 'cm'
      ? 'Unit: centimeters — the model was exported x100 (Unreal world unit).'
      : 'Unit: meters (1 unit = 1 m).';
  const normalLine = target.flipNormalGreen
    ? 'Normal map: DirectX-style (green channel flipped for Unreal).'
    : 'Normal map: OpenGL-style (green up).';
  const packingLine =
    target.texturePacking === 'unity-metallic-smoothness'
      ? 'Textures: packed _MetallicSmoothness.png (R = metallic, A = smoothness = 1 - roughness) for the Unity Standard shader.'
      : 'Textures: standard glTF PBR set (Albedo / Normal / Roughness / Metalness).';
  return `# ${safeName} — ${target.label} export
Generated by Godot 3D Forge v0.2.0.

Target: ${target.label}
${unitLine}
${normalLine}
${packingLine}
Collision: ${target.collisionNaming.note}
Topology: ${stats.triangleCount} triangles | ${stats.vertexCount} vertices | Watertight: ${stats.validation.isWatertight ? 'YES' : 'NO'}
Dimensions: ${stats.boundsMeters.width}m x ${stats.boundsMeters.height}m x ${stats.boundsMeters.depth}m

## Import
${target.readmeBlurb}

## Files in this ZIP
${includedFiles.map((f) => `- ${f}`).join('\n')}
`;
}

/**
 * Per-target ZIP export (F-40): GLB (target-transformed) + that
 * target's textures + its script + a short README. Godot and generic
 * ZIPs contain the exact same GLB the single-file download produces.
 */
export async function exportTargetZip(
  group: THREE.Group,
  settings: MeshBuildSettings,
  stats: MeshStats,
  targetId: ExportTargetId
): Promise<number> {
  const target = getExportTarget(targetId);
  const safeName = sanitizeAsciiNodeName(settings.assetName, 'GameAsset_3D');
  const prepared = prepareExportGroup(group, target);
  const zip = new JSZip();
  const included: string[] = [];
  try {
    const { blob: glbBlob, filename: glbName } = await serializeGroupToBlob(
      prepared.group,
      settings.assetName,
      'glb',
      { optimizeGltf: settings.optimizeGltfOnExport, webpTextures: settings.webpTextures }
    );
    zip.file(glbName, glbBlob);
    included.push(glbName);

    const tex = collectMaterialTextures(group);
    if (tex.albedo) {
      const name = `${safeName}_Albedo.png`;
      zip.file(name, await canvasToPngBlob(tex.albedo));
      included.push(name);
    }
    if (tex.normal) {
      let normalCanvas = tex.normal;
      if (target.flipNormalGreen) {
        const { data, width, height } = readCanvasRgba(tex.normal);
        normalCanvas = rgbaToCanvas(flipNormalMapGreenChannel(data), width, height);
      }
      const name = `${safeName}_Normal.png`;
      zip.file(name, await canvasToPngBlob(normalCanvas));
      included.push(name);
    }
    if (target.texturePacking === 'unity-metallic-smoothness') {
      const packed = buildUnityPackedCanvas(tex, settings);
      if (packed) {
        const name = `${safeName}_MetallicSmoothness.png`;
        zip.file(name, await canvasToPngBlob(packed));
        included.push(name);
      }
    } else {
      if (tex.roughness) {
        const name = `${safeName}_Roughness.png`;
        zip.file(name, await canvasToPngBlob(tex.roughness));
        included.push(name);
      }
      if (tex.metalness) {
        const name = `${safeName}_Metalness.png`;
        zip.file(name, await canvasToPngBlob(tex.metalness));
        included.push(name);
      }
    }

    const script = generateTargetScript(target, settings, stats);
    if (script) {
      const scriptName = target.scriptFileName(safeName);
      zip.file(scriptName, script);
      included.push(scriptName);
    }

    zip.file('README.md', buildTargetReadme(target, settings, stats, included));
    included.push('README.md');

    const zipBlob = await zip.generateAsync({ type: 'blob' });
    triggerDownload(zipBlob, `${safeName}_${target.id}.zip`);
    return zipBlob.size;
  } finally {
    prepared.cleanup();
  }
}
