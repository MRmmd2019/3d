import * as THREE from 'three';
import { SimplifyModifier } from 'three/examples/jsm/modifiers/SimplifyModifier.js';
import { validateMeshTopology } from './meshAlgorithms';
import { mlAlphaMaskFromRgba, removeBackgroundFromImageUrl } from './mlCutout';
import {
  runMeshBuildPipeline,
  type MeshPipelineInput,
  type MeshPipelineOutput,
} from './meshPipeline';
import {
  sanitizeAsciiNodeName,
  type GeneratedTexturesPreview,
  type MeshBuildSettings,
  type MeshPolishProfile,
  type MeshStats,
  type ViewportRenderMode,
} from './meshTypes';

function flipMaskHorizontally(mask: Uint8Array, w: number, h: number): Uint8Array {
  const out = new Uint8Array(mask.length);
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      out[y * w + x] = mask[y * w + (w - 1 - x)];
    }
  }
  return out;
}

/**
 * ML cutout for one view: remove the background with the ONNX model, sample
 * the cut image at seg/map resolution, and derive the mask from its alpha
 * channel. Returns null on any failure — the caller then falls back to the
 * flood-fill path for that view instead of failing the whole build.
 */
async function applyMlCutoutToView(
  imageUrl: string,
  cols: number,
  rows: number,
  mapW: number,
  mapH: number
): Promise<{
  segRgba: Uint8ClampedArray;
  mapRgba: Uint8ClampedArray;
  mask: Uint8Array;
} | null> {
  try {
    const cutBlob = await removeBackgroundFromImageUrl(imageUrl);
    const cutUrl = URL.createObjectURL(cutBlob);
    try {
      const cutImg = await loadHtmlImage(cutUrl);
      const segRgba = sampleImageRgba(cutImg, cols, rows);
      const mapRgba = sampleImageRgba(cutImg, mapW, mapH);
      return { segRgba, mapRgba, mask: mlAlphaMaskFromRgba(segRgba, cols, rows) };
    } finally {
      URL.revokeObjectURL(cutUrl);
    }
  } catch (err) {
    console.warn('[Forge] ML cutout failed, falling back to flood-fill:', err);
    return null;
  }
}

function loadHtmlImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new window.Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error('بارگذاری تصویر برای پردازش سه‌بعدی ناموفق بود.'));
    img.src = src;
  });
}

function sampleImageRgba(
  img: HTMLImageElement,
  width: number,
  height: number
): Uint8ClampedArray {
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  if (!ctx) throw new Error('Canvas 2D context unavailable');
  ctx.drawImage(img, 0, 0, width, height);
  return ctx.getImageData(0, 0, width, height).data;
}

function rgbaToCanvasTexture(
  rgba: Uint8ClampedArray,
  width: number,
  height: number,
  options: {
    colorSpace: THREE.ColorSpace;
    maxAnisotropy: number;
    nearestSampling?: boolean;
  }
): { texture: THREE.CanvasTexture; dataUrl: string } {
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Canvas 2D context unavailable');
  const imgData = new ImageData(new Uint8ClampedArray(rgba), width, height);
  ctx.putImageData(imgData, 0, 0);

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = options.colorSpace;
  texture.anisotropy = options.maxAnisotropy;
  if (options.nearestSampling) {
    texture.minFilter = THREE.NearestFilter;
    texture.magFilter = THREE.NearestFilter;
    texture.generateMipmaps = false;
  }
  texture.needsUpdate = true;

  // Generate compact preview data URL (capped at 256px wide to keep React state light)
  let dataUrl = '';
  if (width <= 256 && height <= 256) {
    dataUrl = canvas.toDataURL('image/png');
  } else {
    const scale = 256 / Math.max(width, height);
    const pw = Math.max(32, Math.round(width * scale));
    const ph = Math.max(32, Math.round(height * scale));
    const prevCanvas = document.createElement('canvas');
    prevCanvas.width = pw;
    prevCanvas.height = ph;
    const pCtx = prevCanvas.getContext('2d');
    if (pCtx) {
      pCtx.drawImage(canvas, 0, 0, pw, ph);
      dataUrl = prevCanvas.toDataURL('image/png');
    }
  }

  return { texture, dataUrl };
}

let workerSingleton: Worker | null = null;
let workerFailed = false;
let jobCounter = 1;

/**
 * F-28: worker-side image sampling is possible only when the browser has
 * a Worker, OffscreenCanvas and createImageBitmap. Anything missing means
 * the main-thread canvas path (sampleImageRgba) is used, exactly as before.
 */
export function canUseWorkerImageSampling(): boolean {
  return (
    typeof Worker !== 'undefined' &&
    typeof OffscreenCanvas !== 'undefined' &&
    typeof createImageBitmap === 'function'
  );
}

function getOrCreateWorker(): Worker | null {
  if (typeof Worker === 'undefined' || workerFailed) return null;
  try {
    if (!workerSingleton) {
      workerSingleton = new Worker(new URL('./meshBuildWorker.ts', import.meta.url), {
        type: 'module',
      });
    }
    return workerSingleton;
  } catch {
    workerFailed = true;
    return null;
  }
}

/**
 * F-28: sample image pixels inside the worker via OffscreenCanvas.
 * Returns null on any failure (unsupported browser, worker error, or the
 * worker reporting no OffscreenCanvas) — the caller then falls back to
 * the main-thread canvas path.
 */
function sampleImageRgbaViaWorker(
  img: HTMLImageElement,
  width: number,
  height: number
): Promise<Uint8ClampedArray | null> {
  if (!canUseWorkerImageSampling() || workerFailed) return Promise.resolve(null);
  return (async (): Promise<Uint8ClampedArray | null> => {
    let bitmap: ImageBitmap;
    try {
      bitmap = await createImageBitmap(img);
    } catch {
      return null;
    }
    const worker = getOrCreateWorker();
    if (!worker) {
      bitmap.close();
      return null;
    }
    const jobId = jobCounter++;
    return new Promise((resolve) => {
      const onMessage = (ev: MessageEvent) => {
        const data = ev.data;
        if (!data || data.jobId !== jobId) return;
        cleanup();
        if (data.ok && data.rgba instanceof Uint8ClampedArray) {
          resolve(data.rgba);
        } else {
          resolve(null);
        }
      };

      const onError = () => {
        cleanup();
        workerFailed = true;
        workerSingleton?.terminate();
        workerSingleton = null;
        resolve(null);
      };

      const cleanup = () => {
        worker.removeEventListener('message', onMessage);
        worker.removeEventListener('error', onError);
      };

      worker.addEventListener('message', onMessage);
      worker.addEventListener('error', onError);

      try {
        worker.postMessage(
          { jobId, type: 'sample-image', bitmap, width, height },
          [bitmap]
        );
      } catch {
        cleanup();
        resolve(null);
      }
    });
  })();
}

/** F-28: try OffscreenCanvas sampling in the worker, fall back to main-thread canvas. */
async function sampleImageRgbaSmart(
  img: HTMLImageElement,
  width: number,
  height: number
): Promise<Uint8ClampedArray> {
  const viaWorker = await sampleImageRgbaViaWorker(img, width, height);
  if (viaWorker) return viaWorker;
  return sampleImageRgba(img, width, height);
}

function executePipelineWithWorker(input: MeshPipelineInput): Promise<MeshPipelineOutput> {
  const worker = getOrCreateWorker();
  if (!worker) {
    return Promise.resolve(runMeshBuildPipeline(input));
  }

  return new Promise((resolve) => {
    try {
      const jobId = jobCounter++;

      const onMessage = (ev: MessageEvent) => {
        const data = ev.data;
        if (!data || data.jobId !== jobId) return;
        cleanup();
        if (data.ok && data.result) {
          resolve(data.result as MeshPipelineOutput);
        } else {
          resolve(runMeshBuildPipeline(input));
        }
      };

      const onError = () => {
        cleanup();
        workerFailed = true;
        workerSingleton?.terminate();
        workerSingleton = null;
        resolve(runMeshBuildPipeline(input));
      };

      const cleanup = () => {
        worker.removeEventListener('message', onMessage);
        worker.removeEventListener('error', onError);
      };

      worker.addEventListener('message', onMessage);
      worker.addEventListener('error', onError);

      // Copy input buffers before transfer so fallback still has data if needed
      const transferPayload: MeshPipelineInput = {
        ...input,
        frontSegRgba: new Uint8ClampedArray(input.frontSegRgba),
        backSegRgba: input.backSegRgba ? new Uint8ClampedArray(input.backSegRgba) : null,
        frontMapRgba: new Uint8ClampedArray(input.frontMapRgba),
        backMapRgba: input.backMapRgba ? new Uint8ClampedArray(input.backMapRgba) : null,
      };

      const transferables: Transferable[] = [
        transferPayload.frontSegRgba.buffer,
        transferPayload.frontMapRgba.buffer,
      ];
      if (transferPayload.backSegRgba) transferables.push(transferPayload.backSegRgba.buffer);
      if (transferPayload.backMapRgba) transferables.push(transferPayload.backMapRgba.buffer);

      worker.postMessage({ jobId, payload: transferPayload }, transferables);
    } catch {
      workerFailed = true;
      resolve(runMeshBuildPipeline(input));
    }
  });
}

async function applyMeshoptDecimationIfNeeded(
  geometry: THREE.BufferGeometry,
  settings: MeshBuildSettings
): Promise<{ geometry: THREE.BufferGeometry; decimatedFromTriangles: number | null }> {
  const indexAttr = geometry.getIndex();
  const posAttr = geometry.getAttribute('position');
  if (!indexAttr || !posAttr) {
    return { geometry, decimatedFromTriangles: null };
  }

  const currentTris = Math.floor(indexAttr.count / 3);
  if (!settings.autoDecimate || currentTris <= settings.targetTriangleBudget) {
    return { geometry, decimatedFromTriangles: null };
  }

  try {
    const modifier = new SimplifyModifier();
    const targetRatio = Math.max(
      0.08,
      Math.min(0.98, settings.targetTriangleBudget / Math.max(1, currentTris))
    );
    const removeVertexCount = Math.max(
      1,
      Math.floor(posAttr.count * (1 - targetRatio))
    );
    const simplified = await modifier.modify(geometry, removeVertexCount);
    simplified.computeVertexNormals();
    geometry.dispose();
    return {
      geometry: simplified,
      decimatedFromTriangles: currentTris,
    };
  } catch {
    return { geometry, decimatedFromTriangles: null };
  }
}

export async function build3DMeshFromImage(
  imageUrl: string,
  settings: MeshBuildSettings,
  options: {
    backImageUrl?: string | null;
    maxAnisotropy?: number;
    renderMode?: ViewportRenderMode;
  } = {}
): Promise<{
  group: THREE.Group;
  pbrMaterial: THREE.Material;
  stats: MeshStats;
  previews: GeneratedTexturesPreview;
}> {
  const { backImageUrl = null, maxAnisotropy = 4, renderMode = 'pbr' } = options;
  const img = await loadHtmlImage(imageUrl);
  const backImg = backImageUrl ? await loadHtmlImage(backImageUrl) : null;

  const aspect = img.naturalWidth / Math.max(1, img.naturalHeight);
  const baseRes =
    settings.mode === 'voxel'
      ? Math.min(68, Math.max(20, Math.round(settings.resolution * 0.45)))
      : settings.resolution;

  const cols = aspect >= 1 ? baseRes : Math.max(20, Math.round(baseRes * aspect));
  const rows = aspect >= 1 ? Math.max(20, Math.round(baseRes / aspect)) : baseRes;

  const nearestSampling = settings.mode === 'voxel';
  const targetTexRes = settings.textureResolution;
  const mapW = nearestSampling
    ? cols
    : aspect >= 1
      ? targetTexRes
      : Math.max(128, Math.round(targetTexRes * aspect));
  const mapH = nearestSampling
    ? rows
    : aspect >= 1
      ? Math.max(128, Math.round(targetTexRes / aspect))
      : targetTexRes;

  let frontSegRgba = await sampleImageRgbaSmart(img, cols, rows);
  let frontMapRgba = await sampleImageRgbaSmart(img, mapW, mapH);
  let backSegRgba = backImg ? await sampleImageRgbaSmart(backImg, cols, rows) : null;
  let backMapRgba = backImg ? await sampleImageRgbaSmart(backImg, mapW, mapH) : null;

  // ML cutout (F-22): when selected, replace the sampled RGBA with the
  // ML-cut image (transparent background) and pass its alpha-derived mask
  // to the pipeline as the alternative mask source. Per-view fallback to
  // flood-fill on model/download failure; default stays flood-fill.
  let mlMask: Uint8Array | null = null;
  let backMlMask: Uint8Array | null = null;
  if (settings.cutoutEnabled && settings.cutoutMethod === 'ml') {
    const mlFront = await applyMlCutoutToView(imageUrl, cols, rows, mapW, mapH);
    if (mlFront) {
      frontSegRgba = mlFront.segRgba;
      frontMapRgba = mlFront.mapRgba;
      mlMask = mlFront.mask;
    }
    if (backImg && backImageUrl) {
      const mlBack = await applyMlCutoutToView(backImageUrl, cols, rows, mapW, mapH);
      if (mlBack) {
        backSegRgba = mlBack.segRgba;
        backMapRgba = mlBack.mapRgba;
        // Pipeline mirrors the back view; mirror the mask the same way.
        backMlMask = flipMaskHorizontally(mlBack.mask, cols, rows);
      }
    }
  }

  const pipelineOut = await executePipelineWithWorker({
    cols,
    rows,
    aspect,
    frontSegRgba,
    backSegRgba,
    mapW,
    mapH,
    frontMapRgba,
    backMapRgba,
    mlMask,
    backMlMask,
    settings,
  });

  let geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.BufferAttribute(pipelineOut.positions, 3));
  geometry.setAttribute('uv', new THREE.BufferAttribute(pipelineOut.uvs, 2));
  if (pipelineOut.normals) {
    geometry.setAttribute('normal', new THREE.BufferAttribute(pipelineOut.normals, 3));
  }
  if (pipelineOut.colors) {
    geometry.setAttribute('color', new THREE.BufferAttribute(pipelineOut.colors, 3));
  }
  geometry.setIndex(new THREE.BufferAttribute(pipelineOut.indices, 1));

  // Meshopt decimation when enabled & triangle budget exceeded
  const decimated = await applyMeshoptDecimationIfNeeded(geometry, settings);
  geometry = decimated.geometry;

  // Re-validate final topology (especially after Meshopt simplification)
  const finalPosAttr = geometry.getAttribute('position');
  const finalIdxAttr = geometry.getIndex();
  const finalValidation = decimated.decimatedFromTriangles
    ? validateMeshTopology(
        finalPosAttr.array as Float32Array,
        finalIdxAttr ? finalIdxAttr.array : null,
        settings.targetTriangleBudget,
        decimated.decimatedFromTriangles
      )
    : pipelineOut.validation;

  const polish: MeshPolishProfile = settings.polish;
  const polishOn = Boolean(polish?.enabled);
  const effectiveNormalStrength =
    polishOn && typeof polish.normalStrengthOverride === 'number'
      ? polish.normalStrengthOverride
      : settings.normalStrength;
  const effectiveRoughness =
    polishOn && typeof polish.roughnessOverride === 'number'
      ? polish.roughnessOverride
      : settings.roughness;
  const effectiveMetalness =
    polishOn && typeof polish.metalnessOverride === 'number'
      ? polish.metalnessOverride
      : settings.metalness;

  const albedoRes = rgbaToCanvasTexture(
    pipelineOut.albedoOutRgba,
    pipelineOut.atlasW,
    pipelineOut.atlasH,
    { colorSpace: THREE.SRGBColorSpace, maxAnisotropy, nearestSampling }
  );
  const normalRes = rgbaToCanvasTexture(
    pipelineOut.normalOutRgba,
    pipelineOut.atlasW,
    pipelineOut.atlasH,
    { colorSpace: THREE.NoColorSpace, maxAnisotropy }
  );
  const roughRes = rgbaToCanvasTexture(
    pipelineOut.roughOutRgba,
    pipelineOut.atlasW,
    pipelineOut.atlasH,
    { colorSpace: THREE.NoColorSpace, maxAnisotropy }
  );
  const metalRes = rgbaToCanvasTexture(
    pipelineOut.metalOutRgba,
    pipelineOut.atlasW,
    pipelineOut.atlasH,
    { colorSpace: THREE.NoColorSpace, maxAnisotropy }
  );
  const maskPreviewRes = rgbaToCanvasTexture(
    pipelineOut.maskPreviewRgba,
    cols,
    rows,
    { colorSpace: THREE.SRGBColorSpace, maxAnisotropy: 1 }
  );
  maskPreviewRes.texture.dispose();

  const useVertexColors = Boolean(geometry.getAttribute('color'));
  const useSegMaps = !nearestSampling;

  // Note: When roughnessMap/metalnessMap are attached, scalar factor = 1.0 so map pixel values apply directly
  let pbrMaterial: THREE.Material;
  if (polishOn && polish.clearcoat > 0.02 && !nearestSampling) {
    pbrMaterial = new THREE.MeshPhysicalMaterial({
      name: `Mat_${sanitizeAsciiNodeName(settings.assetName)}`,
      map: albedoRes.texture,
      normalMap: effectiveNormalStrength > 0.02 ? normalRes.texture : null,
      normalScale: new THREE.Vector2(effectiveNormalStrength, effectiveNormalStrength),
      roughnessMap: roughRes.texture,
      roughness: 1.0,
      metalnessMap: settings.autoMaterialSegmentation ? metalRes.texture : null,
      metalness: settings.autoMaterialSegmentation ? 1.0 : effectiveMetalness,
      clearcoat: polish.clearcoat,
      clearcoatRoughness: polish.clearcoatRoughness,
      envMapIntensity: polish.envMapIntensity,
      vertexColors: useVertexColors,
      flatShading: settings.flatShading,
    });
  } else {
    pbrMaterial = new THREE.MeshStandardMaterial({
      name: `Mat_${sanitizeAsciiNodeName(settings.assetName)}`,
      map: albedoRes.texture,
      normalMap:
        effectiveNormalStrength > 0.02 && useSegMaps ? normalRes.texture : null,
      normalScale: new THREE.Vector2(effectiveNormalStrength, effectiveNormalStrength),
      roughnessMap: useSegMaps ? roughRes.texture : null,
      roughness: useSegMaps ? 1.0 : effectiveRoughness,
      metalnessMap:
        settings.autoMaterialSegmentation && useSegMaps ? metalRes.texture : null,
      metalness:
        settings.autoMaterialSegmentation && useSegMaps ? 1.0 : effectiveMetalness,
      envMapIntensity: polishOn ? polish.envMapIntensity : 1.0,
      vertexColors: useVertexColors,
      flatShading: settings.flatShading,
    });
  }

  if (!settings.autoMaterialSegmentation || nearestSampling) {
    metalRes.texture.dispose();
  }

  let displayMaterial: THREE.Material = pbrMaterial;
  if (renderMode === 'normals') {
    displayMaterial = new THREE.MeshNormalMaterial({
      flatShading: settings.flatShading,
    });
  } else if (renderMode === 'wireframe') {
    const wireClone = pbrMaterial.clone() as THREE.MeshStandardMaterial;
    wireClone.wireframe = true;
    displayMaterial = wireClone;
  }

  const rootName = sanitizeAsciiNodeName(settings.assetName, 'GameAsset_3D');
  const root = new THREE.Group();
  root.name = rootName;

  const colSuffix = settings.godotCollisionSuffix ? '-col' : '';
  const mesh = new THREE.Mesh(geometry, displayMaterial);
  mesh.name = `${rootName}_Mesh${colSuffix}`;
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  mesh.userData.pbrMaterial = pbrMaterial;
  root.add(mesh);

  root.updateMatrixWorld(true);
  const box = new THREE.Box3().setFromObject(mesh);
  if (!box.isEmpty()) {
    const center = new THREE.Vector3();
    box.getCenter(center);
    if (settings.pivotMode === 'bottom_center') {
      mesh.position.set(-center.x, -box.min.y, -center.z);
    } else {
      mesh.position.set(-center.x, -center.y + (box.max.y - box.min.y) * 0.5, -center.z);
    }
  }

  root.updateMatrixWorld(true);
  const finalBox = new THREE.Box3().setFromObject(root);
  const size = new THREE.Vector3();
  finalBox.getSize(size);

  const vertexCount = geometry.attributes.position ? geometry.attributes.position.count : 0;
  const triangleCount = geometry.index
    ? Math.round(geometry.index.count / 3)
    : Math.round(vertexCount / 3);

  const texResLabel = `${pipelineOut.atlasW}×${pipelineOut.atlasH}`;

  return {
    group: root,
    pbrMaterial,
    previews: {
      cutoutMaskUrl: maskPreviewRes.dataUrl,
      normalMapUrl: normalRes.dataUrl,
      roughnessMapUrl: roughRes.dataUrl,
      metalnessMapUrl: metalRes.dataUrl,
    },
    stats: {
      meshCount: 1,
      triangleCount,
      vertexCount,
      materialCount: 1,
      foregroundCoveragePct: pipelineOut.foregroundCoveragePct,
      metallicSurfacePct: pipelineOut.metallicSurfacePct,
      hasBackImage: pipelineOut.hasBackImage,
      textureResolution: texResLabel,
      polishActive: polishOn,
      boundsMeters: {
        width: Number(size.x.toFixed(2)),
        height: Number(size.y.toFixed(2)),
        depth: Number(size.z.toFixed(2)),
      },
      validation: finalValidation,
    },
  };
}

export function disposeObject3D(root: THREE.Object3D | null): void {
  if (!root) return;
  root.traverse((obj) => {
    if (obj instanceof THREE.Mesh) {
      obj.geometry?.dispose();
      const mats = Array.isArray(obj.material) ? obj.material : [obj.material];
      const pbrMat = obj.userData?.pbrMaterial as THREE.Material | undefined;
      const allMats = new Set<THREE.Material>();
      for (const m of mats) if (m) allMats.add(m);
      if (pbrMat) allMats.add(pbrMat);

      for (const m of allMats) {
        const std = m as THREE.MeshStandardMaterial;
        std.map?.dispose();
        std.normalMap?.dispose();
        std.roughnessMap?.dispose();
        std.metalnessMap?.dispose();
        m.dispose();
      }
    }
  });
}
