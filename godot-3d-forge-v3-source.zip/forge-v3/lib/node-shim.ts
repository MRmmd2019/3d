/**
 * Node adapter for the Forge mesh engine (F-29).
 *
 * Browser-free path into the engine core: `sharp` decodes image files to raw
 * RGBA, `fs` writes output files, and the pure engine core
 * (`meshAlgorithms` / `meshPipeline`) runs in Node UNCHANGED.
 *
 * Nothing in this module touches `window` or `document`. The browser-only
 * edges of the engine (`meshEngine.ts` image/canvas loading and
 * `godotExport.ts` anchor downloads) are deliberately NOT used here: the
 * pipeline is driven directly and the GLB is written with
 * `@gltf-transform/core`, which is platform-agnostic.
 *
 * NOTE on targets (Group F owns `lib/targets.ts`, which does not exist yet):
 * the CLI/MCP accept all five target names, but this adapter only applies
 * the Godot default geometry for every target. Target-specific transforms
 * (Unreal cm scale, normal-map green-channel flip, Unity
 * metallic+smoothness packing) land with Group F; see TARGET_NOTE.
 */
import { mkdir, readFile, writeFile as fsWriteFile } from 'node:fs/promises';
import { dirname } from 'node:path';
import sharp from 'sharp';
import { Accessor, Document, WebIO } from '@gltf-transform/core';
import { EXTTextureWebP } from '@gltf-transform/extensions';
import { runMeshBuildPipeline, type MeshPipelineOutput } from './meshPipeline';
import { validateMeshTopology } from './meshAlgorithms';
import { optimizeGlbBinary } from './optimizeGlb';
import {
  DEFAULT_MESH_SETTINGS,
  sanitizeAsciiNodeName,
  type MeshBuildSettings,
  type MeshGenerationMode,
  type MeshValidationReport,
  type TextureResolution,
} from './meshTypes';

// ---------------------------------------------------------------------------
// Image / file primitives
// ---------------------------------------------------------------------------

/**
 * WebIO with the WebP texture extension registered. Required for reading
 * (and writing) GLBs whose textures were WebP-compressed by
 * `optimizeGlbBinary` (EXT_texture_webp is `extensionsRequired` there);
 * a bare `new WebIO()` throws "Missing required extension" on such files.
 */
function createWebIO(): WebIO {
  return new WebIO().registerExtensions([EXTTextureWebP]);
}

export interface DecodedImage {
  data: Uint8ClampedArray;
  width: number;
  height: number;
}

/** Decode an image file (PNG/JPG/WebP/…) to raw RGBA via sharp. */
export async function decodeImageToRgba(path: string): Promise<DecodedImage> {
  const { data, info } = await sharp(path)
    .ensureAlpha()
    .raw()
    .toBuffer({ resolveWithObject: true });
  return {
    data: new Uint8ClampedArray(data.buffer, data.byteOffset, data.byteLength),
    width: info.width,
    height: info.height,
  };
}

/** Encode raw RGBA pixels to a PNG buffer via sharp. */
export async function encodeRgbaToPng(
  rgba: Uint8ClampedArray,
  width: number,
  height: number
): Promise<Buffer> {
  const raw = Buffer.from(rgba.buffer, rgba.byteOffset, rgba.byteLength);
  return sharp(raw, { raw: { width, height, channels: 4 } })
    .png()
    .toBuffer();
}

/** Resample raw RGBA to a new size (sharp lanczos; mirrors canvas drawImage scaling). */
export async function resampleRgba(
  rgba: Uint8ClampedArray,
  width: number,
  height: number,
  newWidth: number,
  newHeight: number
): Promise<Uint8ClampedArray> {
  const raw = Buffer.from(rgba.buffer, rgba.byteOffset, rgba.byteLength);
  const out = await sharp(raw, { raw: { width, height, channels: 4 } })
    .resize(newWidth, newHeight)
    .raw()
    .toBuffer();
  return new Uint8ClampedArray(out.buffer, out.byteOffset, out.byteLength);
}

/** Write bytes (or text) to a file, creating parent directories as needed. */
export async function writeFile(
  path: string,
  bytes: Uint8Array | Buffer | string
): Promise<void> {
  const dir = dirname(path);
  if (dir && dir !== '.') await mkdir(dir, { recursive: true });
  await fsWriteFile(path, bytes);
}

/** Read a whole file as bytes. */
export async function readFileBytes(path: string): Promise<Uint8Array> {
  const buf = await readFile(path);
  return new Uint8Array(buf.buffer, buf.byteOffset, buf.byteLength);
}

/** Default GLB output path for a photo: `<photo-basename>.glb` in the cwd. */
export function defaultGlbOutPath(photoPath: string): string {
  const base = photoPath.replace(/\\/g, '/').split('/').pop() ?? 'asset';
  const stem = base.replace(/\.[^.]+$/, '') || 'asset';
  return `${stem}.glb`;
}

// ---------------------------------------------------------------------------
// Export targets (pass-through until Group F lands lib/targets.ts)
// ---------------------------------------------------------------------------

export const FORGE_TARGETS = ['godot', 'unity', 'unreal', 'blender', 'generic'] as const;
export type ForgeTarget = (typeof FORGE_TARGETS)[number];

export const TARGET_NOTE =
  'Target-specific transforms (Unreal cm scale, normal-map green flip, Unity metallic+smoothness packing) are applied by Group F (lib/targets.ts); this build applies the Godot default geometry for every target.';

export function parseTarget(raw: string | undefined): ForgeTarget {
  if (!raw) return 'godot';
  const t = raw.trim().toLowerCase();
  if ((FORGE_TARGETS as readonly string[]).includes(t)) return t as ForgeTarget;
  throw new Error(
    `Unknown target "${raw}". Valid targets: ${FORGE_TARGETS.join(', ')}.`
  );
}

export function listForgeTargets(): Array<{ id: ForgeTarget; label: string; unit: string }> {
  return [
    { id: 'godot', label: 'Godot 4 — GLB, metres, -col collision suffix', unit: 'm' },
    { id: 'unity', label: 'Unity — GLB via glTFast, metres', unit: 'm' },
    { id: 'unreal', label: 'Unreal — GLB, centimetres (x100 scale)', unit: 'cm' },
    { id: 'blender', label: 'Blender — GLB, metres', unit: 'm' },
    { id: 'generic', label: 'Generic glTF — GLB, metres', unit: 'm' },
  ];
}

// ---------------------------------------------------------------------------
// Pipeline -> GLB
// ---------------------------------------------------------------------------

export interface BuildMeshOptions {
  frontPath: string;
  backPath?: string | null;
  target?: ForgeTarget;
  widthMeters?: number;
  mode?: MeshGenerationMode;
  assetName?: string;
  resolution?: number;
  textureResolution?: TextureResolution;
  /** Run weld/dedup/prune optimization (default true, mirrors the UI export). */
  optimize?: boolean;
}

export interface BuildMeshResult {
  glbBytes: Uint8Array;
  triangles: number;
  vertices: number;
  sizeBytes: number;
  target: ForgeTarget;
  assetName: string;
  widthMeters: number;
  watertight: boolean;
  openBoundaryEdges: number;
  degenerateTriangles: number;
  withinTriangleBudget: boolean;
  boundsMeters: { width: number; height: number; depth: number };
  foregroundCoveragePct: number;
  metallicSurfacePct: number;
  hasBackImage: boolean;
}

function computeBoundsMeters(positions: Float32Array): {
  width: number;
  height: number;
  depth: number;
} {
  let minX = Infinity;
  let minY = Infinity;
  let minZ = Infinity;
  let maxX = -Infinity;
  let maxY = -Infinity;
  let maxZ = -Infinity;
  for (let i = 0; i < positions.length; i += 3) {
    const x = positions[i];
    const y = positions[i + 1];
    const z = positions[i + 2];
    if (x < minX) minX = x;
    if (y < minY) minY = y;
    if (z < minZ) minZ = z;
    if (x > maxX) maxX = x;
    if (y > maxY) maxY = y;
    if (z > maxZ) maxZ = z;
  }
  return {
    width: Number((maxX - minX).toFixed(3)),
    height: Number((maxY - minY).toFixed(3)),
    depth: Number((maxZ - minZ).toFixed(3)),
  };
}

/**
 * Recenter positions the way `meshEngine.build3DMeshFromImage` does for the
 * default `bottom_center` pivot: X/Z centered, Y resting on 0.
 */
function applyBottomCenterPivot(positions: Float32Array): Float32Array {
  const out = new Float32Array(positions);
  let minX = Infinity;
  let minY = Infinity;
  let minZ = Infinity;
  let maxX = -Infinity;
  let maxZ = -Infinity;
  for (let i = 0; i < out.length; i += 3) {
    if (out[i] < minX) minX = out[i];
    if (out[i] > maxX) maxX = out[i];
    if (out[i + 1] < minY) minY = out[i + 1];
    if (out[i + 2] < minZ) minZ = out[i + 2];
    if (out[i + 2] > maxZ) maxZ = out[i + 2];
  }
  const cx = (minX + maxX) / 2;
  const cz = (minZ + maxZ) / 2;
  for (let i = 0; i < out.length; i += 3) {
    out[i] -= cx;
    out[i + 1] -= minY;
    out[i + 2] -= cz;
  }
  return out;
}

/** Combine separate roughness + metalness maps into one glTF ORM texture. */
function combineOrmTexture(
  roughRgba: Uint8ClampedArray,
  metalRgba: Uint8ClampedArray
): Uint8ClampedArray {
  const px = roughRgba.length / 4;
  const orm = new Uint8ClampedArray(px * 4);
  for (let i = 0; i < px; i++) {
    const p = i * 4;
    orm[p] = 255; // occlusion = 1.0
    orm[p + 1] = roughRgba[p]; // G = roughness
    orm[p + 2] = metalRgba[p]; // B = metalness
    orm[p + 3] = 255;
  }
  return orm;
}

async function pipelineOutputToGlb(
  out: MeshPipelineOutput,
  settings: MeshBuildSettings
): Promise<Uint8Array> {
  const safeName = sanitizeAsciiNodeName(settings.assetName, 'GameAsset_3D');
  const polishOn = Boolean(settings.polish?.enabled);
  const effectiveNormalStrength =
    polishOn && typeof settings.polish.normalStrengthOverride === 'number'
      ? settings.polish.normalStrengthOverride
      : settings.normalStrength;

  const albedoPng = await encodeRgbaToPng(out.albedoOutRgba, out.atlasW, out.atlasH);
  const normalPng = await encodeRgbaToPng(out.normalOutRgba, out.atlasW, out.atlasH);
  const ormPng = await encodeRgbaToPng(
    combineOrmTexture(out.roughOutRgba, out.metalOutRgba),
    out.atlasW,
    out.atlasH
  );

  const doc = new Document();
  const buffer = doc.createBuffer();

  // Fresh copies: gltf-transform's setArray() requires ArrayBuffer-backed
  // typed arrays, while the pipeline may hand back ArrayBufferLike views.
  const positions = new Float32Array(applyBottomCenterPivot(out.positions));
  const uvs = new Float32Array(out.uvs);
  const indices = new Uint32Array(out.indices);

  const posAcc = doc
    .createAccessor('position')
    .setType(Accessor.Type.VEC3)
    .setArray(positions)
    .setBuffer(buffer);
  const uvAcc = doc
    .createAccessor('uv')
    .setType(Accessor.Type.VEC2)
    .setArray(uvs)
    .setBuffer(buffer);
  const idxAcc = doc
    .createAccessor('index')
    .setType(Accessor.Type.SCALAR)
    .setArray(indices)
    .setBuffer(buffer);

  const primitive = doc
    .createPrimitive()
    .setAttribute('POSITION', posAcc)
    .setAttribute('TEXCOORD_0', uvAcc)
    .setIndices(idxAcc);
  if (out.normals) {
    primitive.setAttribute(
      'NORMAL',
      doc
        .createAccessor('normal')
        .setType(Accessor.Type.VEC3)
        .setArray(new Float32Array(out.normals))
        .setBuffer(buffer)
    );
  }
  if (out.colors) {
    primitive.setAttribute(
      'COLOR_0',
      doc
        .createAccessor('color')
        .setType(Accessor.Type.VEC3)
        .setArray(new Float32Array(out.colors))
        .setBuffer(buffer)
    );
  }

  const albedoTex = doc
    .createTexture(`${safeName}_albedo`)
    .setImage(new Uint8Array(albedoPng))
    .setMimeType('image/png');
  const normalTex = doc
    .createTexture(`${safeName}_normal`)
    .setImage(new Uint8Array(normalPng))
    .setMimeType('image/png');
  const ormTex = doc
    .createTexture(`${safeName}_orm`)
    .setImage(new Uint8Array(ormPng))
    .setMimeType('image/png');

  const material = doc
    .createMaterial(`Mat_${safeName}`)
    .setBaseColorTexture(albedoTex)
    .setNormalTexture(normalTex)
    .setNormalScale(effectiveNormalStrength)
    .setMetallicRoughnessTexture(ormTex)
    .setMetallicFactor(1.0)
    .setRoughnessFactor(1.0);
  primitive.setMaterial(material);

  const colSuffix = settings.godotCollisionSuffix ? '-col' : '';
  const mesh = doc.createMesh(`${safeName}_Mesh${colSuffix}`).addPrimitive(primitive);
  const node = doc.createNode(safeName).setMesh(mesh);
  const scene = doc.createScene('Scene').addChild(node);
  doc.getRoot().setDefaultScene(scene);

  const bytes = await createWebIO().writeBinary(doc);
  return new Uint8Array(bytes.buffer, bytes.byteOffset, bytes.byteLength);
}

export interface GlbMeshStats {
  meshes: number;
  primitives: number;
  triangles: number;
  vertices: number;
  materials: number;
  textures: number;
}

/** Parse a GLB and count its first mesh's geometry (authoritative post-optimize counts). */
export async function readGlbMeshStats(glbBytes: Uint8Array): Promise<GlbMeshStats> {
  const doc = await createWebIO().readBinary(glbBytes);
  const root = doc.getRoot();
  const meshes = root.listMeshes();
  let triangles = 0;
  let vertices = 0;
  let primitives = 0;
  for (const mesh of meshes) {
    for (const prim of mesh.listPrimitives()) {
      primitives += 1;
      const pos = prim.getAttribute('POSITION');
      const idx = prim.getIndices();
      const posCount = pos?.getCount() ?? 0;
      vertices += posCount;
      triangles += idx ? Math.floor(idx.getCount() / 3) : Math.floor(posCount / 3);
    }
  }
  return {
    meshes: meshes.length,
    primitives,
    triangles,
    vertices,
    materials: root.listMaterials().length,
    textures: root.listTextures().length,
  };
}

/**
 * Build a GLB from a front photo (plus an optional back photo) using the
 * engine core. Grid/texture sizes follow the exact same formulas as
 * `meshEngine.build3DMeshFromImage`, so CLI/MCP output matches the UI.
 */
export async function buildMeshGlb(options: BuildMeshOptions): Promise<BuildMeshResult> {
  const target = options.target ?? 'godot';
  const settings: MeshBuildSettings = {
    ...DEFAULT_MESH_SETTINGS,
    assetName: options.assetName ?? 'GameAsset_3D',
    mode: options.mode ?? DEFAULT_MESH_SETTINGS.mode,
    targetWidthMeters: options.widthMeters ?? DEFAULT_MESH_SETTINGS.targetWidthMeters,
    resolution: options.resolution ?? DEFAULT_MESH_SETTINGS.resolution,
    textureResolution: options.textureResolution ?? DEFAULT_MESH_SETTINGS.textureResolution,
  };

  const front = await decodeImageToRgba(options.frontPath);
  const back = options.backPath ? await decodeImageToRgba(options.backPath) : null;

  const aspect = front.width / Math.max(1, front.height);
  const baseRes =
    settings.mode === 'voxel'
      ? Math.min(68, Math.max(20, Math.round(settings.resolution * 0.45)))
      : settings.resolution;
  const cols = aspect >= 1 ? baseRes : Math.max(20, Math.round(baseRes * aspect));
  const rows = aspect >= 1 ? Math.max(20, Math.round(baseRes / aspect)) : baseRes;

  const nearestSampling = settings.mode === 'voxel';
  const targetTexRes = settings.textureResolution;
  const mapW = nearestSampling
    ? cols
    : aspect >= 1
      ? targetTexRes
      : Math.max(128, Math.round(targetTexRes * aspect));
  const mapH = nearestSampling
    ? rows
    : aspect >= 1
      ? Math.max(128, Math.round(targetTexRes / aspect))
      : targetTexRes;

  const frontSegRgba = await resampleRgba(front.data, front.width, front.height, cols, rows);
  const frontMapRgba = await resampleRgba(front.data, front.width, front.height, mapW, mapH);
  const backSegRgba = back
    ? await resampleRgba(back.data, back.width, back.height, cols, rows)
    : null;
  const backMapRgba = back
    ? await resampleRgba(back.data, back.width, back.height, mapW, mapH)
    : null;

  const out = runMeshBuildPipeline({
    cols,
    rows,
    aspect,
    frontSegRgba,
    backSegRgba,
    mapW,
    mapH,
    frontMapRgba,
    backMapRgba,
    settings,
  });

  let glbBytes = await pipelineOutputToGlb(out, settings);
  if (options.optimize !== false) {
    try {
      // slice() copies exactly this view's bytes into a fresh exact-size buffer.
      glbBytes = await optimizeGlbBinary(glbBytes.slice().buffer as ArrayBuffer);
    } catch {
      // Keep the raw GLB if optimization fails (same fallback as the UI export).
    }
  }

  const stats = await readGlbMeshStats(glbBytes);
  const bounds = computeBoundsMeters(applyBottomCenterPivot(out.positions));

  return {
    glbBytes,
    triangles: stats.triangles,
    vertices: stats.vertices,
    sizeBytes: glbBytes.byteLength,
    target,
    assetName: sanitizeAsciiNodeName(settings.assetName, 'GameAsset_3D'),
    widthMeters: settings.targetWidthMeters,
    watertight: out.validation.isWatertight,
    openBoundaryEdges: out.validation.openBoundaryEdges,
    degenerateTriangles: out.validation.degenerateTriangles,
    withinTriangleBudget: out.validation.withinTriangleBudget,
    boundsMeters: bounds,
    foregroundCoveragePct: out.foregroundCoveragePct,
    metallicSurfacePct: out.metallicSurfacePct,
    hasBackImage: out.hasBackImage,
  };
}

// ---------------------------------------------------------------------------
// GLB validation / optimization (shared by the MCP tools)
// ---------------------------------------------------------------------------

export interface GlbValidation {
  valid: boolean;
  triangles: number;
  vertices: number;
  meshes: number;
  primitives: number;
  materials: number;
  textures: number;
  sizeBytes: number;
  validation: MeshValidationReport;
  error?: string;
}

/** Parse a GLB file and validate the topology of its first mesh. */
export async function validateGlbFile(path: string): Promise<GlbValidation> {
  const bytes = await readFileBytes(path);
  return validateGlbBytes(bytes);
}

export async function validateGlbBytes(bytes: Uint8Array): Promise<GlbValidation> {
  try {
    const doc = await createWebIO().readBinary(bytes);
    const root = doc.getRoot();
    const meshes = root.listMeshes();
    if (meshes.length === 0) {
      return {
        valid: false,
        triangles: 0,
        vertices: 0,
        meshes: 0,
        primitives: 0,
        materials: root.listMaterials().length,
        textures: root.listTextures().length,
        sizeBytes: bytes.byteLength,
        validation: {
          isWatertight: false,
          openBoundaryEdges: 0,
          degenerateTriangles: 0,
          hasInvalidPositions: true,
          withinTriangleBudget: false,
          triangleBudget: DEFAULT_MESH_SETTINGS.targetTriangleBudget,
          decimatedFromTriangles: null,
        },
        error: 'GLB contains no meshes.',
      };
    }
    const prim = meshes[0].listPrimitives()[0];
    const posAttr = prim.getAttribute('POSITION');
    const idxAttr = prim.getIndices();
    const positions = (posAttr?.getArray() ?? new Float32Array(0)) as Float32Array;
    const indices = idxAttr?.getArray() ?? null;
    const validation = validateMeshTopology(
      positions,
      indices,
      DEFAULT_MESH_SETTINGS.targetTriangleBudget,
      null
    );
    const stats = await readGlbMeshStats(bytes);
    return {
      valid: validation.isWatertight && !validation.hasInvalidPositions,
      triangles: stats.triangles,
      vertices: stats.vertices,
      meshes: stats.meshes,
      primitives: stats.primitives,
      materials: stats.materials,
      textures: stats.textures,
      sizeBytes: bytes.byteLength,
      validation,
    };
  } catch (err) {
    return {
      valid: false,
      triangles: 0,
      vertices: 0,
      meshes: 0,
      primitives: 0,
      materials: 0,
      textures: 0,
      sizeBytes: bytes.byteLength,
      validation: {
        isWatertight: false,
        openBoundaryEdges: 0,
        degenerateTriangles: 0,
        hasInvalidPositions: true,
        withinTriangleBudget: false,
        triangleBudget: DEFAULT_MESH_SETTINGS.targetTriangleBudget,
        decimatedFromTriangles: null,
      },
      error: err instanceof Error ? err.message : String(err),
    };
  }
}

/** Optimize a GLB file in place (weld / dedup / prune). Returns new size. */
export async function optimizeGlbFile(
  inputPath: string,
  outputPath?: string
): Promise<{ inputBytes: number; outputBytes: number; outputPath: string }> {
  const bytes = await readFileBytes(inputPath);
  // slice() copies exactly this view's bytes (readFileBytes may wrap a pooled Buffer).
  const optimized = await optimizeGlbBinary(bytes.slice().buffer as ArrayBuffer);
  const outPath = outputPath ?? inputPath;
  await writeFile(outPath, optimized);
  return { inputBytes: bytes.byteLength, outputBytes: optimized.byteLength, outputPath: outPath };
}
